/*
 * Copyright (c) 2004
 *	Dmitry V. Stefankov.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the Author
 *      Dmitry V. Stefankov and its contributors.
 * 4. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#if defined(_UNIX)
#include  <sys/types.h>
#include  <sys/param.h>
#include  <unistd.h>
#include  <sys/socket.h>
#include  <sys/time.h>
#include  <stdlib.h>
#include  <string.h>
#include  <stdio.h>
#include  <netinet/in.h>
#include  <syslog.h>
#include  <fcntl.h>
#include  <arpa/inet.h>
#include  <signal.h>
#include  <errno.h>
#include  <netdb.h>
#include  <ctype.h>
#include  <sys/stat.h>
#include  <pthread.h>
#endif

#if defined(_WIN32)
#include  <basetsd.h>
#include  <windows.h>
#include  <stdlib.h>
#include  <string.h>
#include  <stdio.h>
#include  <fcntl.h>
#include  <errno.h>
#include  <signal.h>
#include  <winsock.h>
#include  <time.h>
#include  <sys/stat.h>
#include  <io.h>
#include  <process.h>
#include  "getopt.h"
#endif

#include  "defs.h"
#include  "netcode.h"
#if defined(_UNIX)
#include  <bfpsdk.h>
#endif
#if defined(_WIN32)
#include  "bfpsdk.h"
#endif

#if __SSL__
#include <openssl/rsa.h>       /* SSLeay stuff */
#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#endif


/* Constants */

#define  MAX_CLIENTS_BACKLOG           5
#define  IP_ADDR_SIZE                  16
#define  FILENAME_SIZE                512

#if defined(_UNIX)
#define  MIN_REQ_SSIZE                (2048*1024)
#endif
#if defined(_WIN32)
#define  MIN_REQ_SSIZE                (0*1024)
#endif

/*----------------------------- Debugging -----------------------------------*/

#define  V_LEVEL_INFO        0
#define  V_LEVEL_DEBUG       1
#define  V_LEVEL_MIN         V_LEVEL_INFO
#define  V_LEVEL_MAX         V_LEVEL_DEBUG


/*-------------------------- Client-server data -----------------------------*/

#define    IP_ADDR_SIZE                16
#define    PORT_SIZE                    8
#define    DEF_XFR_BLOCK_SIZE        8192

/*----------------------------- Module data --------------------------------*/

int      term_flag = 0;
int      verbose = 0;
int      dmode = 0;
int      v_level = V_LEVEL_INFO;
int      names_resolv = 1;
int      ssl_flag = 1;
#if __SSL__
SSL_CTX*  ctx = NULL;
#endif

int      client_connect_tmout   = 10;
int      client_data_send_tmout = 15;
int      client_data_recv_tmout = 15;

char   * server_addr = NULL;
char   * server_port = NULL;  
char   * real_server_port = NULL;
char     real_server_address[IP_ADDR_SIZE];

char   * ssl_server_port = NULL;
char   * ssl_real_server_port = NULL;
char     ssl_real_server_address[IP_ADDR_SIZE];


char     server_def_port[] = "5775";
char     ssl_server_def_port[] = "5776";
char     ip_localhost[]    = "127.0.0.1";

char *   version = "1.0.0";
char *   program_name;
char     full_program_name[FILENAME_SIZE];

struct bfp_software_info  bfp_soft_param;        
int         read_fp_tmout = 7;
long int    image_scan_size = 0;
u_long      user_scanner_num = 0;

#if defined(_UNIX)
pthread_mutex_t        access_scanner = PTHREAD_MUTEX_INITIALIZER;
#endif
#if defined(_WIN32)
HANDLE                 h_access_scanner = NULL; 
#endif

unsigned char   * pImagesMdl  = NULL;
unsigned char   * pModel = NULL;

extern  int        optind;
extern  int        opterr;
extern  char     * optarg;

char         * g_szDebugLogFile = NULL;
#if defined(_WIN32)
char  g_szDefLogFile[]   = "remote_scanner.log";
#endif

/* SSL stuff */
#if defined(_UNIX)
char def_cert_file[]    = "/usr/local/etc/auth_pam_bfp/server.pem";
char def_privkey_file[] = "/usr/local/etc/auth_pam_bfp/server.pem";
char def_cacert_file[]  = "/usr/local/etc/auth_pam_bfp/cacert.pem";
#endif
#if defined(_WIN32)
char  def_cert_file[]    = "server.pem";
char  def_privkey_file[] = "server.pem";
char  def_cacert_file[]  = "cacert.pem";
#endif
char *  ssl_cert_file = NULL;
char *  ssl_privkey_file = NULL;
char *  ssl_privkey_pass = NULL;
char *  ssl_cacert_file = NULL;

int ssl_verify_flag = 0;


#if defined(_WIN32)
/*
 * Wait for N milliseconds
 */
DWORD WaitingThisInterval( DWORD dwTimeout )
{
  DWORD      dwRetCode = 0;                 // Return code
  DWORD      dwRes;                         // Result code
  HANDLE     hEventObj;                     // Event object

  hEventObj = CreateEvent(  NULL,           /* no security attributes */
                            FALSE,          /* manual-reset event */
                            FALSE,          /* initial state is signaled */
                            NULL            /* object name */
  ); 

  if (hEventObj == NULL) { 
    dwRetCode = 1;
    return(dwRetCode);
  }

  dwRes = WaitForSingleObject( hEventObj, dwTimeout );

  switch( dwRes ) {
    case WAIT_TIMEOUT:
      dwRetCode = 0;
      break;
   case WAIT_OBJECT_0:
      dwRetCode = 2;
      break;
   case WAIT_ABANDONED:
      dwRetCode = 3;
      break;
    default:
      dwRetCode = 4;
      break;
  }

  CloseHandle(hEventObj);

  return(dwRetCode);
}


/*
 * Write buffer to user logfile
 */
BOOL WriteDLogFile( LPTSTR String )
{
   HANDLE    hFile;                         // File object
   DWORD     dwBytesWritten;                // Write counter

   hFile = CreateFile(
                     g_szDebugLogFile,
                     GENERIC_READ|GENERIC_WRITE,
                     FILE_SHARE_READ|FILE_SHARE_WRITE,
                     NULL,
                     OPEN_ALWAYS,
                     FILE_FLAG_SEQUENTIAL_SCAN,
                     NULL
                     );

   if (hFile == INVALID_HANDLE_VALUE) return FALSE;

   SetFilePointer(hFile, 0, NULL, FILE_END);

   WriteFile(
            hFile,
            String,
            lstrlen(String)*sizeof(TCHAR),
            &dwBytesWritten,
            NULL
            );

   CloseHandle(hFile);

   return TRUE;
}


/*
 * Convert from UNIX time format (1 sec, from 1 Jan 1970)
 * to Microsoft time format     (100 ns, from 1 Jan 1601)
 */
void TimetToFileTime( time_t t, LPFILETIME pft )
{
    LONGLONG ll = Int32x32To64(t, 10000000) + 116444736000000000;
    pft->dwLowDateTime = (DWORD) ll;
    pft->dwHighDateTime = (DWORD)(ll >>32);
}
#endif


/*
 * Print standard message
 */
void print_message( const char * msg )
{
   if (msg == NULL) return;

#if defined(_WIN32)   
  if (verbose) {
    if (dmode) WriteDLogFile( (LPTSTR)msg );
    else printf( "%s", msg );
  }
#endif

#if defined(_UNIX)
   if (verbose) {
     if (dmode) syslog( LOG_INFO, "%s", msg );
     else printf( "%s", msg );
   }
#endif

}


/*
 * Print standard message from signal handler
 */
void print_message_signal( const char * msg )
{
   if (msg == NULL) return;

#if defined(_WIN32)   
   if (verbose) {
     if (dmode) WriteDLogFile( (LPTSTR)msg );
     else write( fileno(stdin), msg, strlen(msg) );
   }
#endif
   
#if defined(_UNIX)
   if (verbose) {
     if (dmode) syslog( LOG_INFO, "%s", msg );
     else write( STDIN_FILENO, msg, strlen(msg) );
   }
#endif
}


/*
 * Print error message
 */
void print_error_message( const char * msg )
{
   if (msg == NULL) return;

#if defined(_WIN32) 
  if (dmode) WriteDLogFile( (LPTSTR)msg );  
  else fprintf( stderr, "%s", msg );
#endif

#if defined(_UNIX)
   if (dmode) syslog( LOG_NOTICE, "%s", msg );
   else fprintf( stderr, "%s", msg );
#endif

}


/*
 * Print error message from signal handler
 */
void print_error_message_signal( const char * msg )
{
   if (msg == NULL) return;

#if defined(_WIN32)   
   if (verbose) {
     if (dmode) WriteDLogFile( (LPTSTR)msg );
     else write( fileno(stderr), msg, strlen(msg) );
   }
#endif
   
#if defined(_UNIX)
   if (dmode) syslog( LOG_NOTICE, "%s", msg );
   else write( STDERR_FILENO, msg, strlen(msg) );
#endif
}


/*
 * Change debug level
 */
static void set_new_debug_level(int sig)
{
   char msg_buf[32];
   
   snprintf( msg_buf, sizeof(msg_buf), "DEBUG_LEVEL: switched by signal %d\n", sig );
   print_message_signal( msg_buf );

   v_level++;
   if (v_level > V_LEVEL_MAX) v_level = V_LEVEL_MIN;   
}


/*
 * Signal Handler
 */
static void term(int sig)
{
   char msg_buf[32];

   snprintf( msg_buf, sizeof(msg_buf), "TERM: catched by signal %d\n", sig );
   print_message_signal( msg_buf );
   
   term_flag = 1;
}


/*
 * Signal Handler
 */
static void catch_pipe(int sig)
{
   char msg_buf[32];

   snprintf( msg_buf, sizeof(msg_buf), "PIPE: catched by signal %d\n", sig );
   print_message_signal( msg_buf );
}


void shutdown_lib( void )
{
#if __SSL__
  if (ssl_flag) {
    if (ctx != NULL) SSL_CTX_free (ctx);
  }
#endif
  if (pImagesMdl != NULL) { 
    free(pImagesMdl);
    pImagesMdl = NULL;
  }
  if (pModel != NULL) {
    free(pModel);
    pModel = NULL;
  }
}


/*
 * Terminate server
 */
int terminate_server( void )
{
  int  res = 1;
  
  print_message( "Terminated.\n" );

  shutdown_lib();
#if defined(_UNIX)
  if (dmode) closelog();
#endif

#if defined(_WIN32)    
  WSACleanup();
#endif
  
  exit(0);

  return(res);
} 


#if __SSL__
int verify_callback( int ok, X509_STORE_CTX * ctx )
{
  char   msg_buf[32];
  
  snprintf(msg_buf,sizeof(msg_buf), "SSL: verify_ok=%d\n", ok );
  print_message( msg_buf );
  
  return(ok);
}

/*
   SSL requests processing 
*/ 
void * do_ssl_services( void * arg )
{
  int                   res;
  int                   clen;  
  int                   connfd;  
  int                   listenfd;  
  int                   reuseaddr_opt;
  struct                sockaddr_in serveraddr;
  struct                sockaddr_in clientaddr;
  unsigned long         myaddr;
  unsigned char         up[4];
  char                * p;
  char                  msg_buf[512];
  char                  client_ip_buf[IP_ADDR_SIZE];
  struct in_addr        inadr;    
  int                   model_size;
  int                   n = 1;	
  int                   err;
  X509*                 client_cert;
  char*                 str;
  SSL_METHOD            *meth;
  SSL                   *ssl = NULL;
  long int              result;  
  int                   i;
  int                   init_bfplib_done = 0;  
  u_long                device_num;  
  long                  ssl_options;
  struct bfp_hardware_info  bfp_param;  
#if defined(_UNIX)
  u_long                scanner_num = 0;  
  struct timeval        tv;  
  struct timeval        tv2;
#endif
#if defined(_WIN32)
  volatile u_long       scanner_num = 0;
  int                   tv2;
  int                   tv1;
#endif
  
  /* SSL preliminaries. We keep the certificate and key with the context. */
  print_message( "SSL: try to init.\n" );
    
  SSL_load_error_strings();
  SSLeay_add_ssl_algorithms();
  meth = SSLv23_server_method();
  ctx = SSL_CTX_new (meth);
  if (!ctx) {
      ERR_print_errors_fp(stderr);
      return(NULL);
  }
  ssl_options = SSL_CTX_get_options(ctx);
  ssl_options |= SSL_OP_NO_SSLv2;
  SSL_CTX_set_options( ctx, ssl_options );

  if (ssl_cert_file == NULL) ssl_cert_file = def_cert_file;
  if (SSL_CTX_use_certificate_file(ctx, ssl_cert_file, SSL_FILETYPE_PEM) <= 0) {
      ERR_print_errors_fp(stderr);
      return(NULL);
  }
    
  if (ssl_privkey_pass != NULL) 
    SSL_CTX_set_default_passwd_cb_userdata( ctx, ssl_privkey_pass );
  if (ssl_privkey_file == NULL) ssl_privkey_file = def_privkey_file;    
  if (SSL_CTX_use_PrivateKey_file(ctx, ssl_privkey_file, SSL_FILETYPE_PEM) <= 0) {
      ERR_print_errors_fp(stderr);
      return(NULL);
  }

  if (!SSL_CTX_check_private_key(ctx)) {
      print_error_message("SSL-ERROR: Private key does not match the certificate public key\n");
      return(NULL);
  }

  if (ssl_verify_flag) {
    if (ssl_cacert_file == NULL) ssl_cacert_file = def_cacert_file;
    if (!SSL_CTX_load_verify_locations( ctx, ssl_cacert_file, 
                getenv(X509_get_default_cert_dir_env()) )) {
      ERR_print_errors_fp(stderr);
      return(NULL);
    }    
    SSL_CTX_set_verify( ctx, SSL_VERIFY_PEER|SSL_VERIFY_FAIL_IF_NO_PEER_CERT, verify_callback );          
  }


    
  print_message( "SSL: init done.\n" );

  listenfd = socket( AF_INET, SOCK_STREAM, 0);
  if (listenfd == -1) {
    print_error_message( "SSL-ERROR: cannot create socket!\n" );
    return(NULL);
  }

  if (verbose) print_message( "SSL: set socket SO_REUSEADDR.\n" );     
  reuseaddr_opt = 1;
  res = setsockopt( listenfd, SOL_SOCKET, SO_REUSEADDR, (char *)&reuseaddr_opt, 
                    sizeof(reuseaddr_opt) );
  if (res == -1) {
     print_error_message( "SSL-ERROR: cannot set socket SO_REUSEADDR option!\n" );
  }
     
  memset(&serveraddr, 0, sizeof(serveraddr) );
  serveraddr.sin_family = AF_INET;
  if (server_addr == NULL) myaddr = INADDR_ANY;
  else myaddr = inet_addr(server_addr);
  memcpy( up, &myaddr, sizeof(up) );
  snprintf( real_server_address, sizeof(real_server_address),
            "%d.%d.%d.%d",up[0], up[1], up[2], up[3] );
  snprintf( msg_buf, sizeof(msg_buf), "SSL: address = %d.%d.%d.%d\n",up[0], up[1], up[2], up[3] );
  print_message( msg_buf );
  serveraddr.sin_addr.s_addr = myaddr;
  serveraddr.sin_port = htons( (u_short)atol(ssl_real_server_port) );

  res = bind( listenfd, (const struct sockaddr *)&serveraddr, sizeof(serveraddr) );
  if (res == -1) {
    print_error_message( "SSL-ERROR: bind() failed!\n" );
    return(NULL);
  }
  
  res = listen( listenfd, MAX_CLIENTS_BACKLOG );
  if (res == -1) {
    print_error_message( "SSL-ERROR: listen() failed!\n" );
    return(NULL);
  }

  if (verbose) {
    snprintf( msg_buf, sizeof(msg_buf), "SSL: listen on interface. Port %s\n", 
              ssl_real_server_port );
    print_message( msg_buf );
  }


  for( ;; ) {

     init_bfplib_done = 0;
     print_message( "SSL: wait in accept(..) [network]\n" );
  
     clen = sizeof(clientaddr);
     connfd = accept( listenfd, (struct sockaddr *)&clientaddr, (socklen_t *)&clen ); 
     if (term_flag == 1) break;
     if (connfd == -1) {
       print_error_message( "SSL: accept() failed!\n" );
       continue;
     }
     
     memset( client_ip_buf, 0, sizeof(client_ip_buf) );
     memcpy(  &inadr, &clientaddr.sin_addr.s_addr, 4 );
     p = inet_ntoa( inadr );
     if (p != NULL) 
       strncpy( client_ip_buf, p, sizeof(client_ip_buf) );
     if (verbose) {
       if (dmode) {
         snprintf( msg_buf, sizeof(msg_buf), "SSL: connection opened for [%s:%d]\n",
                   client_ip_buf, clientaddr.sin_port );
         print_message( msg_buf );
       }
       else {
         if (verbose && (v_level >= V_LEVEL_DEBUG)) {
           print_message( "SSL: accept...\n" );
           snprintf( msg_buf, sizeof(msg_buf),"SSL: src addr size = %d bytes\n", clen );     
           print_message( msg_buf );
           snprintf( msg_buf, sizeof(msg_buf),"SSL: port = %d\n", clientaddr.sin_port );          
           print_message( msg_buf );
           snprintf( msg_buf, sizeof(msg_buf),"SSL: address = %s\n", client_ip_buf );
           print_message( msg_buf );
         }
       }
     }

#if defined(_WIN32)     
     memset( &tv1, 0, sizeof(tv1) );  
     tv1 = client_data_send_tmout * MS_PER_SECOND;
     res = setsockopt( connfd, SOL_SOCKET, SO_SNDTIMEO, (char *)&tv1, sizeof(tv1) );
     memset( &tv2, 0, sizeof(tv2) );        
     tv2 = client_data_recv_tmout * MS_PER_SECOND;
     res = setsockopt( connfd, SOL_SOCKET, SO_RCVTIMEO, (char *)&tv2, sizeof(tv2) );
#endif

#if defined(_UNIX)
     memset( &tv, 0, sizeof(tv) );
     tv.tv_sec = client_data_send_tmout;
     tv.tv_usec = 0;
     res = setsockopt( connfd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv) );
     if (res == -1) {
       print_error_message( "SSL: cannot set socket send timeout!\n" );
       goto error_done;
     }
     
     memset( &tv2, 0, sizeof(tv2) );
     tv2.tv_sec = client_data_recv_tmout;
     tv2.tv_usec = 0;
     res = setsockopt( connfd, SOL_SOCKET, SO_RCVTIMEO, &tv2, sizeof(tv2) );
     if (res == -1) {
       print_error_message( "SSL: cannot set socket receive timeout!\n" );
       goto error_done;
     }
#endif

    /* TCP connection is ready. Do server side SSL. */
    ssl = SSL_new (ctx);                           
    if (ssl == NULL) {
      print_error_message( "SSL: cannot allocate new socket!\n" );
      goto error_done;
    }
    SSL_set_fd (ssl, connfd);
    err = SSL_accept (ssl);                        
    if (err == -1) {
      ERR_print_errors_fp(stderr);    
      print_error_message( "SSL: cannot accept new connection!\n" );
      goto error_done;
    }
  
    /* Get the cipher - opt */
    snprintf( msg_buf,sizeof(msg_buf),
              "SSL connection using %s\n", SSL_get_cipher (ssl));
    print_message( msg_buf );
  
    result = -1;
    /* Get client's certificate (note: beware of dynamic allocation) - opt */
    client_cert = SSL_get_peer_certificate (ssl);
    if (client_cert != NULL) {

      if (ssl_verify_flag) {    
        result = SSL_get_verify_result( ssl );
        snprintf( msg_buf,sizeof(msg_buf)-1,"SSL: client_verify=%ld\n", result );
        print_message( msg_buf );
      }
      
      print_message("SSL: Client certificate:\n");
    
      str = X509_NAME_oneline (X509_get_subject_name (client_cert), 0, 0);
      if (str != NULL) {
        snprintf( msg_buf,sizeof(msg_buf),"SSL: subject: %s\n", str);
        print_message( msg_buf );
        OPENSSL_free (str);
      }
    
      str = X509_NAME_oneline (X509_get_issuer_name  (client_cert), 0, 0);
      if (str != NULL) {
        snprintf(msg_buf,sizeof(msg_buf),"SSL: issuer: %s\n", str);
        print_message( msg_buf );
        OPENSSL_free (str);
      }
      
      /* We could do all sorts of certificate verification stuff here before
        deallocating the certificate. */
    
      X509_free (client_cert);
    } 
    else {
      print_message("SSL: Client does not have certificate.\n");
    }

     if (ssl_verify_flag) {
       if ((client_cert != NULL) && (result == X509_V_OK)) {
         print_message( "SSL: client verification OK.\n" );
       }
       else {
         print_message( "SSL: client verification failed.\n" );
         goto error_done;
       }
     }

     memset(pImagesMdl, 0, image_scan_size);

     /* Init library */
     res = bfp_init();
     if (res != 0) {
       print_error_message( "ERROR: bfp_init() failed!\n" );
       goto error_done;
     }
     init_bfplib_done = 1;
     scanner_num = 0;
     
     /* Search for hardware */
     memset( &bfp_param, 0, sizeof(bfp_param) ); 
     res = bfp_get_hardware_info( &bfp_param, 0 );
     if (res != 0) {
       print_error_message( "ERROR: no scanners detected!\n" );
       goto error_done;      
     }
     if (user_scanner_num)
       scanner_num = user_scanner_num;
     else 
       scanner_num = (bfp_param.serial_num_high<<16)+
                     (bfp_param.serial_num_mid<<8)+
                     (bfp_param.serial_num_low);
     snprintf( msg_buf, sizeof(msg_buf),
               "SSL: scanner_num = %lu\n", scanner_num );
     print_message( msg_buf );
     
     /* Synchronize access to scanner */
     print_message( "SSL: lock access to scanner.\n" );
#if defined(_UNIX)
     res = pthread_mutex_lock( &access_scanner );
#endif
#if defined(_WIN32)
     res = 0;
     WaitForSingleObject( &h_access_scanner, INFINITE );
#endif
     if (res != 0) {
       snprintf( msg_buf, sizeof(msg_buf), 
                 "SSL: lock_scanner_access failed, code = %d\n", res );
       print_error_message( msg_buf );    
       goto error_done;
     }

     print_message( "SSL: read image from scanner.\n" );
     res = -1;
     for( i=0; i<read_fp_tmout; i++ ) {
       memset( pImagesMdl, 0, image_scan_size );
       res = bfp_get_image_timeo( pImagesMdl, image_scan_size, 0, 0 );
       if (verbose && (v_level >= V_LEVEL_DEBUG)) {
         snprintf( msg_buf, sizeof(msg_buf), "SSL: %d: read_image_result = %d\n", i+1, res);
         print_message( msg_buf );
       }
       if (res == 0) break;
     }
     if (res != 0) {
       print_error_message( "SSL: image capture failed!\n" );
       print_message( "SSL: unlock access to scanner.\n" );
#if defined(_WIN32)
       res = 0;
       ReleaseMutex( &h_access_scanner);
#endif
#if defined(_UNIX)
       res = pthread_mutex_unlock( &access_scanner );
#endif
       goto error_done;
     }

     print_message( "SSL: extract model.\n" );
     model_size = 0;
     n = 1;
     memset(pModel, 0, n * bfp_soft_param.model_size);     
     res = bfp_extract( pImagesMdl, n, pModel );
     if (res > 0) model_size = res;
     snprintf( msg_buf, sizeof(msg_buf), "SSL: build_model = %d\n", res);
     print_message( msg_buf );

#if defined(_WIN32)
     snprintf( msg_buf, sizeof(msg_buf),
               "SSL (Win32): scanner_num = %lu\n", scanner_num );
     print_message( msg_buf );
#endif

     print_message( "SSL: unlock access to scanner.\n" );
#if defined(_WIN32)
     res = 0;
     ReleaseMutex( &h_access_scanner);
#endif
#if defined(_UNIX)
     res = pthread_mutex_unlock( &access_scanner );
#endif
     if (res != 0) {
       snprintf( msg_buf, sizeof(msg_buf), 
                 "SSL: unlock_access_scanner failed, code = %d\n", res );
       print_error_message( msg_buf );    
     } 

     res = set_send_timeo( SSL_get_wfd(ssl), client_data_send_tmout );
     if (res != 0) {
         print_error_message( "SSL: error to set send timeout!\n" );
         goto error_done;
     }

     if (model_size > 0) {
       device_num = htonl(scanner_num);
#if defined(_WIN32)
       snprintf( msg_buf, sizeof(msg_buf),
                 "SSL: scanner_num = %lu (net), %lu (orig)\n", device_num, scanner_num );
       print_message( msg_buf );
#endif
       err = SSL_write (ssl, &device_num, sizeof(device_num) );  
       if (err == -1) {
         ERR_print_errors_fp(stderr);           
         print_error_message( "SSL: error to send serial!\n" );
         goto error_done;
       }
       err = SSL_write (ssl, pModel, model_size );  
       if (err == -1) {
         ERR_print_errors_fp(stderr);           
         print_error_message( "SSL: error to send data!\n" );
         goto error_done;
       }
     }
     print_message( "SSL: model data sent successfully\n" ); 

error_done:
     /* Free resources */
     if (init_bfplib_done) {
        init_bfplib_done = 0; 
        res = bfp_deinit();
     }
     if (pModel != NULL) memset( pModel, 0, n * bfp_soft_param.model_size );
     if (pImagesMdl != NULL) memset( pImagesMdl, 0, image_scan_size );

     if (ssl != NULL) {
        SSL_free (ssl);
        ssl = NULL;
     }
     CLOSE_SOCKET( connfd );
     print_message( "SSL: connection closed.\n" );

     print_message( "SSL: listen ... [network]\n" );
     
  }

  res = terminate_server();

  return(NULL);
}


/*
 * Run subprocess to service SSL requests
 */
int run_ssl_service( void )
{
  int          retcode = 0;
  char         msg_buf[512];
  int          res;
  void       * arg = NULL;
#if defined(_UNIX)
  size_t                default_stack_size = 0;
  size_t                new_stack_size = 0;
  pthread_attr_t        stack_size_custom_attr;
  pthread_t    tid;
#endif
#if defined(_WIN32)
  HANDLE                hThread;
  PDWORD                pdwThreadId;
  DWORD                 dwErrorCode;
  DWORD                 dwStackSize = 0;
#endif

#if defined(_UNIX)
  pthread_attr_init(&stack_size_custom_attr);
  pthread_attr_getstacksize(&stack_size_custom_attr,&default_stack_size);
  snprintf( msg_buf, sizeof(msg_buf), "SSL: default thread stacksize = %d\n", default_stack_size);   
  print_message( msg_buf );
  if (default_stack_size < MIN_REQ_SSIZE) {
    pthread_attr_setstacksize(&stack_size_custom_attr,(size_t)MIN_REQ_SSIZE);    
    pthread_attr_getstacksize(&stack_size_custom_attr,&new_stack_size);    
    snprintf( msg_buf, sizeof(msg_buf), "SSL: new thread stacksize = %d\n", new_stack_size);   
    print_message( msg_buf );
    if (new_stack_size < MIN_REQ_SSIZE) {
      print_message( "SSL: not enough stack size to run thread!\n" );
      retcode = -1;
      return(retcode);
    }
  }
  
   res = pthread_create( &tid, &stack_size_custom_attr, do_ssl_services, arg );
#endif
#if defined(_WIN32)
     pdwThreadId = malloc( sizeof(DWORD) );
     if ( pdwThreadId == NULL) {
       print_error_message( "ERROR: failed to get thread id local space!\n" );
       goto done;     
     }
     res = 0;
     dwStackSize = MIN_REQ_SSIZE;
     hThread = CreateThread( NULL, dwStackSize, 
                             (LPTHREAD_START_ROUTINE )do_ssl_services, 
                             arg, 0, pdwThreadId );
     if (hThread == NULL) {
       retcode = -1;
       dwErrorCode = GetLastError();
     }
     else {
       res = 0;
     }
done:
#endif

   snprintf( msg_buf, sizeof(msg_buf),
             "create ssl_service_thread result code = %d\n", res );
   print_message( msg_buf );  
  
  return(retcode);
}
#endif


/*
 * Help.
 */
void usage(void)
{
  fprintf( stderr, "\n" );
  fprintf( stderr, "REMOTE_SCANNER_ACCESS_SERVER program\n" );
  fprintf( stderr, "\n" );
  fprintf( stderr, "Usage: %s [-sDhv] [-a address] [-p port] [-d level]\n", program_name ); 
  fprintf( stderr, "       [-c certs_file] [-k privkey] [-l ssl_port] [-t secs]\n" );
  fprintf( stderr, "       [-f ca_cert_file ] [-y authmode] [-P keypass] [-u scanner_num]\n" );
  fprintf( stderr, "  -h                --  this help\n" );
  fprintf( stderr, "  -v                --  verbose\n" );
  fprintf( stderr, "  -D                --  daemon mode (default=no)\n" );
  fprintf( stderr, "  -d level          --  debugging level\n" );
  fprintf( stderr, "  -a address        --  listen on this interface (default=all)\n" );
  fprintf( stderr, "  -p port           --  listen on this port\n" );
  fprintf( stderr, "  -l port           --  listen on this port (SSL)\n" );  
  fprintf( stderr, "  -s                --  SSL turn off\n" );
  fprintf( stderr, "  -P keypass        --  userpass to decrypt private key (defualt=none)\n" );
  fprintf( stderr, "  -t seconds        --  image capture timeout\n" );
  fprintf( stderr, "  -u scanner_num    --  user defined scanner number\n" );
  fprintf( stderr, "  -y authmode       --  verify client certificate(0=no,1=yes)\n" );
  fprintf( stderr, "Defaults:\n" );
  fprintf( stderr, "  ssl               --  %d\n", ssl_flag );
  fprintf( stderr, "  ca_cert_file      --  %s\n", def_cacert_file );  
  fprintf( stderr, "  certificate_file  --  %s\n", def_cert_file );
  fprintf( stderr, "  private_key_file  --  %s\n", def_privkey_file );  
  fprintf( stderr, "  server_port       --  %s\n", server_def_port );
  fprintf( stderr, "  ssl_server_port   --  %s\n", ssl_server_def_port );  
  fprintf( stderr, "  verbose level     --  %d\n", verbose );
  fprintf( stderr, "  debug level       --  %d\n", v_level );
  fprintf( stderr, "  names resolving   --  %d\n", names_resolv );
  fprintf( stderr, "  connect timeout   --  %d seconds\n", 
                   client_connect_tmout );  
  fprintf( stderr, "  send timeout      --  %d seconds\n", 
                   client_data_send_tmout );
  fprintf( stderr, "  receive timeout   --  %d seconds\n", 
                   client_data_recv_tmout );
  fprintf( stderr, "  capture timeout   --  %d seconds\n", 
                   read_fp_tmout );  
  fprintf( stderr, "\n" );
  exit(1);
}


/*
 * Main module
 */
int  main( int argc, char ** argv )
{
  int                   res;
  int                   op;
  char                * cp;  
  int                   clen;  
  int                   connfd;  
  int                   listenfd;  
  int                   reuseaddr_opt;
  struct                sockaddr_in serveraddr;
  struct                sockaddr_in clientaddr;
  unsigned long         myaddr;
  unsigned char         up[4];
  char                * p;
  char                * p_addr;
  char                  msg_buf[512];
  char                  client_ip_buf[IP_ADDR_SIZE];
  struct in_addr        inadr;  
  int                   mincount;
  struct bfp_hardware_info  bfp_param;
  u_long                device_num = 0;
  int                   model_size = 0;
  int                   n = 1;	
  int                   i;
  int                   init_bfplib_done = 0;
#if defined(_UNIX)
  u_long                scanner_num = 0;
  pid_t                 pid;
  struct sigaction      sa;  
  sigset_t		mask;
  struct timeval        tv;  
  struct timeval        tv2;
#endif
#if defined(_WIN32)
  volatile u_long       scanner_num = 0;
  WORD 			wVersionRequested;
  WSADATA 		wsaData;
  int 			iErr;
  int                   tv1;
  int                   tv2;
#endif

/* Find program name */  
  if ((cp = strrchr(argv[0],'/')) != NULL)
     program_name = cp + 1;
  else
     program_name = argv[0];
  strncpy( full_program_name, argv[0], sizeof(full_program_name) );

/* Process command line  */  
  opterr = 0;
  while( (op = getopt(argc,argv,"a:c:d:Df:hl:k:P:p:st:u:vy:")) != -1) {
    switch(op) {
      case 'a':
               server_addr = optarg;
      	       break;      	   
      case 'c':
               ssl_cert_file = optarg;
               break; 	       
      case 'd': 
               v_level = atoi(optarg);
               break;
      case 'D':
                ++dmode;
                break;
      case 'f':
               ssl_cacert_file = optarg;
               break;
      case 'h':
               usage();
               break;      
      case 'l':
               ssl_server_port = optarg;
      	       break;      		
      case 'k':
               ssl_privkey_file = optarg;
               break; 	       
      case 'P':
               ssl_privkey_pass = optarg;
               break; 	       
      case 'p':
               server_port = optarg;
      	       break;      		
      case 's':
               ssl_flag = 0;
               break;
      case 't':
               read_fp_tmout = atoi(optarg);
               break;
      case 'v':
               ++verbose;
      	       break;
      case 'u':
               user_scanner_num = atol(optarg);
               break;
      case 'y':
               ssl_verify_flag = atoi(optarg);
               break;
      default:
               usage();
               break;
    }
  }

#if defined(_UNIX)
  if (dmode) {
    if ( (pid = fork()) < 0 ) {
      print_error_message( "Fork() failed!\n" );
      return(-1);
    }
    else if (pid != 0)
      exit(0);
    /* Child continue */
    setsid();
    chdir("/");
    umask(0);
  }
#endif

  if (dmode) {
#if defined(_UNIX)
    openlog( "bfp_srv", LOG_PID, LOG_USER );
#endif
    print_message( "started." );
  }

#if defined(_WIN32)
  wVersionRequested = MAKEWORD( 1, 1 );
  iErr = WSAStartup( wVersionRequested, &wsaData );
  if ( iErr != 0 )
  {
    print_error_message("No Windows Sockests found!\n");
    return(1);
  }
#endif

  if (server_port == NULL) real_server_port = server_def_port;
  else real_server_port = server_port;

  if (ssl_server_port == NULL) ssl_real_server_port = ssl_server_def_port;
  else ssl_real_server_port = ssl_server_port;

  if (names_resolv && (server_addr != NULL)) {
       res = is_ip_addr( server_addr );
       if (res != 0) {
           if (verbose) {
             snprintf( msg_buf, sizeof(msg_buf), 
                       "Try to resolve symbolic name %s.\n", server_addr );
             print_message( msg_buf );
           }
           p = name2ip ( server_addr );
           if (p == NULL ) {
             snprintf( msg_buf, sizeof(msg_buf), "ERROR: cannot resolve name %s!\n",
                       server_addr );
             print_error_message( msg_buf );
             return(1);           
           }
           p_addr = malloc( strlen(p)+1 );
           if (p_addr == NULL) {
             snprintf( msg_buf, sizeof(msg_buf), "ERROR: cannot get space for name %s!\n",
                       server_addr );
             print_error_message( msg_buf );
             return(1);           
           }
           strncpy( p_addr, p, strlen(p)+1 );
           server_addr = p_addr;           
           if (verbose) {
             snprintf( msg_buf, sizeof(msg_buf), "server_address: %s\n",
                       server_addr );
             print_message( msg_buf );
           }
       }
  }

#if defined(_WIN32)
  h_access_scanner  = CreateMutex( NULL, FALSE, 
                                         "MutexToAccessScanner" );

  if (h_access_scanner == NULL) {
    print_error_message( "ERR: cannot create mutex to lock scanner access!\n" );
    return(1);
  }
#endif

  /* Init library */
  res = bfp_init();
  if (res != 0) {
    print_error_message( "ERROR: bfp_init() failed!\n" );
    return(1); 
  }

  memset( &bfp_soft_param, 0, sizeof(bfp_soft_param) );
  res = bfp_get_software_info( &bfp_soft_param );
  if (res != 0) {
    print_error_message( "ERROR: cannot software options!\n" );
    shutdown_lib();
    return(1);           
  }

  image_scan_size = bfp_soft_param.image_size;        
  
  pModel = (unsigned char *)malloc(n * bfp_soft_param.model_size);
  if (pModel == NULL) {
    print_error_message( "ERROR:  model memory allocation failed!\n");
    shutdown_lib();
    return(1);           
  }
  
  pImagesMdl = malloc(n*image_scan_size);
  if (pImagesMdl == NULL) {
    print_error_message( "ERROR:  image memory allocation failed!\n");
    shutdown_lib();          
    return(1);           
  }

  res = bfp_deinit();          
  
  listenfd = socket( AF_INET, SOCK_STREAM, 0);
  if (listenfd == -1) {
    print_error_message( "ERROR: cannot create socket!\n" );
    return(1);
  }

  if (verbose) print_message( "Set socket SO_REUSEADDR.\n" );     
  reuseaddr_opt = 1;
  res = setsockopt( listenfd, SOL_SOCKET, SO_REUSEADDR, (char *)&reuseaddr_opt, 
                    sizeof(reuseaddr_opt) );
  if (res == -1) {
     print_error_message( "ERROR: cannot set socket SO_REUSEADDR option!\n" );
  }
     
  memset(&serveraddr, 0, sizeof(serveraddr) );
  serveraddr.sin_family = AF_INET;
  if (server_addr == NULL) myaddr = INADDR_ANY;
  else myaddr = inet_addr(server_addr);
  memcpy( up, &myaddr, sizeof(up) );
  snprintf( real_server_address, sizeof(real_server_address),
            "%d.%d.%d.%d",up[0], up[1], up[2], up[3] );
  snprintf( msg_buf, sizeof(msg_buf), "address = %d.%d.%d.%d\n",up[0], up[1], up[2], up[3] );
  print_message( msg_buf );
  serveraddr.sin_addr.s_addr = myaddr;
  serveraddr.sin_port = htons( (u_short)atol(real_server_port) );

  res = bind( listenfd, (const struct sockaddr *)&serveraddr, sizeof(serveraddr) );
  if (res == -1) {
    print_error_message( "ERROR: bind() failed!\n" );
    return(1);
  }
  
  res = listen( listenfd, MAX_CLIENTS_BACKLOG );
  if (res == -1) {
    print_error_message( "ERROR: listen() failed!\n" );
    return(1);
  }

  if (verbose) {
    snprintf( msg_buf, sizeof(msg_buf), "Listen on interface. Port %s\n", 
              real_server_port );
    print_message( msg_buf );
  }

#if defined(_WIN32)
   signal(SIGSEGV, term );   
   signal(SIGBREAK, term );
   signal(SIGTERM, term );
   signal(SIGINT, term );
#endif

#if defined(_UNIX)
  sigemptyset(&mask);

#define SIGNAL(s,handler)	{ \
	sa.sa_handler = handler; \
	if (sigaction(s,&sa,NULL) < 0) { \
	  fprintf( stderr, "Couldn't establish signal handler (%d): %m", s); \
	} \
   }   
   
  sa.sa_mask = mask;
  sa.sa_flags = 0; 
  SIGNAL(SIGUSR1, set_new_debug_level );   
  SIGNAL(SIGTERM, term );
  SIGNAL(SIGINT, term );
  SIGNAL(SIGPIPE, catch_pipe );
#endif

#if __SSL__
  if (ssl_flag) res = run_ssl_service();
#endif
  
  for( ;; ) {

     init_bfplib_done = 0;
     print_message( "Wait in accept(..) [network]\n" );
  
     clen = sizeof(clientaddr);
     connfd = accept( listenfd, (struct sockaddr *)&clientaddr, (socklen_t *)&clen ); 
     if (term_flag == 1) break;
     if (connfd == -1) {
       print_error_message( "accept() failed!\n" );
       continue;
     }
     
     memset( client_ip_buf, 0, sizeof(client_ip_buf) );
     memcpy(  &inadr, &clientaddr.sin_addr.s_addr, 4 );
     p = inet_ntoa( inadr );
     if (p != NULL) 
       strncpy( client_ip_buf, p, sizeof(client_ip_buf) );
     if (verbose) {
       if (dmode) {
         snprintf( msg_buf, sizeof(msg_buf), "connection opened for [%s:%d]\n",
                   client_ip_buf, clientaddr.sin_port );
         print_message( msg_buf );
       }
       else {
         if (verbose && (v_level >= V_LEVEL_DEBUG)) {
           print_message( "Accept...\n" );
           snprintf( msg_buf, sizeof(msg_buf),"Src addr size = %d bytes\n", clen );     
           print_message( msg_buf );
           snprintf( msg_buf, sizeof(msg_buf),"port = %d\n", clientaddr.sin_port );          
           print_message( msg_buf );
           snprintf( msg_buf, sizeof(msg_buf),"address = %s\n", client_ip_buf );
           print_message( msg_buf );
         }
       }
     }

#if defined(_WIN32)     
     tv1 = client_data_send_tmout * MS_PER_SECOND;
     res = setsockopt( connfd, SOL_SOCKET, SO_SNDTIMEO, (char *)&tv1, sizeof(tv1) );

     tv2 = client_data_recv_tmout * MS_PER_SECOND;
     res = setsockopt( connfd, SOL_SOCKET, SO_RCVTIMEO, (char *)&tv2, sizeof(tv2) );
#endif

     mincount = bfp_soft_param.model_size;
#if defined(_UNIX)
     memset( &tv, 0, sizeof(tv) );
     tv.tv_sec = client_data_send_tmout;
     tv.tv_usec = 0;
     res = setsockopt( connfd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv) );
     if (res == -1) {
       print_error_message( "Cannot set socket send timeout!\n" );
       goto error_done;
     }
     
     memset( &tv2, 0, sizeof(tv2) );
     tv2.tv_sec = client_data_recv_tmout;
     tv2.tv_usec = 0;
     res = setsockopt( connfd, SOL_SOCKET, SO_RCVTIMEO, &tv2, sizeof(tv2) );
     if (res == -1) {
       print_error_message( "Cannot set socket receive timeout!\n" );
       goto error_done;
     }

     res = setsockopt( connfd, SOL_SOCKET, SO_RCVLOWAT, &mincount, sizeof(mincount) );
     if (res == -1) {
       print_error_message( "Cannot set socket minimum count!\n" );
       goto error_done;
     }
#endif

     memset(pImagesMdl, 0, image_scan_size);

     /* Init library */
     res = bfp_init();
     if (res != 0) {
       print_error_message( "ERROR: bfp_init() failed!\n" );
       goto error_done;      
     }
     init_bfplib_done = 1;
     scanner_num = 0;
     
     /* Search for hardware */
     memset( &bfp_param, 0, sizeof(bfp_param) ); 
     res = bfp_get_hardware_info( &bfp_param, 0 );
     if (res != 0) {
       print_error_message( "ERROR: no scanners detected!\n" );
       goto error_done;      
     }
     if (user_scanner_num)
       scanner_num = user_scanner_num;
     else 
       scanner_num = (bfp_param.serial_num_high<<16)+
                     (bfp_param.serial_num_mid<<8)+
                     (bfp_param.serial_num_low);
     snprintf( msg_buf, sizeof(msg_buf),
               "scanner_num = %lu\n", scanner_num );
     print_message( msg_buf );

     print_message( "Lock access.\n" );
     
     /* Synchronize access to scanner */     
#if defined(_UNIX)
     res = pthread_mutex_lock( &access_scanner );
#endif
#if defined(_WIN32)
     res = 0;
     WaitForSingleObject( &h_access_scanner, INFINITE );
#endif
     if (res != 0) {
       snprintf( msg_buf, sizeof(msg_buf), 
                 "lock_scanner_access failed, code = %d\n", res );
       print_error_message( msg_buf );    
       goto error_done;
     }

     print_message( "Try to get image.\n" );     

     for( i=0; i<read_fp_tmout; i++ ) {
       memset( pImagesMdl, 0, image_scan_size );
       res = bfp_get_image_timeo( pImagesMdl, image_scan_size, 0, 0 );
       if (verbose && (v_level >= V_LEVEL_DEBUG)) {
         snprintf( msg_buf, sizeof(msg_buf), "%d: read_image_result = %d\n", i+1, res);
         print_message( msg_buf );
       }
       if (res == 0) break;
     }
     if (res != 0) {
       print_error_message( "Image capture failed!\n" );
#if defined(_UNIX)
       res = pthread_mutex_unlock( &access_scanner );
#endif
#if defined(_WIN32)
       res = 0;
       ReleaseMutex( &h_access_scanner);
#endif
       goto error_done;
     }

     print_message( "Transform image into model.\n" );
     
     memset(pModel, 0, n * bfp_soft_param.model_size);     
     model_size = 0;
     res = bfp_extract( pImagesMdl, n, pModel );
     if (res > 0) model_size = res;
     snprintf( msg_buf, sizeof(msg_buf), "build_model = %d\n", res);
     print_message( msg_buf );
     
     print_message( "Unlock access.\n" );     

#if defined(_WIN32)
    res = 0;
    ReleaseMutex( &h_access_scanner);
#endif
#if defined(_UNIX)
     res = pthread_mutex_unlock( &access_scanner );
#endif
     if (res != 0) {
       snprintf( msg_buf, sizeof(msg_buf), 
                 "unlock_access_scanner failed, code = %d\n", res );
       print_error_message( msg_buf );    
     }     

#if defined(_WIN32)
     snprintf( msg_buf, sizeof(msg_buf),
               "scanner_num (Win32) = %lu\n", scanner_num );
     print_message( msg_buf );
#endif
     
     if (model_size > 0) {
       clen = sizeof(scanner_num);
       device_num = htonl(scanner_num);
#if defined(_WIN32)
       snprintf( msg_buf, sizeof(msg_buf),
                 "scanner_num = %lu (net), %lu (orig)\n", device_num, scanner_num );
       print_message( msg_buf );
#endif
       res = do_write( connfd, (char *)&device_num, clen, 0, client_data_send_tmout );
       if (res == -1) {
         print_error_message( "Error to send serial!\n" );
         goto error_done;
       }
       if (res != clen ) {
         snprintf( msg_buf, sizeof(msg_buf), "ERROR: Sent only %d bytes of serial!\n", res );
         print_error_message( msg_buf );
         goto error_done;
       }
       res = do_write( connfd, pModel, model_size, 0, client_data_send_tmout );
       if (res == -1) {
         print_error_message( "Error to send data!\n" );
         goto error_done;
       }
       if (res != model_size ) {
         snprintf( msg_buf, sizeof(msg_buf), "ERROR: Sent only %d bytes of model!\n", res );
         print_error_message( msg_buf );
         goto error_done;
       }
     }    
     print_message( "Model data sent successfully.\n" ); 

error_done:
     /* Free resources */
     if (init_bfplib_done) {
        init_bfplib_done = 0; 
        res = bfp_deinit();
     }
     if (pModel != NULL) memset( pModel, 0, n * bfp_soft_param.model_size );
     if (pImagesMdl != NULL) memset( pImagesMdl, 0, image_scan_size );
     CLOSE_SOCKET( connfd );
     print_message( "connection closed.\n" );

     print_message( "listen ... [network]\n" );
     
  }

  res = terminate_server();
    
  return(0);
}
