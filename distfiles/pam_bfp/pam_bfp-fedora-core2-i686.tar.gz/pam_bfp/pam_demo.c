/*
 * Copyright (c) 2004
 *	Dmitry V. Stefankov.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the Author
 *      Dmitry V. Stefankov and its contributors.
 * 4. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/*
  Based on source code taken from Linux-PAM doc and examples:
  contributed by Shane Watts <shane@icarus.bofh.asn.au>
  slight modifications by AGM.
 */


#define  __TEST_ACCOUNT_ACCESS__   0


#include <sys/param.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pwd.h>
#include <security/pam_appl.h>


int login_conv(int, const struct pam_message **,
            struct pam_response **, void *);

static struct pam_conv conv = { login_conv, NULL };


int main(int argc, char *argv[])
{
    pam_handle_t *pamh=NULL;
    int retval;
    const char *user="nobody";

    if(argc < 2) {
        fprintf(stderr, "Usage: %s [username]\n", argv[0]);
        exit(1);
    }

    user = argv[1];
    
    retval = pam_start("login", user, &conv, &pamh);
        
    if (retval == PAM_SUCCESS)
        retval = pam_authenticate(pamh, 0);    /* is user really user? */

#if __TEST_ACCOUNT_ACCESS__
    if (retval == PAM_SUCCESS)
        retval = pam_acct_mgmt(pamh, 0);       /* permitted access? */
#endif

    /* This is where we have been authorized or not. */

    if (retval == PAM_SUCCESS) {
        fprintf(stdout, "Authenticated\n");
    } else {
        fprintf(stdout, "Not Authenticated\n");
    }

    if (pam_end(pamh,retval) != PAM_SUCCESS) {     /* close Linux-PAM */
        pamh = NULL;
        fprintf(stderr, "login: failed to release authenticator\n");
        exit(1);
    }

    return ( retval == PAM_SUCCESS ? 0:1 );       /* indicate success */
}


int
login_conv(int num_msg, const struct pam_message **msg,
        struct pam_response **resp, void *appdata)
{
        struct pam_response * reply;
        int count = 0;

        reply = (struct pam_response *) calloc( num_msg, sizeof(struct pam_response) );
        if (reply == NULL) return PAM_CONV_ERR;
        
        while ( num_msg-- )
        {
                char * string = NULL;        
        
                switch(msg[count]->msg_style) {

                case PAM_PROMPT_ECHO_ON:
                     fprintf(stdout, "%s", msg[count]->msg);
                     reply[count].resp = (char *)malloc(PAM_MAX_RESP_SIZE);
                     reply[count].resp_retcode = 0;
                     fgets(reply[count].resp, PAM_MAX_RESP_SIZE-1, stdin);
                     break;

                case PAM_PROMPT_ECHO_OFF:
		     string = strdup(getpass( msg[count]->msg ));
	             if (string == NULL) {
	                 free(reply);
		         return PAM_CONV_ERR;
	             }
                     break;

                case PAM_ERROR_MSG:
                     fprintf(stderr, "%s\n", msg[count]->msg);
                     break;

                case PAM_TEXT_INFO:
                     fprintf(stdout, "%s\n", msg[count]->msg);
                     break;

                default:
                     break;
                }
                if (string != NULL) {
	             reply[count].resp = string;
	             reply[count].resp_retcode = 0;
	             string = NULL;
                }
                count++;
        }
        *resp = reply;
        reply = NULL;
        
        return PAM_SUCCESS;
}
