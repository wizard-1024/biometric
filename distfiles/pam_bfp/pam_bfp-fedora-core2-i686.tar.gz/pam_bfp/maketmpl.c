/*
 * Copyright (c) 2004
 *	Dmitry V. Stefankov.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the Author
 *      Dmitry V. Stefankov and its contributors.
 * 4. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */


#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <math.h>

#include <bfpsdk.h>

#if __CRYPT__
#include "cryptcode.h"
#endif

/* Write template file for given user by images scanning */
/* Almost all code was borrowed from BFP SDK sample */

int main(int argc, char **argv)
{
 int               do_encrypt = 0;
 int               i;
 unsigned char   * lpMapA = NULL;
 unsigned char   * lpMapB = NULL; 
 long              l = 0;
 long              n = 1;
 int               res;
 long              tmpl_size;
 struct bfp_hardware_info  bfp_hw_param; 
 struct bfp_software_info  bfp_soft_param;
 int               IMG_SCAN_SIZE;
 int               timeout = 15;
 int               max_images_num = 0;
 unsigned char   * pImagesTmpl = NULL;
 unsigned char   * pImagesMdl  = NULL;
 unsigned char   * lpMapEncA = NULL;
 FILE            * fp;
 unsigned int      oursize = 0;
 unsigned int      newsize = 0;
 char            * secret = NULL;
 char              verify_s[32];
 
 if (argc < 2) {
   fprintf( stderr, "Usage: %s user.tmpl [-k|-p]\n", argv[0] );
   return(1);
 }
 
 // Init library
 res = bfp_init();
 if (res != 0) {
   fprintf( stderr, "bfp_init() failed, code=%d\n", res );
   return(1);
 }

 if (argc > 2) {
   if (strcmp(argv[2],"-k") == 0) do_encrypt=1;
   if (strcmp(argv[2],"-p") == 0) do_encrypt=2;   
 }
 
 
 // Detect hardware presence
 memset( &bfp_hw_param, 0, sizeof(bfp_hw_param) );
 res = bfp_get_hardware_info( &bfp_hw_param, 0 );
 if (res != 0) {
   fprintf( stderr, "bfp_get_hardware_param() failed, code=%d\n", res );
   return(1);
 }

 // Get library constants
 memset( &bfp_soft_param, 0, sizeof(bfp_soft_param) );
 res = bfp_get_software_info( &bfp_soft_param );
 if (res != 0) {
   fprintf( stderr, "bfp_get_software_info() failed, code=%d\n", res );
   return(1);
 }

 
 max_images_num = bfp_soft_param.samples_num;
 IMG_SCAN_SIZE = bfp_soft_param.image_size;

 // Allocate memory
 l = bfp_soft_param.max_models;
 if((lpMapA = (unsigned char *)malloc(l * bfp_soft_param.model_size)) == NULL)
    {printf("Not enough memory!"); goto final;}
 memset(lpMapA, 0, l * bfp_soft_param.model_size);

 n = 1;
 if((lpMapB = (unsigned char *)malloc(n * bfp_soft_param.model_size)) == NULL)
    {printf("Not enough memory!"); goto final;}
 memset(lpMapB, 0, n * bfp_soft_param.model_size);
 
 pImagesTmpl = malloc(max_images_num*IMG_SCAN_SIZE);
 if (pImagesTmpl == NULL) {
   printf( "Not enough memory for images buffer (template)!\n" );
   goto final;
 }
 memset( pImagesTmpl, 0, max_images_num*IMG_SCAN_SIZE );

 pImagesMdl = malloc(n*IMG_SCAN_SIZE);
 if (pImagesMdl == NULL) {
   printf( "Not enough memory for images buffer (model)!\n" );
   goto final;
 }
 memset( pImagesMdl, 0, n*IMG_SCAN_SIZE );

 if (do_encrypt == 2) {
      secret = getpass( "enter secret: " );     
      strncpy( verify_s, secret, sizeof(verify_s) );
      secret = getpass( "enter secret again: " );
      res = strcmp(secret,verify_s);
      if (res != 0) {
        fprintf( stderr, "Mismatched secrets.\n" );
        goto final;
      }
 }

 // Read N images from scanner
 printf( "Get images for template.\n" );
 for( i=0; i<max_images_num; i++ ) {
   printf( "Put your finger on scanner.\n" );
   res = bfp_get_image_timeo( pImagesTmpl+(i*IMG_SCAN_SIZE), IMG_SCAN_SIZE, timeout, 0 );
   if (res != 0) {
         printf( "ERROR: cannot get fingerprint image from scanner!\n" );
         return(1);
   }
   printf( "Take your finger off scanner. Image %d.\n", i );
   sleep(1);
 }

 // Build template from images
 printf("Build template.\n");
 tmpl_size = bfp_extract(pImagesTmpl,max_images_num , lpMapA);
 printf("template_size = %lu\n", tmpl_size );

#if __CRYPT__
  if ((do_encrypt == 1) || (do_encrypt == 2)) {
    oursize = tmpl_size+64;
    if((lpMapEncA = (unsigned char *)malloc(oursize)) == NULL)
       {printf("Not enough memory!"); goto final;}
    memset(lpMapEncA, 0, oursize);
    newsize = blowfish_encrypt( lpMapA, tmpl_size,
                                lpMapEncA, oursize, secret );
    printf("new_template_size = %d\n", newsize );	       
  }  
#endif

 fp = fopen( argv[1], "wb");
 if (fp != NULL) {
   if (do_encrypt == 0) {
     fwrite( lpMapA, tmpl_size, 1, fp );
   }
   if ((do_encrypt == 1) || (do_encrypt == 2)) {
     if ((lpMapEncA != NULL) && newsize && oursize) 
       fwrite( lpMapEncA, newsize, 1, fp );
   }
   fclose(fp);
 }
 
final:
 // Cleanup 
 if (secret != NULL) memset( secret, 0, strlen(secret) );
 if (verify_s != NULL) memset( verify_s, 0, strlen(verify_s) );
 if ( lpMapEncA != NULL) {
   free(lpMapEncA);
 }
 if (lpMapA != NULL) {
   memset(lpMapA, 0, l * bfp_soft_param.model_size);
   free(lpMapA);
 }
 if (pImagesTmpl != NULL) {
   memset( pImagesTmpl, 0, max_images_num*IMG_SCAN_SIZE );
   free(pImagesTmpl);
 }
 if (lpMapB != NULL) { 
   memset(lpMapB, 0, n * bfp_soft_param.model_size);
   free(lpMapB);  
 }
 if (pImagesMdl != NULL) {
   memset( pImagesMdl, 0, n*IMG_SCAN_SIZE );
   free(pImagesMdl);
 }
 
 // Exit library
 res = bfp_deinit();
  
 return 0;
}
