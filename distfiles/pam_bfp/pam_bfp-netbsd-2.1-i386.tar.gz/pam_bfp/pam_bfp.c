/*
 * Copyright (c) 2004
 *	Dmitry V. Stefankov.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the Author
 *      Dmitry V. Stefankov and its contributors.
 * 4. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */


#if __linux__
#define  _GNU_SOURCE
#endif

#include <sys/cdefs.h>
#include <libgen.h>
#include <sys/types.h>
#include <sys/param.h>
#include <stdio.h>
#include <stdarg.h>
#include <unistd.h>
#include <stdlib.h>
#include <syslog.h>
#include <ctype.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#define PAM_SM_AUTH
#include <security/pam_appl.h>
#include <security/pam_modules.h>
#if __linux__
//#include <security/pam_misc.h>
#endif
#if __FreeBSD__
#include <security/pam_mod_misc.h>
#if __FreeBSD_version >= 503001
#include <security/openpam.h>
#endif
#endif

//#include <security/pam_mod_misc.h>
#include <security/openpam.h>

#if __SSL__
#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#endif

#if __BFPSERVER__
#include <bfpserver.h>
#endif

#include <bfpsdk.h>
#include "netcode.h"

#if __CRYPT__
#include "cryptcode.h"
#endif

/* Additional PAM modules */

#if __linux__
/* Standard options
 */
enum opt { PAM_OPT_DEBUG, PAM_OPT_NO_WARN, PAM_OPT_ECHO_PASS,
	PAM_OPT_USE_FIRST_PASS, PAM_OPT_TRY_FIRST_PASS, PAM_OPT_USE_MAPPED_PASS,
	PAM_OPT_TRY_MAPPED_PASS, PAM_OPT_EXPOSE_ACCOUNT,
	PAM_OPT_STD_MAX /* XXX */ };

#define PAM_MAX_OPTIONS	32

struct opttab {
	const char *name;
	int value;
};

struct options {
	struct {
		const char *name;
		int bool;
		char *arg;
	} opt[PAM_MAX_OPTIONS];
};
#endif

#if __FreeBSD_version >= 503001
#define  PAM_OPT_TMPL_DIR      "tmpldir"
#define  PAM_OPT_CFG_FILE      "cfgfile"
#define  PAM_OPT_FP_PROMPT     "fp_prompt"
#else
enum {
	PAM_OPT_TMPL_DIR = PAM_OPT_STD_MAX,
	PAM_OPT_CFG_FILE,
	PAM_OPT_FP_PROMPT,
};

static struct opttab other_options[] = {
	{ "tmpldir", 	PAM_OPT_TMPL_DIR },
	{ "cfgfile",    PAM_OPT_CFG_FILE },   
	{ "fp_prompt",  PAM_OPT_FP_PROMPT },
	{ NULL, 0 }
};

struct options   options;
#endif

#define  MAX_FP_AUTH_NUM   128

#define  AUTH_MODE_LOCAL     1
#define  AUTH_MODE_SERVER    2

struct fp_auth_param
{
  int    local;
  int    level;
  int    auth_mode;
  int    fp_timeout;
  int    display_remote_device;
  int    ssl_flag;
  int    ssl_verify_flag;
  int    ssl_decrypt_flag;
  char   ssl_cacert_file[256];
  char   ssl_cert_file[256];
  char   ssl_privkey_file[256];
  char   ssl_privkey_pass[128];
  char   account[32];
  char   device_address[64];
  char   device_port[8];
  char   bfpserver_address[64];
  char   bfpserver_port[8];
  char   users_list[256];
};

int entries_num = 0;
struct fp_auth_param  ConfigEntries[MAX_FP_AUTH_NUM];
	
/* Use local or remote scanner */
#define  AUTH_LOCAL    1
#define  AUTH_REMOTE   0

/* Default catalogs and files */
char  def_tmpl_dir[] = "/usr/local/etc/auth_pam_bfp"; 
char  def_cfg_file[] = "/usr/local/etc/auth_pam_bfp/auth_bfp.conf";

char   * tmpl_dir = NULL;
char   * conf_file = NULL;
	
/* Miscellaneous */
int disp_fp_prompt = 0;
char * fp_prompt_display = NULL;

/* Server-client */	
int  client_connect_tmout = 10;
int  client_data_send_tmout = 15;
int  client_data_recv_tmout = 15;

/* Buffers */
unsigned char   * pImagesMdl  = NULL;
unsigned char   * pModel = NULL;
unsigned char   * pTmpl = NULL;

/* Real user template */
char * real_user = NULL; 
#if __BFPSERVER__          
char store_user_name[128];
#endif

/* Authentication type (local/network) */
char logon_type[64];

/* tcp port */
char def_srv_port[] = "5775";
char ssl_def_srv_port[] = "5776";

/* SSL protocol support */
#if __SSL__
SSL_CTX* ctx = NULL;
SSL*     ssl = NULL;
char def_cert_file[]    = "/usr/local/etc/auth_pam_bfp/client.pem";
char def_privkey_file[] = "/usr/local/etc/auth_pam_bfp/client.pem";
char def_cacert_file[]  = "/usr/local/etc/auth_pam_bfp/cacert.pem";
#endif

#if __CRYPT__
#define  CRYPTO_BUF_SIZE  32768
unsigned char pEncBuf[CRYPTO_BUF_SIZE];
unsigned char pDecBuf[CRYPTO_BUF_SIZE];
#endif

/* Missing functions */
#if __linux__

struct opttab std_options[PAM_MAX_OPTIONS] = {
	{ "debug",		PAM_OPT_DEBUG },
	{ "no_warn",		PAM_OPT_NO_WARN },
	{ "echo_pass",		PAM_OPT_ECHO_PASS },
	{ "use_first_pass",	PAM_OPT_USE_FIRST_PASS },
	{ "try_first_pass",	PAM_OPT_TRY_FIRST_PASS },
	{ "use_mapped_pass",	PAM_OPT_USE_MAPPED_PASS },
	{ "try_mapped_pass",	PAM_OPT_TRY_MAPPED_PASS },
	{ "expose_account",	PAM_OPT_EXPOSE_ACCOUNT },
	{ NULL,			0 }
};

/* Populate the options structure, syslogging all errors */
void
pam_std_option(struct options *options, struct opttab other_options[],
    int argc, const char *argv[])
{
	struct opttab *oo;
	int i, j, std, extra, arglen, found;

	std = 1;
	extra = 1;
	oo = other_options;
	for (i = 0; i < PAM_MAX_OPTIONS; i++) {
		if (std && std_options[i].name == NULL)
			std = 0;
		else if (extra && (oo == NULL || oo->name == NULL))
			extra = 0;

		if (std)
			options->opt[i].name = std_options[i].name;
		else if (extra) {
			if (oo->value != i)
				syslog(LOG_DEBUG, "Extra option fault: %d %d",
				    oo->value, i);
			options->opt[i].name = oo->name;
			oo++;
		}
		else
			options->opt[i].name = NULL;

		options->opt[i].bool = 0;
		options->opt[i].arg = NULL;
	}

	for (j = 0; j < argc; j++) {
#ifdef DEBUG
		syslog(LOG_DEBUG, "Doing arg %s", argv[j]);
#endif
		found = 0;
		for (i = 0; i < PAM_MAX_OPTIONS; i++) {
			if (options->opt[i].name == NULL)
				break;
			arglen = strlen(options->opt[i].name);
			if (strcmp(argv[j], options->opt[i].name) == 0) {
				options->opt[i].bool = 1;
				found = 1;
				break;
			}
			else if (strncmp(argv[j], options->opt[i].name, arglen)
			    == 0 && argv[j][arglen] == '=')  {
				options->opt[i].bool = 1;
				options->opt[i].arg
				    = strdup(&argv[j][arglen + 1]);
				found = 1;
				break;
			}
		}
		if (!found)
			syslog(LOG_WARNING, "PAM option: %s invalid", argv[j]);
	}
}

/* Test if option is set in options */
int
pam_test_option(struct options *options, enum opt option, char **arg)
{
	if (arg != NULL)
		*arg = options->opt[option].arg;
	return options->opt[option].bool;
}

/* Set option in options, errors to syslog */
void
pam_set_option(struct options *options, enum opt option)
{
	if (option < PAM_OPT_STD_MAX)
		options->opt[option].bool = 1;
#ifdef DEBUG
	else
		syslog(LOG_DEBUG, "PAM options: attempt to set option %d",
		    option);
#endif
}

/* Clear option in options, errors to syslog */
void
pam_clear_option(struct options *options, enum opt option)
{
	if (option < PAM_OPT_STD_MAX)
		options->opt[option].bool = 0;
#ifdef DEBUG
	else
		syslog(LOG_DEBUG, "PAM options: attempt to clear option %d",
		    option);
#endif
}


static char *modulename(const char *);

/* Log a debug message, including the function name and a
 * cleaned up filename.
 */
void
_pam_log(struct options *options, const char *file, const char *function,
    const char *format, ...)
{
	va_list ap;
	char *fmtbuf, *modname;

	if (pam_test_option(options, PAM_OPT_DEBUG, NULL)) {
		modname = modulename(file);
		va_start(ap, format);
		asprintf(&fmtbuf, "%s: %s: %s", modname, function, format);
		vsyslog(LOG_DEBUG, fmtbuf, ap);
		free(fmtbuf);
		va_end(ap);
	}
}

static char *
modulename(const char *file)
{
	char *modname, *period;

	modname = strdup(basename((char *)file));
	period = strchr(modname, '.');
	if (period != NULL)
		*period = '\0';

	return modname;
}

#define  PAM_LOG( args...)  _pam_log(&options, __FILE__, __FUNCTION__, ##args )

#endif


/* Supplemental functions */

#if !defined(filelength)
long filelength(int fd) 
{
  long cur_pos;
  long file_size;
  
  cur_pos = lseek(fd,0,SEEK_CUR);
  file_size = lseek(fd,0,SEEK_END);
  lseek(fd,cur_pos,SEEK_SET);
  return(file_size);
}
#endif


/*
 * Syntax parser simple function
 * ( name=value or name="value1 value2" )
 */
int get_elem_value( char * name, char *buf, int buflen, 
                    char ** valbuf, int * valsize )
{
   int       retcode = -1;
   int       len = buflen;
   int       count = 0;
   int       mult_values = 0;
   char    * cp;
   char    * p;
   char    * s;
   
   if ((buf == NULL) || (valsize == NULL) || (buflen == 0) || (valbuf == NULL)) 
     return(retcode);
   
   cp = buf;
   len = buflen;

   /* Remove leading delimiters */
   while( isspace(*cp) && len--) cp++;
   
   /* Skip token name */
   p = strstr( cp, name );
   if (p == NULL) {
     retcode = -2;
     goto done;
   } 
   
   cp = p + strlen(name);
   len -= strlen(name);

   /* Skip equal sign */
   if (*cp != '=') {
     retcode = -3;
     goto done;     
   }
   cp++;
   len--;

   /* Check for multiples values */
   if (*cp == '"') {
     mult_values = 1;
     cp++;
     len--;
   }
   
   /* Find element word size */
   if (mult_values) {
     s = cp;
     s++;
     p = strchr( s, '"');
     if (p == NULL) {
       retcode = -4;
       goto done;
     }
     count = p - cp;
   }
   else {
     p = cp;
     while( len-- && *p && !isspace(*p)) { p++, count++; }
   }

   *valbuf = cp;
   *valsize = count;
   retcode = 0;

done:      
   return( retcode );
}


/* Close and shutdown all */
void shutdown_lib( int ssl_flag )
{
  int res;
  
  if (pImagesMdl != NULL) { 
    free(pImagesMdl);
    pImagesMdl = NULL;
  }
  if (pModel != NULL) {
    free(pModel);
    pModel = NULL;
  }
  if (pTmpl != NULL) {
    free(pTmpl);
    pTmpl = NULL;
  }
  res = bfp_deinit();          
#if __SSL__
  if (ssl_flag) {
    if (ssl != NULL) {
      SSL_free (ssl);
      ssl = NULL;
    }
    if (ctx != NULL) {
      SSL_CTX_free (ctx);
      ctx = NULL;
    }
  }
#endif  
}

#if __SSL__
int verify_callback( int ok, X509_STORE_CTX * ctx )
{
  PAM_LOG("verify_ok=%d\n", ok );
  
  return(ok);
}
#endif


/* Biometric authentication for given users list */
int do_user_bio_auth( struct fp_auth_param * p_fp_auth_info )
{
        int               func_res = -1;
	int               res;
	int               model_size = 0;
	int               tmpl_size = 0;
        int               n = 1;	
        u_long            scanner_num = 0;
        u_long            device_num;
        long int          image_scan_size;
        struct bfp_hardware_info  bfp_param;
        struct bfp_software_info  bfp_soft_param;        
        char              filename[512];
        FILE            * fp;
        char            * user;
        char            * p;
        int               connfd;
        struct sockaddr_in  server;
        int               clen;
        int               mincount;
        char              users_list[256];
        char            * ssl_cert_file = NULL;
        char            * ssl_privkey_file = NULL;
	char            * ssl_privkey_pass = NULL;
        char            * ssl_cacert_file = NULL;
#if __SSL__
        int               err = 0;
        X509*             server_cert;
        char*             str;
        SSL_METHOD       *meth;
        long int          result;
        long              ssl_options;        
#endif
#if __BFPSERVER__
        struct bfpserver_parameters   server_params;
        struct person_info            person_request;
        struct person_info            person_answer;
        struct data_record            pam_bfp_dat_rec;
        struct data_record          * p_rec;
        int                           retcode; 
#endif

        if (p_fp_auth_info == NULL) {
          syslog(LOG_ERR,"empty fp_auth_info found.");       
          return(func_res);         
        }
        
        if (p_fp_auth_info->users_list[0] == '\0') {
          syslog(LOG_ERR,"empty users list found.");       
          return(func_res); 
        }

	/* Test user templates presence */
	if (p_fp_auth_info->auth_mode & AUTH_MODE_LOCAL) {
	  memcpy( users_list, p_fp_auth_info->users_list, sizeof(users_list) );
	  p = users_list;
	  user = strsep( &p," ," );
	  mincount = 0;
	  while( user != NULL) {
	    snprintf( filename, sizeof(filename)-1, "%s/%s.tmpl",
	              tmpl_dir, user );
	    PAM_LOG( "template=%s", filename );
	    fp = fopen( filename, "rb" );
	    if (fp != NULL) {
	      mincount++;
	      fclose(fp);
	    }          
	    user = strsep( &p," ," );
	  }
	  PAM_LOG( "tmpl_files_count=%d", mincount );
	  if (mincount) {
	    PAM_LOG( "Templates found. OK." );
	  }
	  else {
	    PAM_LOG( "NO templates found. Disable local auth." );
	    p_fp_auth_info->auth_mode &= ~AUTH_MODE_LOCAL;
	  }
	}

#if __SSL__
          if (p_fp_auth_info->ssl_flag) {
            PAM_LOG("use SSL");
            err = 0;
            SSLeay_add_ssl_algorithms();
            meth = SSLv23_client_method();
            SSL_load_error_strings();
            ctx = SSL_CTX_new (meth);                        
            if (ctx == NULL) {
              syslog( LOG_ERR, "SSL ctx allocation failed.");
	      goto done;
            }
            ssl_options = SSL_CTX_get_options(ctx);
            ssl_options |= SSL_OP_NO_SSLv2;
            SSL_CTX_set_options( ctx, ssl_options );
            /* Load user's parameters */
            if (p_fp_auth_info->ssl_cacert_file[0] != '\0')
              ssl_cacert_file = p_fp_auth_info->ssl_cacert_file;
            if (p_fp_auth_info->ssl_cert_file[0] != '\0')
              ssl_cert_file = p_fp_auth_info->ssl_cert_file;              
            if (p_fp_auth_info->ssl_privkey_file[0] != '\0')
              ssl_privkey_file = p_fp_auth_info->ssl_privkey_file;              
            if (p_fp_auth_info->ssl_privkey_pass[0] != '\0')
              ssl_privkey_pass = p_fp_auth_info->ssl_privkey_pass;              
            if (p_fp_auth_info->ssl_verify_flag) {
              if ((ssl_cert_file == NULL) && (ssl_privkey_file != NULL))
                ssl_cert_file = ssl_privkey_file;
              if ((ssl_cert_file != NULL) && (ssl_privkey_file == NULL))
                 ssl_privkey_file = ssl_cert_file;
              if (ssl_cert_file == NULL) ssl_cert_file = def_cert_file;
              if (SSL_CTX_use_certificate_file(ctx, ssl_cert_file, SSL_FILETYPE_PEM) <= 0) {
                syslog( LOG_ERR, "Cannot load client certificate.");
		goto done;
              }
              PAM_LOG("Client certificate loaded.");	      
              if (ssl_privkey_file == NULL) ssl_privkey_file = def_privkey_file;    
	      if (ssl_privkey_pass != NULL) 
	        SSL_CTX_set_default_passwd_cb_userdata( ctx, ssl_privkey_pass );
              if (SSL_CTX_use_PrivateKey_file(ctx, ssl_privkey_file, SSL_FILETYPE_PEM) <= 0) {
                syslog( LOG_ERR, "Cannot load client private key.");              
		goto done;
              }
              PAM_LOG("Client private key loaded.");	      	      
              if (!SSL_CTX_check_private_key(ctx)) {
                syslog( LOG_ERR,"Private key does not match the certificate public key.\n");
		goto done;
              }
              if (ssl_cacert_file == NULL) ssl_cacert_file = def_cacert_file;
              if (!SSL_CTX_load_verify_locations( ctx, ssl_cacert_file, 
                              getenv(X509_get_default_cert_dir_env()) )) {
                syslog( LOG_ERR, "Cannot load CA certificate.");              
		goto done;
              }    
              PAM_LOG("CA certificate loaded.");	      	      
            }
          }
#endif

#if __BFPSERVER__
	if (p_fp_auth_info->auth_mode & AUTH_MODE_SERVER) {
          if (p_fp_auth_info->bfpserver_port[0] == '\0') {
	    if (p_fp_auth_info->ssl_flag) 
	        strcpy( p_fp_auth_info->bfpserver_port, BFPSERVER_SSL_PORT );          	  
	    else
                strcpy( p_fp_auth_info->bfpserver_port, BFPSERVER_PORT );          	  
          }
          PAM_LOG("server:port=%s:%s",p_fp_auth_info->bfpserver_address, 
                                      p_fp_auth_info->bfpserver_port);                    
          PAM_LOG( "Test bfpserver presence" );                                                
          memset( &server_params, 0, sizeof(server_params) );
          server_params.server_ip_address = p_fp_auth_info->bfpserver_address;
          server_params.server_tcp_port = p_fp_auth_info->bfpserver_port;
          server_params.server_send_tmout = -1;
          server_params.server_recv_tmout = -1;
          if (p_fp_auth_info->ssl_flag) {
            server_params.net_mode = NET_MODE_OPENSSL;
            server_params.ssl_verify_flag = p_fp_auth_info->ssl_verify_flag;
            server_params.cert_file = ssl_cert_file;
            server_params.privkey_file = ssl_privkey_file;
	    server_params.privkey_pass = ssl_privkey_pass;
            server_params.ca_cert_file = ssl_cacert_file;
          }
          else {
            server_params.net_mode = NET_MODE_OPEN;
            server_params.ssl_verify_flag = 0;
            server_params.cert_file = NULL;
            server_params.privkey_file = NULL;
	    server_params.privkey_pass = NULL;
            server_params.ca_cert_file = NULL;
          }
          retcode = bfpserver_check_ready( &server_params );
          PAM_LOG( "server_result=%d", retcode );                                                         
          if (retcode == SRV_BFP_ERR_OK) {
            PAM_LOG( "Server found OK.\n" );
          }
          else {
            PAM_LOG( "Server not found. Disable network auth." );
            p_fp_auth_info->auth_mode &= ~AUTH_MODE_SERVER;
          }
        }
#endif

	if ((p_fp_auth_info->auth_mode & 
	    (AUTH_MODE_SERVER|AUTH_MODE_LOCAL)) == 0) {
	  PAM_LOG( "No local or network mode found ready. Exit.\n" );
	  return(1);
	}

        /* Init library */
        res = bfp_init();
        if (res != 0) {
          syslog(LOG_ERR,"bfp_init() failed");       
          return(func_res); 
        }

        /* Check local hardware */
        if (p_fp_auth_info->local ==  AUTH_LOCAL) {
          memset( &bfp_param, 0, sizeof(bfp_param) ); 
          res = bfp_get_hardware_info( &bfp_param, 0 );
          if (res != 0) {
            syslog( LOG_ERR, "no scanners detected" );
	    goto done;
          }
          PAM_LOG("hardware found");
          scanner_num = (bfp_param.serial_num_high<<16)+
                        (bfp_param.serial_num_mid<<8)+
                        (bfp_param.serial_num_low);
          //scanner_num = 0;
          PAM_LOG("local_scanner_num=%lu", scanner_num);              
        }
        
        /* Get library constants to init buffers */
        memset( &bfp_soft_param, 0, sizeof(bfp_soft_param) );
        res = bfp_get_software_info( &bfp_soft_param );
        if (res != 0) {
          syslog( LOG_ERR, "bfp_get_software_param() failed, code=%d\n", res );
	  goto done;
        }

        PAM_LOG("software options got");        

        image_scan_size = bfp_soft_param.image_size;        
        tmpl_size = bfp_soft_param.total_size;
        
        /* Allocate buffers space */
        
        pModel = (unsigned char *)malloc(n * bfp_soft_param.model_size);
        if (pModel == NULL) {
          syslog( LOG_ERR, "model memory allocation failed.");
	  goto done;
        }
        memset(pModel, 0, n * bfp_soft_param.model_size);

        pTmpl = (unsigned char *)malloc(tmpl_size);
        if (pTmpl == NULL) {
          syslog( LOG_ERR, "template memory allocation failed.");
	  goto done;
        }
        memset(pTmpl, 0, tmpl_size);

        res = -1;
        model_size = 0;
        
        /* Get image from local scanner and extract model */
        if (p_fp_auth_info->local ==  AUTH_LOCAL) {
          pImagesMdl = malloc(n*image_scan_size);
          if (pImagesMdl == NULL) {
            syslog( LOG_ERR, "image memory allocation failed.");
	    goto done;
          }
          if (disp_fp_prompt) printf( "Put your finger on local scanner.\n" );
          PAM_LOG("read image");
          res = bfp_get_image_timeo( pImagesMdl, image_scan_size, 
                                     p_fp_auth_info->fp_timeout, 0 );
          PAM_LOG("read_image_result=%d", res);
          if (res == 0) {
	    res = bfp_extract( pImagesMdl, n, pModel );
	    if (res > 0) model_size = res;
	    PAM_LOG("bfp_extract=%d",res);
	    res = 0;
	  }
        }

        /* Scan image on remote scanner, extract and get model */        
	if (p_fp_auth_info->local ==  AUTH_REMOTE) {
	  PAM_LOG("try remote scanner");

          if (p_fp_auth_info->device_address[0] == '\0') {
            syslog( LOG_ERR, "no devicename present.");
	    goto done;
          }

          if (p_fp_auth_info->device_port[0] == '\0') {
            if (p_fp_auth_info->ssl_flag) strcpy( p_fp_auth_info->device_port, ssl_def_srv_port );          	  
            else strcpy( p_fp_auth_info->device_port, def_srv_port );          	  
          }
          PAM_LOG("device:port=%s:%s",p_fp_auth_info->device_address, 
                                      p_fp_auth_info->device_port);                    
          
          /* Make socket */
          connfd = socket( AF_INET, SOCK_STREAM, 0);
          if (connfd == -1) {
            syslog( LOG_ERR, "socket() failure.");
	    goto done;
          }
                                     
          server.sin_addr.s_addr = inet_addr( p_fp_auth_info->device_address );
          server.sin_family = AF_INET;
          server.sin_port = htons( (u_short)atol( p_fp_auth_info->device_port ) );

          /* Connect to server */
          res = connect_nonb( connfd, (struct sockaddr *)&server, 
                              sizeof(struct sockaddr_in), client_connect_tmout );
          if (res == -1) {
            syslog( LOG_ERR, "connect_nonb() failure.");
            close( connfd );
	    goto done;
          }

          res = set_send_timeo( connfd, client_data_send_tmout );
            if (res != 0) {
              syslog( LOG_ERR, "set_send_timeo() failure. code=%d", res );
              close( connfd );
              goto done;           
          }

          res = set_recv_timeo( connfd, client_data_recv_tmout );
            if (res != 0) {
              syslog( LOG_ERR, "set_recv_timeo() failure. code=%d", res );
              close( connfd );
              goto done;           
          }

#if __SSL__
          if (p_fp_auth_info->ssl_flag) {
            /* Now we have TCP connection. Start SSL negotiation. */
            ssl = SSL_new (ctx);                         
            if (ssl == NULL) {
              syslog( LOG_ERR, "new SSL allocation failed.");
              close( connfd );
	      goto done;
            }
            SSL_set_fd (ssl, connfd);
            err = SSL_connect (ssl);                     
            if (err == -1) {
              ERR_print_errors_fp(stderr);
              syslog( LOG_ERR, "SSL connect error.");
              close( connfd );              
	      goto done;
            }

            if (p_fp_auth_info->ssl_verify_flag) {
              SSL_set_verify( ssl, SSL_VERIFY_PEER, verify_callback );                
            }
                        
            /* Following two steps are optional and not required for
               data exchange to be successful. */
            /* Get the cipher - opt */
            PAM_LOG("SSL connection using %s\n", SSL_get_cipher (ssl));
            
            /* Get server's certificate (note: beware of dynamic allocation) - opt */
            server_cert = SSL_get_peer_certificate (ssl);       
            if (server_cert != NULL) {
                PAM_LOG("Device certificate:\n");
                str = X509_NAME_oneline (X509_get_subject_name (server_cert),0,0);
                if (str != NULL) {
                  PAM_LOG("subject: %s\n", str);
                  OPENSSL_free (str);
                }
                str = X509_NAME_oneline (X509_get_issuer_name  (server_cert),0,0);
                if (str != NULL) {
                  PAM_LOG("issuer: %s\n", str);
                  OPENSSL_free (str);
                }
                /* We could do all sorts of certificate verification stuff here before
                deallocating the certificate. */
                X509_free (server_cert);
            }
            if (p_fp_auth_info->ssl_verify_flag) {
              result = SSL_get_verify_result( ssl );
              PAM_LOG( "verify_result=%ld\n", result );
              if ((server_cert != NULL) && (result == X509_V_OK)) {
                PAM_LOG( "Device verification OK.\n" );
              }
              else {
                syslog( LOG_ERR, "Device verification failed.\n" );
                close( connfd );              
		goto done;
              }
            }
          }  
#endif

          clen = n * bfp_soft_param.model_size;
          memset( pModel, 0, clen );

          if (disp_fp_prompt) {
            printf( "Put your finger on remote scanner" );
	    if (p_fp_auth_info->display_remote_device) 
              printf( " (%s).\n", p_fp_auth_info->device_address );          
	    else	    
	      printf( ".\n" );
          }
	  
          /* Get model from remote server */
          if (p_fp_auth_info->ssl_flag == 0) {
#if 0	  
            /* Set watermark to receive */
            mincount = sizeof(device_num);
            res = setsockopt( connfd, SOL_SOCKET, SO_RCVLOWAT, &mincount, sizeof(mincount) );
            if (res == -1) {
              syslog( LOG_ERR, "setsockopt() failure.");
              close( connfd );
              goto done;
            }
#endif	    
            res = do_read( connfd, (char *)&device_num, sizeof(device_num), 0, client_data_recv_tmout );
            if (res != sizeof(device_num)) {
              syslog( LOG_ERR, "do_read() failure. code1=%d", res );
              close( connfd );
              goto done;
            }
            /* Set watermark to receive */
            mincount = clen;
#if 0	    
            res = setsockopt( connfd, SOL_SOCKET, SO_RCVLOWAT, &mincount, sizeof(mincount) );
            if (res == -1) {
              syslog( LOG_ERR, "setsockopt() failure.");
              close( connfd );
              goto done;
            }
#endif            
            res = do_read( connfd, pModel, clen, 0, client_data_recv_tmout );
            if (res != clen) {
              syslog( LOG_ERR, "do_read() failure. code2=%d", res );
              close( connfd );
              goto done;
            }
          }
#if __SSL__
          if (p_fp_auth_info->ssl_flag) {
            /* DATA EXCHANGE */
            err = SSL_read( ssl, &device_num, sizeof(device_num) );
            res = err;
            if (err == -1) {
              ERR_print_errors_fp(stderr);
              syslog( LOG_ERR, "SSL read error (serial).");
              close( connfd );              
              goto done;
            }           
            err = SSL_read (ssl, pModel, clen);
            res = err;
            if (err == -1) {
              ERR_print_errors_fp(stderr);
              syslog( LOG_ERR, "SSL read error (model).");
              close( connfd );              
              goto done;
            }
            PAM_LOG("SSL-> got %d bytes\n", err);
            SSL_shutdown (ssl);  /* send SSL/TLS close_notify */
          }
#endif          
          model_size = res;          
          PAM_LOG( "got %d data bytes", model_size );          
          res = 0;
          scanner_num = ntohl(device_num);
          PAM_LOG("remote_scanner_num=%lu", scanner_num);
            
          /* Close connection */
          close( connfd );	  
	}

#if __BFPSERVER__
	if ((res == 0) && (model_size > 0) && 
	    (p_fp_auth_info->auth_mode & AUTH_MODE_SERVER)) {
          if (p_fp_auth_info->bfpserver_port[0] == '\0') {
            strcpy( p_fp_auth_info->bfpserver_port, BFPSERVER_PORT );          	  
          }
          PAM_LOG("server:port=%s:%s",p_fp_auth_info->bfpserver_address, 
                                      p_fp_auth_info->bfpserver_port);                    
          PAM_LOG("scanner_num=%lu", scanner_num );
          PAM_LOG( "Authenticate on bfpserver" );                                                
          memset( &server_params, 0, sizeof(server_params) );
          server_params.server_ip_address = p_fp_auth_info->bfpserver_address;
          server_params.server_tcp_port = p_fp_auth_info->bfpserver_port;
          server_params.server_send_tmout = -1;
          server_params.server_recv_tmout = -1;
          if (p_fp_auth_info->ssl_flag) {
            server_params.net_mode = NET_MODE_OPENSSL;
            server_params.ssl_verify_flag = p_fp_auth_info->ssl_verify_flag;
            server_params.cert_file = ssl_cert_file;
            server_params.privkey_file = ssl_privkey_file;
	    server_params.privkey_pass = ssl_privkey_pass;
            server_params.ca_cert_file = ssl_cacert_file;
          }
          else {
            server_params.net_mode = NET_MODE_OPEN;
            server_params.ssl_verify_flag = 0;
            server_params.cert_file = NULL;
            server_params.privkey_file = NULL;
	    server_params.privkey_pass = NULL;
            server_params.ca_cert_file = NULL;
          }
          memset( &person_request, 0, sizeof(person_request) );
          memset( &person_answer, 0, sizeof(person_answer) );          
          person_request.options |= OPT_GET_PERSON_DATA;
          person_request.person_id = 0;
          person_request.person_bfp_size = model_size;
          person_request.p_person_bfp = pModel; 
          pam_bfp_dat_rec.data_rec_type = DATA_REC_TYPE_PAM_BFP_ACCOUNT;
          pam_bfp_dat_rec.data_rec_size = 0;
          person_request.person_data_size = sizeof(pam_bfp_dat_rec);
          person_request.p_person_data = (u_char *)&pam_bfp_dat_rec;
          person_request.device_num = scanner_num;
          retcode = bfpserver_identify_person( &server_params, p_fp_auth_info->level,
                                               &person_request, &person_answer );
          PAM_LOG( "server_auth_result=%d", retcode );                                                         
          if (retcode == SRV_BFP_ERR_OK) {
            PAM_LOG( "server_person_id=%lu\n", person_answer.person_id );
	    
	    memset( store_user_name, 0, sizeof(store_user_name) );
	    if (person_answer.person_data_size && (person_answer.p_person_data != NULL)) {
	      PAM_LOG( "server: got %lu data bytes", person_answer.person_data_size );
	      p_rec =(p_data_record) person_answer.p_person_data;
	      p = (u_char *)p_rec;
	      p += sizeof(struct data_record);
	      memcpy( store_user_name, p, p_rec->data_rec_size );
	      PAM_LOG( "server: user_name=%s", store_user_name );
	      real_user = store_user_name;
	      p = strstr( p_fp_auth_info->users_list, real_user );
	      if (p != NULL) {
	        PAM_LOG( "server: this_user_found_in_list" );
	        strncpy( logon_type, "network", sizeof(logon_type)-1);	    
	        PAM_LOG( "server: auth_ok" );
	        func_res = 0;
	        goto done;
	      }
	      PAM_LOG( "server: this_user_not_in_list" );
            }	    
	    PAM_LOG( "server: user_name_unknown" );
          }                                     
          else {
            PAM_LOG( "server: auth_error" );
          }
        }
#endif
	
	/* If model OK then compare against user templates */
	if ((res == 0) && (model_size > 0) && 
	    (p_fp_auth_info->auth_mode & AUTH_MODE_LOCAL)) {
	  p = p_fp_auth_info->users_list;
	  user = strsep( &p," ," );
	  while( user != NULL) {
	    snprintf( filename, sizeof(filename)-1, "%s/%s.tmpl",
	              tmpl_dir, user );
	    PAM_LOG( "template=%s", filename );          
	    fp = fopen( filename, "rb" );
	    if (fp != NULL) {
#if __CRYPT__
              if ((p_fp_auth_info->ssl_decrypt_flag == 1) || 
                  (p_fp_auth_info->ssl_decrypt_flag == 2)) {
	        char *secret = NULL;	      
		unsigned int filelen;
                res = 0;
	        if (p_fp_auth_info->ssl_decrypt_flag == 2) {
	          secret = getpass( "enter secret: ");
	        }
		filelen = filelength(fileno(fp));
		if (filelen > sizeof(pEncBuf)) filelen = sizeof(pEncBuf);
 	        res = fread( pEncBuf, 1, filelen, fp );	      
	        PAM_LOG("read %d bytes",res);	      
		memset( pTmpl, 0, tmpl_size );
	        res = blowfish_decrypt( pEncBuf, res, pDecBuf, sizeof(pDecBuf), 
	                                secret );
		if (res > 0) memcpy( pTmpl, pDecBuf, res );			
		PAM_LOG("%02x,%02x\n",*pEncBuf,*(pEncBuf+1) );
		PAM_LOG("%02x,%02x\n",*pDecBuf,*(pDecBuf+1) );		
		memset( pEncBuf, 0, filelen );
		memset( pDecBuf, 0, res );		
		if (secret != NULL) memset( secret, 0, strlen(secret) );
	        PAM_LOG("decrypted %d bytes",res );	        
	      }
#endif
              if (p_fp_auth_info->ssl_decrypt_flag == 0) {
 	        res = fread( pTmpl, 1, tmpl_size, fp );	      
	        PAM_LOG("read %d bytes",res);	      
	      }
	      if ((res > 0) && (res < (tmpl_size+64))){
	        res = bfp_match( pTmpl, res, pModel, model_size );
	        PAM_LOG( "measure = %d", res );
		if (res > p_fp_auth_info->level) {
	          func_res = 0;
	          real_user = user;
	          PAM_LOG( "auth_ok" );
	          strncpy( logon_type, "local", sizeof(logon_type)-1);
	        }
		else {
		  PAM_LOG( "auth_error" );
		}
	      }
	      fclose(fp);
	      if (func_res == 0) goto done;
	    }          
	    user = strsep( &p," ," );
	  }
	}
	
done:	
   if (pTmpl != NULL) memset(pTmpl, 0, tmpl_size); 
   if (pModel != NULL) memset(pModel, 0, n * bfp_soft_param.model_size);
   shutdown_lib(p_fp_auth_info->ssl_flag);

   return(func_res);
}


/*
  Configuration file processing
*/
int process_config_file( const char * config, const char * this_account, 
                         const char * this_host )
{
  int   func_res = -1;
  FILE  * fp;
  char  buf[512];
  int   found;
  int   len;
  int   res;
  char  * cp;
  char  * item;
  int   item_len;
  char  * host;
  char  * p;
  char  my_server_address[128];
  char  my_host[64];
  char  from_host[64];
  struct fp_auth_param fp_auth_info;
  char  clients_list[512];

  if (this_account == NULL) {
    syslog(LOG_ERR,"pam_bfp: null account not supported." );            
    return(func_res);
  }

  entries_num = 0;
  
  PAM_LOG( "config=%s", config );  

  fp = fopen( config, "r" );
  if (fp != NULL) {

    PAM_LOG("file opened ok");  
    
    while( fgets(buf,sizeof(buf),fp) != NULL) {
      len = strlen(buf);    
      if (len < 3) continue;
      if (buf[0] == '#') continue;
      cp = buf;

      memset( &fp_auth_info, 0, sizeof(fp_auth_info) );      
      
      /* defaults */
      fp_auth_info.level = 400;
      fp_auth_info.fp_timeout = 5;
      fp_auth_info.auth_mode = AUTH_MODE_LOCAL;
      fp_auth_info.display_remote_device = 0;
  
      item_len = 0;
      item = NULL;
      res = get_elem_value( "account", cp, strlen(cp), &item, &item_len );
      if (item_len) {
        if ( item_len > (sizeof(fp_auth_info.account)-1) ) item_len = sizeof(fp_auth_info.account)-1;
        memcpy( fp_auth_info.account, item, item_len );
	PAM_LOG( "account=%s, this_account=%s", fp_auth_info.account, this_account );  
        if (strcmp(fp_auth_info.account, this_account) != 0) {
          PAM_LOG("not our account.");
          continue;
        } 
      }

      item_len = 0;
      item = NULL;
      res = get_elem_value( "users", cp, strlen(cp), &item, &item_len );
      if (item_len) {
        if ( item_len > (sizeof(fp_auth_info.users_list)-1) ) 
          item_len = sizeof(fp_auth_info.users_list)-1;
        memcpy( &fp_auth_info.users_list, item, item_len );
        PAM_LOG("users=%s", fp_auth_info.users_list );
      }
      else {
        PAM_LOG("empty users list found.");
        continue;
      }

      item_len = 0;
      item = NULL;
      res = get_elem_value( "local", cp, strlen(cp), &item, &item_len );
      if (item_len) {
        fp_auth_info.local = atoi(item);
	PAM_LOG( "local=%d", fp_auth_info.local );  
      }

      item_len = 0;
      item = NULL;
      res = get_elem_value( "timeout", cp, strlen(cp), &item, &item_len );
      if (item_len) {
        fp_auth_info.fp_timeout = atoi(item);
        PAM_LOG("timeout=%d", fp_auth_info.fp_timeout );
      }

      item_len = 0;
      item = NULL;
      res = get_elem_value( "authmode", cp, strlen(cp), &item, &item_len );
      if (item_len) {
        fp_auth_info.auth_mode = atoi(item);
        PAM_LOG("authmode=%d", fp_auth_info.auth_mode );
      }

      item_len = 0;
      item = NULL;
      res = get_elem_value( "level", cp, strlen(cp), &item, &item_len );
      if (item_len) {
        fp_auth_info.level = atoi(item);
        PAM_LOG("level=%d", fp_auth_info.level );
      }

      item_len = 0;
      item = NULL;
      res = get_elem_value( "decrypt", cp, strlen(cp), &item, &item_len );
      if (item_len) {
        fp_auth_info.ssl_decrypt_flag = atoi(item);
        PAM_LOG("ssl_decrypt_flag=%d", fp_auth_info.ssl_decrypt_flag );
      }

      item_len = 0;
      item = NULL;
      res = get_elem_value( "cafile", cp, strlen(cp), &item, &item_len );
      if (item_len) {
        if ( item_len > (sizeof(fp_auth_info.ssl_cacert_file)-1) ) 
          item_len = sizeof(fp_auth_info.ssl_cacert_file)-1;
        memcpy( &fp_auth_info.ssl_cacert_file, item, item_len );
        PAM_LOG("cacertf=%s", fp_auth_info.ssl_cacert_file );
      }

      item_len = 0;
      item = NULL;
      res = get_elem_value( "certfile", cp, strlen(cp), &item, &item_len );
      if (item_len) {
        if ( item_len > (sizeof(fp_auth_info.ssl_cert_file)-1) ) 
          item_len = sizeof(fp_auth_info.ssl_cert_file)-1;
        memcpy( &fp_auth_info.ssl_cert_file, item, item_len );
        PAM_LOG("certf=%s", fp_auth_info.ssl_cert_file );
      }

      item_len = 0;
      item = NULL;
      res = get_elem_value( "keyfile", cp, strlen(cp), &item, &item_len );
      if (item_len) {
        if ( item_len > (sizeof(fp_auth_info.ssl_privkey_file)-1) ) 
          item_len = sizeof(fp_auth_info.ssl_privkey_file)-1;
        memcpy( &fp_auth_info.ssl_privkey_file, item, item_len );
        PAM_LOG("privkeyf=%s", fp_auth_info.ssl_privkey_file );
      }

      item_len = 0;
      item = NULL;
      res = get_elem_value( "keypass", cp, strlen(cp), &item, &item_len );
      if (item_len) {
        if ( item_len > (sizeof(fp_auth_info.ssl_privkey_pass)-1) ) 
          item_len = sizeof(fp_auth_info.ssl_privkey_pass)-1;
        memcpy( &fp_auth_info.ssl_privkey_pass, item, item_len );
        PAM_LOG("privkeyp=%s", fp_auth_info.ssl_privkey_pass );
      }

      item_len = 0;
      item = NULL;
      res = get_elem_value( "server", cp, strlen(cp), &item, &item_len );
      if (item_len) {
          memset( my_server_address, 0, sizeof(my_server_address) );
          if ( item_len > (sizeof(my_server_address)-1) ) item_len = sizeof(my_server_address)-1;
          memcpy( my_server_address, item, item_len );
	  PAM_LOG( "server_name=%s", my_server_address );  
          res = resolve_name( my_server_address, sizeof(my_server_address),
                              fp_auth_info.bfpserver_address, 
                              sizeof(fp_auth_info.bfpserver_address) );
          if (res != 0) {
            syslog(LOG_ERR,"pam_bfp: cannot resolve servername" );          
            continue;
          }
          PAM_LOG( "server_ip=%s", fp_auth_info.bfpserver_address );            
      }

      item_len = 0;
      item = NULL;
      res = get_elem_value( "sport", cp, strlen(cp), &item, &item_len );
      if (item_len) {
          if ( item_len > (sizeof(fp_auth_info.bfpserver_port)-1) ) 
             item_len = sizeof(fp_auth_info.bfpserver_port)-1;
          memcpy( fp_auth_info.bfpserver_port, item, item_len );
	  PAM_LOG( "sport=%s", fp_auth_info.bfpserver_port );  
      }

      item_len = 0;
      item = NULL;
      res = get_elem_value( "ssl", cp, strlen(cp), &item, &item_len );
      if (item_len) {
          fp_auth_info.ssl_flag = atoi(item);
	  PAM_LOG( "ssl=%d", fp_auth_info.ssl_flag );  
      }

      item_len = 0;
      item = NULL;
      res = get_elem_value( "verify", cp, strlen(cp), &item, &item_len );
      if (item_len) {
          fp_auth_info.ssl_verify_flag = atoi(item);
          PAM_LOG("ssl_verify_flag=%d", fp_auth_info.ssl_verify_flag );
      }

      if (fp_auth_info.local == AUTH_REMOTE) {

        item_len = 0;
        item = NULL;
        res = get_elem_value( "disp_rem_dev", cp, strlen(cp), &item, &item_len );
        if (item_len) {
          fp_auth_info.display_remote_device = atoi(item);
	  PAM_LOG( "disp_rem_dev=%d", fp_auth_info.display_remote_device );  
        }

        item_len = 0;
        item = NULL;
        res = get_elem_value( "device", cp, strlen(cp), &item, &item_len );
        if (item_len) {
          memset( my_server_address, 0, sizeof(my_server_address) );
          if ( item_len > (sizeof(my_server_address)-1) ) item_len = sizeof(my_server_address)-1;
          memcpy( my_server_address, item, item_len );
	  PAM_LOG( "device_name=%s", my_server_address );  
          res = resolve_name( my_server_address, sizeof(my_server_address),
                              fp_auth_info.device_address, 
                              sizeof(fp_auth_info.device_address) );
          if (res != 0) {
            syslog(LOG_ERR,"pam_bfp: cannot resolve devicename" );          
            continue;
          }
          PAM_LOG( "device_ip=%s", fp_auth_info.device_address );            
        }
        else {
          syslog( LOG_ERR, "pam_bfp: no device in line: %s\n", cp );
          continue;
        }

        item_len = 0;
        item = NULL;
        res = get_elem_value( "dport", cp, strlen(cp), &item, &item_len );
        if (item_len) {
          if ( item_len > (sizeof(fp_auth_info.device_port)-1) ) 
             item_len = sizeof(fp_auth_info.device_port)-1;
          memcpy( fp_auth_info.device_port, item, item_len );
	  PAM_LOG( "dport=%s", fp_auth_info.device_port );  
        }

        item_len = 0;
        item = NULL;
        res = get_elem_value( "clients", cp, strlen(cp), &item, &item_len );
        if (item_len && (this_host == NULL)) {
          PAM_LOG("host_is_empty and clients_is_non_empty, skip this.");
          continue;
        }
        if (item_len && (this_host != NULL)) {
          memset( clients_list, 0, sizeof(clients_list) );
          if ( item_len > (sizeof(clients_list)-1) ) item_len = sizeof(clients_list)-1;
          memcpy( clients_list, item, item_len );
          /* if clients and this_host are non-empty then search for match */
          PAM_LOG( "from_host=%s", this_host );
          res = resolve_name( this_host, strlen(this_host), from_host, sizeof(from_host) );
          if (res != 0) {
            syslog(LOG_ERR,"pam_bfp: cannot resolve from_host=%s", this_host );
            continue;
          }
          PAM_LOG( "from_host_ip=%s", from_host );	    
	  p = clients_list;
	  host = strsep( &p," ," );
	  found = 0;
	  while( host != NULL) {
            PAM_LOG( "next_host=%s", host );	    
	    res = resolve_name( host, strlen(host), my_host, sizeof(my_host) );
            PAM_LOG( "ip_host=%s", my_host );	    
	    if (res == 0) {
	      if (strcmp(my_host,from_host) == 0) {
	        found = 1;
	        break;
	      }
	    }
	    host = strsep( &p," ," );
          }
          if (found == 0) {
            PAM_LOG("no match_entry found" );          
            continue;
          }
          PAM_LOG("match_entry found" );          
        }

      }

      PAM_LOG( "add this line to run." );
      
      if (entries_num < MAX_FP_AUTH_NUM) {
        memcpy( &ConfigEntries[entries_num],&fp_auth_info,
                sizeof(struct fp_auth_param) );
        entries_num++;
      }
      else {
        PAM_LOG("config_run_table is full.");
      }
    }

    PAM_LOG( "config done" );    
    fclose(fp);
  }

  PAM_LOG( "%d entries to run.",entries_num);
  if (entries_num)  func_res = 0;

  PAM_LOG("result=%d", func_res );  
  return(func_res);
}


/* Standard PAM authentication functions */

PAM_EXTERN int
pam_sm_authenticate(pam_handle_t *pamh, int flags, int argc,
    const char **argv)
{
        int              auth_ok = 0;
	int              retval;
	const void       *item;
	const char       *user;
	const char       *tty;
	const char       *rhost;
	int              res;
	int              i;
	
        /* Standard and other options processing */
#if __FreeBSD_version >= 503001		
        // nothing
#else
	pam_std_option(&options, other_options, argc, argv);
#endif

	tmpl_dir = NULL;
#if __FreeBSD_version >= 503001
        tmpl_dir = openpam_get_option( pamh, PAM_OPT_TMPL_DIR );
#else
	pam_test_option(&options, PAM_OPT_TMPL_DIR, &tmpl_dir);
#endif	
	if (tmpl_dir == NULL) tmpl_dir = def_tmpl_dir;

	conf_file = NULL;
#if __FreeBSD_version >= 503001	
        conf_file = openpam_get_option( pamh, PAM_OPT_CFG_FILE );
#else
	pam_test_option(&options, PAM_OPT_CFG_FILE, &conf_file);
#endif
	if (conf_file == NULL) conf_file = def_cfg_file;

        fp_prompt_display = NULL;
#if __FreeBSD_version >= 503001		
        fp_prompt_display = openpam_get_option( pamh, PAM_OPT_FP_PROMPT );
#else	
	pam_test_option(&options, PAM_OPT_FP_PROMPT, &fp_prompt_display);
#endif		
	if (fp_prompt_display != NULL) disp_fp_prompt = atoi(fp_prompt_display);

	PAM_LOG("Options processed");	

        /* Get user credentials */	
        
	if ((retval = pam_get_user(pamh, &user, NULL)) != PAM_SUCCESS) {
           return retval;
	}
	if ((retval = pam_get_item(pamh, PAM_TTY, &item)) != PAM_SUCCESS) {
		return retval;
        }
	tty = (const char *)item;
	if ((retval = pam_get_item(pamh, PAM_RHOST, &item)) != PAM_SUCCESS) {
		return retval;
	}
	rhost = (const char *)item;
	PAM_LOG("user=%s,tty=%s,host=%s",user,tty,rhost); 

	
        /* Try authentication  */
        PAM_LOG("process_config()"); 
        res = process_config_file( conf_file, user, rhost );
        if (res == 0) {
	  for( i=0; i<entries_num; i++ ) {
	    PAM_LOG("do_auth_this_run_line %d.",i); 
	    memset( logon_type, 0, sizeof(logon_type) );
	    auth_ok = do_user_bio_auth( &ConfigEntries[i] );
	    if (auth_ok == 0) {
	      syslog( LOG_INFO, "biometric %s authentication ok for %s as %s", logon_type, real_user, user );
	      return PAM_SUCCESS;
	    }
	  }
	}
        
        /* Biometric authentication error then use standed Unix schemes */	
        
	syslog(LOG_ERR,"biometric authentication unsuccessful"); 
	return PAM_AUTH_ERR; 
}


PAM_EXTERN int
pam_sm_setcred(pam_handle_t *pamh, int flags, int argc, const char **argv)
{
#if __FreeBSD_version >= 503001		
        // nothing
#else
	pam_std_option(&options, NULL, argc, argv);
#endif

	PAM_LOG("Options processed");
	
	PAM_LOG("success");

	return PAM_SUCCESS;
}

#ifdef PAM_MODULE_ENTRY
PAM_MODULE_ENTRY("pam_bfp");
#endif
