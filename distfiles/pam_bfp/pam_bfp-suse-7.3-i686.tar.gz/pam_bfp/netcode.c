/*-
 * Copyright (c) 2004
 *	Dmitry V. Stefankov.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the Author
 *      Dmitry V. Stefankov and its contributors.
 * 4. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#if defined(_UNIX)
#include  <sys/types.h>
#include  <sys/param.h>
#include  <unistd.h>
#include  <sys/socket.h>
#include  <sys/time.h>
#include  <sys/stat.h>
#include  <ctype.h>
#include  <stdlib.h>
#include  <string.h>
#include  <stdio.h>
#include  <fcntl.h>
#include  <netinet/in.h>
#include  <arpa/inet.h>
#include  <sys/wait.h>
#include  <time.h>
#include  <errno.h>
#include  <netdb.h>
#endif

#if defined(_WIN32)
#include  <windows.h>
#include  <stdlib.h>
#include  <string.h>
#include  <stdio.h>
#include  <fcntl.h>
#include  <errno.h>
#include  <ctype.h>
#include  <winsock.h>
#include  <time.h>
#endif

#if __SSL__
#include  <openssl/ssl.h>
#endif

#include  "defs.h"

int      connect_on_select = 1;
int      send_on_select = 1;
int      receive_on_select = 1;

/*
 * Check for ip address/name presence
 */
int is_ip_addr( const char * str )
{
  int      res = -1;
  int      len;
  char     ch;
  
  len = strlen(str);
  
  if ((str == NULL) || (len == 0))
    return(res);
  
  while( len-- ) {
    ch = *str++;
    if (!isdigit(ch) && (ch != '.'))
      return(res);
  }
  res = 0;
  
  return( res );
} 

 
/*
 * Resolve dns name
 */
char * name2ip( const char * name )
{
  struct hostent *      he = NULL;
  struct in_addr        in_addr;
  char *  p = NULL;

  if (name == NULL) return(p);

  he = gethostbyname( name );
  if (he != NULL) {
      memcpy ( &in_addr, he->h_addr, he->h_length );
      p = inet_ntoa( in_addr );
  }

  return( p );
}


/*
  Resolve canonical name 
*/
int resolve_name( const char * iname, int isize, char * oname, int osize )
{
  int    func_res = -1;
  int    res;
  char   *p; 
  
  if ((iname == NULL) || (isize < 1) || (oname == NULL) || (osize < 1))
    return(func_res);  

  memset( oname, 0, osize );
  
  res = is_ip_addr( iname );
  if (res == 0) {
    strncpy( oname, iname, osize-1 );
    func_res = 0;
    goto done;
  }
  
  p = name2ip( iname );  
  if (p != NULL) {
    strncpy( oname, p, osize-1);
    func_res = 0;
    goto done;
  }
  
done:    
  return(func_res);  
}


#if defined(_UNIX)
/*
 * Test sockets set for read/write ready
 */
int isconnected( int s, fd_set *rd, fd_set *wr, fd_set *ex )
{
  int err;
  int len = sizeof(err);
  
  errno = 0;
  if (!FD_ISSET(s,rd) && !FD_ISSET(s,wr)) 
    return 0;
  
  if (getsockopt( s, SOL_SOCKET, SO_ERROR, &err, &len) < 0)
    return 0;
    
  errno = err;
  return( err == 0);
}
#endif


#if defined(_WIN32)
/*
 * Test sockets set for read/write ready
 */
int isconnected( int s, fd_set *rd, fd_set *wr, fd_set *ex )
{
  WSASetLastError( 0 );
  if ( !FD_ISSET( s, rd ) && !FD_ISSET( s, wr ) ) {
    return 0;
  }
  if ( FD_ISSET( s, ex ) ) {
    return 0;
  }
  return 1;
}
#endif


/*
 * Connect with a Timeout using SELECT
 */
int connect_nonb( int sockfd, const struct sockaddr * pserver, socklen_t salen, int nsec )
{
  int  error;
  int  res;
  fd_set rset;
  fd_set wset;
  fd_set eset;  
  struct timeval tval;
#if defined(_WIN32)
  unsigned long int nbmode;
#endif
#if defined(_UNIX)
  int  flags;
#endif

#if defined(_WIN32)
  nbmode = 1;
  error = ioctlsocket( sockfd, FIONBIO, &nbmode );
  if (error == SOCKET_ERROR) return(-1);
#endif
#if defined(_UNIX)
  flags = fcntl( sockfd,F_GETFL,0);
  error = fcntl( sockfd, F_SETFL, flags | O_NONBLOCK);
  if (error == -1) return(-1);
#endif
  
  error = 0;
  res = connect( sockfd,(const struct sockaddr *) pserver, salen);
  if (res == -1) {
#if defined(_WIN32)    
    errno = WSAGetLastError();
    if ((errno != WSAEINPROGRESS) && (errno != WSAEWOULDBLOCK)) return(-1);
#endif
#if defined(_UNIX)
    if (errno != EINPROGRESS) return(-1);
#endif
  }

  if (res == 0) goto done;

  FD_ZERO( &rset );
  FD_SET( sockfd, &rset );
  wset = rset;
  eset = rset;
  memset( &tval, 0, sizeof(tval) );
  tval.tv_sec = nsec;
  tval.tv_usec = 0;

  res = select( sockfd+1, &rset, &wset, &eset, &tval );
  if (res == -1) {
    CLOSE_SOCKET( sockfd );
    return(-1);
  }
  if (res == 0) {
    CLOSE_SOCKET( sockfd );
#if defined(_WIN32)    
    errno = WSAETIMEDOUT;
#endif
#if defined(_UNIX)
    errno = ETIMEDOUT;
#endif
    return(-1);
  }

  if (!isconnected(sockfd,&rset,&wset,&eset)) {
    CLOSE_SOCKET( sockfd );
    return(-1);
  }
  
done:  
#if defined(_WIN32)
  nbmode = 0;
  error = ioctlsocket( sockfd, FIONBIO, &nbmode );
#endif
#if defined(_UNIX)
  fcntl( sockfd, F_SETFL, flags );
#endif
  
  if (error) {
    CLOSE_SOCKET( sockfd );
    errno = error;
    return(-1);
  }
  
  return(0);
}

 
/*
 * Receive data using select() as timeout
 */
int  readable_timeo( int sockfd, int nsec )
{
  fd_set          readfds;
  struct timeval  tv_read;
  int             rc;
  int             retcode = -1;

  FD_ZERO( &readfds );
  FD_SET( sockfd, &readfds );
  
  memset( &tv_read, 0, sizeof(tv_read) );
  tv_read.tv_sec = nsec;
  tv_read.tv_usec = 0;
  
  for( ;; ) {
     rc = select( sockfd+1, &readfds, NULL, NULL, &tv_read );
     if (rc == -1) break;
     if (rc == 0) break;
     if (rc > 0) {
        retcode = 0;
        break;
     }
     if (!FD_ISSET( sockfd, &readfds) ) break;
   }

  return(retcode);
}


/*
 * Send data using select() as timeout
 */
int  writeable_timeo( int sockfd, int nsec )
{
  fd_set          writefds;
  struct timeval  tv_write;
  int             rc;
  int             retcode = -1;

  FD_ZERO( &writefds );
  FD_SET( sockfd, &writefds );
  
  memset( &tv_write, 0, sizeof(tv_write) );
  tv_write.tv_sec = nsec;
  tv_write.tv_usec = 0;
  
  for( ;; ) {
     rc = select( sockfd+1, NULL, &writefds, NULL, &tv_write );
     if (rc == -1) break;
     if (rc == 0) break;
     if (rc > 0) {
        retcode = 0;
        break;
     }
     if (!FD_ISSET( sockfd, &writefds) ) break;
   }

  return(retcode);
}


/*
 * Read operation
 */
int do_read( int sockfd, char * buf, int len, int flags, int timeout )
{
  int         res = -1;
  int         maxlen = len;
  int         reslen = 0;  
  
  while( maxlen ) {
    if (receive_on_select) {
      if (readable_timeo( sockfd, timeout ) != 0) goto done;
    }
    res = recv( sockfd, buf, maxlen, flags );
    if (res == -1) goto done;    
    if (res == 0) {
      res = reslen;
      goto done;
    }
    if (res > 0) { 
      maxlen -= res; 
      buf += res;
      reslen += res;      
    }
  }
  res = reslen;  

done:
  return(res);
}


/*
 * Write operation
 */
int do_write( int sockfd, char * buf, int len, int flags, int timeout )
{
  int         res = -1;
  int         maxlen = len;
  int         reslen = 0;
  
  while( maxlen ) {
    if (send_on_select) {
      if (writeable_timeo( sockfd, timeout ) != 0) goto done;
    }
    res = send( sockfd, buf, maxlen, flags );
    if (res== -1) goto done;    
    if (res == 0) {
      res = reslen;
      goto done;
    }
    if (res > 0) { 
      maxlen -= res; 
      buf += res;
      reslen += res;
    }
  }
  res = reslen;

done:
  return(res);
}


/*
 * Set socket receive timeout
 */
int set_recv_timeo( int sockfd, int timeout )
{
  int              res;
#if defined(_UNIX)
  struct timeval   tv_r;
#endif
#if defined(_WIN32)
  int                   tv_r;
#endif

#if defined(_WIN32)
  memset( &tv_r, 0, sizeof(tv_r) );  
  tv_r = timeout * MS_PER_SECOND;
  res = setsockopt( sockfd, SOL_SOCKET, SO_SNDTIMEO, (char *)&tv_r, sizeof(tv_r) );
#endif
  
#if defined(_UNIX)
  memset( &tv_r, 0, sizeof(tv_r) );
  tv_r.tv_sec = timeout;
  tv_r.tv_usec = 0;
  res = setsockopt( sockfd, SOL_SOCKET, SO_RCVTIMEO, &tv_r, sizeof(tv_r) );
#endif
  
  return(res);
}


/*
 * Set socket send timeout
 */
int set_send_timeo( int sockfd, int timeout )
{
  int              res;
#if defined(_UNIX)
  struct timeval   tv_s;
#endif
#if defined(_WIN32)
  int                   tv_s;
#endif
  
#if defined(_UNIX)
  memset( &tv_s, 0, sizeof(tv_s) );
  tv_s.tv_sec = timeout;
  tv_s.tv_usec = 0;
  res = setsockopt( sockfd, SOL_SOCKET, SO_RCVTIMEO, &tv_s, sizeof(tv_s) );
#endif

#if defined(_WIN32)
  memset( &tv_s, 0, sizeof(tv_s) );  
  tv_s = timeout * MS_PER_SECOND;
  res = setsockopt( sockfd, SOL_SOCKET, SO_SNDTIMEO, (char *)&tv_s, sizeof(tv_s) );
#endif
  
  return(res);
}
