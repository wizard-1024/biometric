/*
 * Copyright (c) 2004
 *	Dmitry V. Stefankov.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the Author
 *      Dmitry V. Stefankov and its contributors.
 * 4. Neither the name of the Author nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */


#if __CRYPT__

#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <sys/stat.h>

#include <openssl/evp.h>
#include "cryptcode.h"

unsigned char bf_key[] = {18,205,122,37,48,175,66,70,188,129,102,11,132,83,134,165};
unsigned char bf_iv[] = {81,12,143,69,195,206,7,158};
unsigned char bf_key_pw[] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };

int blowfish_encrypt 
( unsigned char * ibuf, unsigned int ibufsiz,
  unsigned char * obuf, unsigned int obufsiz,
  char *pw )
{
  int outlen, tmplen;
  EVP_CIPHER_CTX ctx;

  if ((obufsiz == 0) || (ibufsiz == 0)) return(0);
  if ((ibuf == NULL) || (obuf == NULL)) return(0);
  
  EVP_CIPHER_CTX_init(&ctx);
  if (pw == NULL) {
    EVP_EncryptInit_ex(&ctx, EVP_bf_cbc(), NULL, bf_key, bf_iv);
    }
  else {
    EVP_MD_CTX mdctx;
    const EVP_MD *md;
    unsigned char md_value[EVP_MAX_MD_SIZE];
    int md_len;
  
    memset( bf_key_pw, 0, sizeof(bf_key_pw) );  
    
    OpenSSL_add_all_digests();  
    md = EVP_get_digestbyname("md5");
    if(!md) {
      printf("Unknown message digest: md5.");
      return(0);
    }
    EVP_MD_CTX_init(&mdctx);
    EVP_DigestInit_ex(&mdctx, md, NULL);
    EVP_DigestUpdate(&mdctx, pw, strlen(pw));
    EVP_DigestFinal_ex(&mdctx, md_value, &md_len);
    EVP_MD_CTX_cleanup(&mdctx);
#if 0    
    {
      int i;
      printf("Digest is: ");
      for(i = 0; i < md_len; i++) printf("%02x", md_value[i]);
      printf("\n");
    }
#endif
    memcpy( bf_key_pw, md_value, sizeof(bf_key_pw) );    
    EVP_EncryptInit_ex(&ctx, EVP_bf_cbc(), NULL, bf_key_pw, bf_iv);
  }
  
  if (!EVP_EncryptUpdate(&ctx, obuf, &outlen, ibuf, ibufsiz))
  {
    /* Error */
    memset( bf_key_pw, 0, sizeof(bf_key_pw) );  
    return 0;
  }
  
  /* Buffer passed to EVP_EncryptFinal() must be after data just
   * encrypted to avoid overwriting it.
   */
  if (!EVP_EncryptFinal_ex(&ctx, obuf + outlen, &tmplen))
  {
    /* Error */
    memset( bf_key_pw, 0, sizeof(bf_key_pw) );  
    return 0;
  }
  outlen += tmplen;
  
  EVP_CIPHER_CTX_cleanup(&ctx);
  
  memset( bf_key_pw, 0, sizeof(bf_key_pw) );  
  
  return(outlen);
}


int blowfish_decrypt 
( unsigned char * ibuf, unsigned int ibufsiz,
  unsigned char * obuf, unsigned int obufsiz,
  char *pw )
{
  int outlen, tmplen;
  EVP_CIPHER_CTX ctx;

  if ((obufsiz == 0) || (ibufsiz == 0)) return(0);
  if ((ibuf == NULL) || (obuf == NULL)) return(0);
  
  EVP_CIPHER_CTX_init(&ctx);
  if (pw == NULL) {
    EVP_DecryptInit_ex(&ctx, EVP_bf_cbc(), NULL, bf_key, bf_iv);  
    }
  else {
    EVP_MD_CTX mdctx;
    const EVP_MD *md;
    unsigned char md_value[EVP_MAX_MD_SIZE];
    int md_len;
  
    memset( bf_key_pw, 0, sizeof(bf_key_pw) );  
    
    OpenSSL_add_all_digests();  
    md = EVP_get_digestbyname("md5");
    if(!md) {
      printf("Unknown message digest: md5.");
      return(0);
    }
    EVP_MD_CTX_init(&mdctx);
    EVP_DigestInit_ex(&mdctx, md, NULL);
    EVP_DigestUpdate(&mdctx, pw, strlen(pw));
    EVP_DigestFinal_ex(&mdctx, md_value, &md_len);
    EVP_MD_CTX_cleanup(&mdctx);
#if 0
    {
      int i;
      printf("Digest is: ");
      for(i = 0; i < md_len; i++) printf("%02x", md_value[i]);
      printf("\n");
    }
#endif
    memcpy( bf_key_pw, md_value, sizeof(bf_key_pw) );    
  
    EVP_DecryptInit_ex(&ctx, EVP_bf_cbc(), NULL, bf_key_pw, bf_iv);
  }

  if (!EVP_DecryptUpdate(&ctx, obuf, &outlen, ibuf, ibufsiz))
  {
    /* Error */
    memset( bf_key_pw, 0, sizeof(bf_key_pw) );  
    return 0;
  }
  
  /* Buffer passed to EVP_EncryptFinal() must be after data just
   * encrypted to avoid overwriting it.
   */
  if (!EVP_DecryptFinal_ex(&ctx, obuf + outlen, &tmplen))
  {
    /* Error */
    memset( bf_key_pw, 0, sizeof(bf_key_pw) );  
    return 0;
  }
  outlen += tmplen;
  
  EVP_CIPHER_CTX_cleanup(&ctx);

  memset( bf_key_pw, 0, sizeof(bf_key_pw) );    
  
  return(outlen);
}

#endif

