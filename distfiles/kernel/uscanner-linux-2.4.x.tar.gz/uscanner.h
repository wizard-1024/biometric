/*
 * USB Biometric FingerPrint Scanner Driver - 0.3
 * (kernel 2.4.x)
 *
 * Copyright (C) 2003-2004 Dmitry Stefankov (dmstef22@biomark.org.ru)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *
 * $Id: uscanner.h,v 1.5 2004-12-06 16:10:58+03 dstef Exp root $
 *
 */


/* Version Information */
#define DRIVER_VERSION "v0.3"
#define DRIVER_AUTHOR "Dmitry Stefankov, dmstef22@biomark.org.ru"
#define DRIVER_DESC "USB Biometric FingerPrint Scanner Driver"

/* Define these values to match your device */
#define USB_USCAN_VENDOR_ID	0x0834
#define USB_USCAN_PRODUCT_ID	0x0020

#define USB_FUTRONIC_VENDOR_ID	0x1491
#define USB_FUTRONIC_PRODUCT_ID	0x0020

/* Our device name */
#define  DEVICE_NAME  "uscanner"

/* Get a minor range for your devices from the usb maintainer */
#define USB_USCAN_MINOR_BASE	192	

/* we can have up to this number of device plugged in at once */
#define MAX_DEVICES		16

/* read_scanner timeouts -- RD_NAK_TIMEOUT * RD_EXPIRE = Number of seconds */
#define RD_NAK_TIMEOUT (10*HZ)	/* Default number of X seconds to wait */
#define RD_EXPIRE 12		/* Number of attempts to wait X seconds */
