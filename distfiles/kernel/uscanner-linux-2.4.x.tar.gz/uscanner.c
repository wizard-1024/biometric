/*
 * USB Biometric FingerPrint Scanner Driver - 0.3
 * (kernel 2.4.x)
 *
 * Copyright (C) 2003-2004 Dmitry Stefankov (dmstef22@biomark.org.ru)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *
 * This driver is originally based on a USB skeleton driver and 
 * a USB scanner driver.
 *
 * TODO:
 *
 * History:
 *
 * 0.3    29-Mar-2004
 *         removed all driver mode (no more ioctl calls)
 *         support of classic Unix driver model (open/write/read/close)
 *  
 * 0.2    11-Dev-2003
 *     --  support for driver mode
 *         mode 0 (send command indirectly before read data)
 *                ioctl/read sequence
 *         mode 1 (write command directly before read data)
 *                 write/read sequence
 *         code cleanup
 *
 * 0.1    9-Dec-2003
 *     --  first version
 * 
 */

#include <linux/config.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/signal.h>
#include <linux/errno.h>
#include <linux/poll.h>
#include <linux/init.h>
#include <linux/slab.h>
#include <linux/fcntl.h>
#include <linux/module.h>
#include <linux/spinlock.h>
#include <linux/list.h>
#include <linux/smp_lock.h>
#include <linux/devfs_fs_kernel.h>
#include <linux/usb.h>

#include "uscanner.h"

#define _WAIT_ON_READ_TIMEOUT 0

/* Module source information */
static  char rcsid[] = "$Id: uscanner.c,v 1.7 2004-12-06 16:11:05+03 dstef Exp $";

/* Debugging */
#ifdef CONFIG_USB_DEBUG
	static int debug = 1;
#else
	static int debug = 0;
#endif

/* Use our own dbg macro */
#undef dbg
#define dbg(format, arg...) do { if (debug) printk(KERN_INFO __FILE__ ": " format "\n" , ## arg); } while (0)

/* Critical values */
static int  read_timeout = 0;
static int  read_bufsize = 4096;
/*  Notes about buffer size for reading (2xP3-1000)
  bufsize(bytes) image-read-time(sec)
      64           4.798 (most stable, but very poor performance)
     128           2.479
     192           1.710
     256           1.299
     384           0.910
     448           0.766
     512           0.792 (kernel panic, not fatal)
    1024           0.381
    2048           0.602
    4096           2.292 (recommended to use as default)
    8192           0.379
   16384           0.240
   32768           0.231 (fatal kernel panic!)
*/
static int  write_bufsize = 4096;

/* Module paramaters */
MODULE_PARM(debug, "i");
MODULE_PARM_DESC(debug, "Debug enabled or not");
MODULE_PARM(read_timeout, "i");
MODULE_PARM_DESC(read_timeout, "Timeout on read operations");
MODULE_PARM(read_bufsize, "i");
MODULE_PARM_DESC(read_bufsize, "Buffer size for read operations");
MODULE_PARM(write_bufsize, "i");
MODULE_PARM_DESC(write_bufsize, "Buffer size for write operations");


/* table of devices that work with this driver */
static struct usb_device_id uscan_table [] = {
	{ USB_DEVICE(USB_USCAN_VENDOR_ID, USB_USCAN_PRODUCT_ID) },
	{ USB_DEVICE(USB_FUTRONIC_VENDOR_ID, USB_FUTRONIC_PRODUCT_ID) },	
	{ }					/* Terminating entry */
};

MODULE_DEVICE_TABLE (usb, uscan_table);

/* Structure to hold all of our device specific stuff */
struct usb_uscan {
	struct usb_device *	udev;			/* save off the usb device pointer */
	struct usb_interface *	interface;		/* the interface for this device */
	devfs_handle_t		devfs;			/* devfs device node */
	unsigned char		minor;			/* the starting minor number for this device */
	unsigned char		num_ports;		/* the number of ports this device has */
	char			num_interrupt_in;	/* number of interrupt in endpoints we have */
	char			num_bulk_in;		/* number of bulk in endpoints we have */
	char			num_bulk_out;		/* number of bulk out endpoints we have */

	unsigned char *		bulk_in_buffer;		/* the buffer to receive data */
	int			bulk_in_size;		/* the size of the receive buffer */
	__u8			bulk_in_endpointAddr;	/* the address of the bulk in endpoint */

	unsigned char *		bulk_out_buffer;	/* the buffer to send data */
	int			bulk_out_size;		/* the size of the send buffer */
	struct urb *		write_urb;		/* the urb used to send data */
	__u8			bulk_out_endpointAddr;	/* the address of the bulk out endpoint */

	struct tq_struct	tqueue;			/* task queue for line discipline waking up */
	int			open_count;		/* number of times this port has been opened */
	struct semaphore	sem;			/* locks this structure */
	int                     rd_nak_timeout;         /* read timeout value */
#if _WAIT_ON_READ_TIMEOUT							   
	wait_queue_head_t       rd_wait_q;              /* read timeouts */	
#endif	
};


/* the global usb devfs handle */
extern devfs_handle_t usb_devfs_handle;


/* local function prototypes */
static ssize_t uscan_read	(struct file *file, char *buffer, size_t count, loff_t *ppos);
static ssize_t uscan_write	(struct file *file, const char *buffer, size_t count, loff_t *ppos);
static int uscan_ioctl		(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg);
static int uscan_open		(struct inode *inode, struct file *file);
static int uscan_release	(struct inode *inode, struct file *file);
	
static void * uscan_probe	(struct usb_device *dev, unsigned int ifnum, const struct usb_device_id *id);
static void uscan_disconnect	(struct usb_device *dev, void *ptr);

static void uscan_write_bulk_callback	(struct urb *urb);


/* array of pointers to our devices that are currently connected */
static struct usb_uscan		*minor_table[MAX_DEVICES];

/* lock to protect the minor_table structure */
static DECLARE_MUTEX (minor_table_mutex);

/*
 * File operations needed when we register this driver.
 * This assumes that this driver NEEDS file operations,
 * of course, which means that the driver is expected
 * to have a node in the /dev directory. If the USB
 * device were for a network interface then the driver
 * would use "struct net_driver" instead, and a serial
 * device would use "struct tty_driver". 
 */
static struct file_operations uscan_fops = {
	/*
	 * The owner field is part of the module-locking
	 * mechanism. The idea is that the kernel knows
	 * which module to increment the use-counter of
	 * BEFORE it calls the device's open() function.
	 * This also means that the kernel can decrement
	 * the use-counter again before calling release()
	 * or should the open() function fail.
	 *
	 * Not all device structures have an "owner" field
	 * yet. "struct file_operations" and "struct net_device"
	 * do, while "struct tty_driver" does not. If the struct
	 * has an "owner" field, then initialize it to the value
	 * THIS_MODULE and the kernel will handle all module
	 * locking for you automatically. Otherwise, you must
	 * increment the use-counter in the open() function
	 * and decrement it again in the release() function
	 * yourself.
	 */
	owner:		THIS_MODULE,

	read:		uscan_read,
	write:		uscan_write,
	ioctl:		uscan_ioctl,
	open:		uscan_open,
	release:	uscan_release,
};      


/* usb specific object needed to register this driver with the usb subsystem */
static struct usb_driver uscan_driver = {
	name:		"uscanner",
	probe:		uscan_probe,
	disconnect:	uscan_disconnect,
	fops:		&uscan_fops,
	minor:		USB_USCAN_MINOR_BASE,
	id_table:	uscan_table,
};

 
/* Stolen code form usb-debug.c */

static void usb_show_endpoint(struct usb_endpoint_descriptor *endpoint)
{
	usb_show_endpoint_descriptor(endpoint);
}

static void usb_show_interface(struct usb_interface_descriptor *altsetting)
{
	int i;

	usb_show_interface_descriptor(altsetting);

	for (i = 0; i < altsetting->bNumEndpoints; i++)
		usb_show_endpoint(altsetting->endpoint + i);
}

static void usb_show_config(struct usb_config_descriptor *config)
{
	int i, j;
	struct usb_interface *ifp;

	usb_show_config_descriptor(config);
	for (i = 0; i < config->bNumInterfaces; i++) {
		ifp = config->interface + i;

		if (!ifp)
			break;

		printk("\n  Interface: %d\n", i);
		for (j = 0; j < ifp->num_altsetting; j++)
			usb_show_interface(ifp->altsetting + j);
	}
}

void usb_show_device(struct usb_device *dev)
{
	int i;

	usb_show_device_descriptor(&dev->descriptor);
	for (i = 0; i < dev->descriptor.bNumConfigurations; i++)
		usb_show_config(dev->config + i);
}

/*
 * Parse and show the different USB descriptors.
 */
void usb_show_device_descriptor(struct usb_device_descriptor *desc)
{
	if (!desc)
	{
		printk("Invalid USB device descriptor (NULL POINTER)\n");
		return;
	}
	printk("  Length              = %2d%s\n", desc->bLength,
		desc->bLength == USB_DT_DEVICE_SIZE ? "" : " (!!!)");
	printk("  DescriptorType      = %02x\n", desc->bDescriptorType);

	printk("  USB version         = %x.%02x\n",
		desc->bcdUSB >> 8, desc->bcdUSB & 0xff);
	printk("  Vendor:Product      = 0x%04x:0x%04x\n",
		desc->idVendor, desc->idProduct);
	printk("  MaxPacketSize0      = %d\n", desc->bMaxPacketSize0);
	printk("  NumConfigurations   = %d\n", desc->bNumConfigurations);
	printk("  Device version      = %x.%02x\n",
		desc->bcdDevice >> 8, desc->bcdDevice & 0xff);

	printk("  Device Class:SubClass:Protocol = %02x:%02x:%02x\n",
		desc->bDeviceClass, desc->bDeviceSubClass, desc->bDeviceProtocol);
	switch (desc->bDeviceClass) {
	case 0:
		printk("    Per-interface classes\n");
		break;
	case USB_CLASS_AUDIO:
		printk("    Audio device class\n");
		break;
	case USB_CLASS_COMM:
		printk("    Communications class\n");
		break;
	case USB_CLASS_HID:
		printk("    Human Interface Devices class\n");
		break;
	case USB_CLASS_PRINTER:
		printk("    Printer device class\n");
		break;
	case USB_CLASS_MASS_STORAGE:
		printk("    Mass Storage device class\n");
		break;
	case USB_CLASS_HUB:
		printk("    Hub device class\n");
		break;
	case USB_CLASS_VENDOR_SPEC:
		printk("    Vendor class\n");
		break;
	default:
		printk("    Unknown class\n");
	}
	
	printk("  Manufacturer  index = 0x%02x\n", desc->iManufacturer );
	printk("  Product       index = 0x%02x\n", desc->iProduct );	
	printk("  Serial number index = 0x%02x\n", desc->iSerialNumber );	
}

void usb_show_config_descriptor(struct usb_config_descriptor *desc)
{
	printk("Configuration:\n");
	printk("  bLength             = %4d%s\n", desc->bLength,
		desc->bLength == USB_DT_CONFIG_SIZE ? "" : " (!!!)");
	printk("  bDescriptorType     =   %02x\n", desc->bDescriptorType);
	printk("  wTotalLength        = %04x\n", desc->wTotalLength);
	printk("  bNumInterfaces      =   %02x\n", desc->bNumInterfaces);
	printk("  bConfigurationValue =   %02x\n", desc->bConfigurationValue);
	printk("  iConfiguration      =   %02x\n", desc->iConfiguration);
	printk("  bmAttributes        =   %02x\n", desc->bmAttributes);
	printk("  MaxPower            = %4dmA\n", desc->MaxPower * 2);
}

void usb_show_interface_descriptor(struct usb_interface_descriptor *desc)
{
	printk("  Alternate Setting: %2d\n", desc->bAlternateSetting);
	printk("    bLength             = %4d%s\n", desc->bLength,
		desc->bLength == USB_DT_INTERFACE_SIZE ? "" : " (!!!)");
	printk("    bDescriptorType     =   %02x\n", desc->bDescriptorType);
	printk("    bInterfaceNumber    =   %02x\n", desc->bInterfaceNumber);
	printk("    bAlternateSetting   =   %02x\n", desc->bAlternateSetting);
	printk("    bNumEndpoints       =   %02x\n", desc->bNumEndpoints);
	printk("    bInterface Class:SubClass:Protocol =   %02x:%02x:%02x\n",
		desc->bInterfaceClass, desc->bInterfaceSubClass, desc->bInterfaceProtocol);
	printk("    iInterface          =   %02x\n", desc->iInterface);
}

void usb_show_endpoint_descriptor(struct usb_endpoint_descriptor *desc)
{
	char *LengthCommentString = (desc->bLength ==
		USB_DT_ENDPOINT_AUDIO_SIZE) ? " (Audio)" : (desc->bLength ==
		USB_DT_ENDPOINT_SIZE) ? "" : " (!!!)";
	char *EndpointType[4] = { "Control", "Isochronous", "Bulk", "Interrupt" };

	printk("    Endpoint:\n");
	printk("      bLength             = %4d%s\n",
		desc->bLength, LengthCommentString);
	printk("      bDescriptorType     =   %02x\n", desc->bDescriptorType);
	printk("      bEndpointAddress    =   %02x (%s)\n", desc->bEndpointAddress,
		(desc->bmAttributes & USB_ENDPOINT_XFERTYPE_MASK) ==
			USB_ENDPOINT_XFER_CONTROL ? "i/o" :
		(desc->bEndpointAddress & USB_ENDPOINT_DIR_MASK) ? "in" : "out");
	printk("      bmAttributes        =   %02x (%s)\n", desc->bmAttributes,
		EndpointType[USB_ENDPOINT_XFERTYPE_MASK & desc->bmAttributes]);
	printk("      wMaxPacketSize      = %04x\n", desc->wMaxPacketSize);
	printk("      bInterval           =   %02x\n", desc->bInterval);

	/* Audio extensions to the endpoint descriptor */
	if (desc->bLength == USB_DT_ENDPOINT_AUDIO_SIZE) {
		printk("      bRefresh            =   %02x\n", desc->bRefresh);
		printk("      bSynchAddress       =   %02x\n", desc->bSynchAddress);
	}
}

void usb_show_string(struct usb_device *dev, char *id, int index)
{
	char *buf;

	if (!index)
		return;
	if (!(buf = kmalloc(256, GFP_KERNEL)))
		return;
	if (usb_string(dev, index, buf, 256) > 0)
		printk(KERN_INFO "%s: %s\n", id, buf);
	kfree(buf);
}

void usb_dump_urb (struct urb *urb)
{
	printk ("urb                   :%p\n", urb);
	printk ("next                  :%p\n", urb->next);
	printk ("dev                   :%p\n", urb->dev);
	printk ("pipe                  :%08X\n", urb->pipe);
	printk ("status                :%d\n", urb->status);
	printk ("transfer_flags        :%08X\n", urb->transfer_flags);
	printk ("transfer_buffer       :%p\n", urb->transfer_buffer);
	printk ("transfer_buffer_length:%d\n", urb->transfer_buffer_length);
	printk ("actual_length         :%d\n", urb->actual_length);
	printk ("setup_packet          :%p\n", urb->setup_packet);
	printk ("start_frame           :%d\n", urb->start_frame);
	printk ("number_of_packets     :%d\n", urb->number_of_packets);
	printk ("interval              :%d\n", urb->interval);
	printk ("error_count           :%d\n", urb->error_count);
	printk ("context               :%p\n", urb->context);
	printk ("complete              :%p\n", urb->complete);
}



/**
 *	usb_uscan_debug_data
 */
static inline void usb_uscan_debug_data (const char *function, int size, const unsigned char *data)
{
	int i;

	if (!debug)
		return;
	
	printk (KERN_INFO __FILE__": %s - length = %d, data = ", 
		function, size);
	for (i = 0; i < size; ++i) {
		printk ("%.2x ", data[i]);
	}
	printk ("\n");
}


/**
 *	uscan_delete
 */
static inline void uscan_delete (struct usb_uscan *dev)
{
	minor_table[dev->minor] = NULL;
	if (dev->bulk_in_buffer != NULL)
		kfree (dev->bulk_in_buffer);
	if (dev->bulk_out_buffer != NULL)
		kfree (dev->bulk_out_buffer);
	if (dev->write_urb != NULL)
		usb_free_urb (dev->write_urb);
	kfree (dev);
}


/**
 *	uscan_open
 */
static int uscan_open (struct inode *inode, struct file *file)
{
	struct usb_uscan *dev = NULL;
	int subminor;
	int retval = 0;
	
	if (debug)
	  printk("uscan_open()\n");

	subminor = MINOR (inode->i_rdev) - USB_USCAN_MINOR_BASE;
	if ((subminor < 0) ||
	    (subminor >= MAX_DEVICES)) {
		return -ENODEV;
	}

	/* Increment our usage count for the module.
	 * This is redundant here, because "struct file_operations"
	 * has an "owner" field. This line is included here soley as
	 * a reference for drivers using lesser structures... ;-)
	 */
	MOD_INC_USE_COUNT;

	/* lock our minor table and get our local data for this minor */
	down (&minor_table_mutex);
	dev = minor_table[subminor];
	if (dev == NULL) {
		up (&minor_table_mutex);
		MOD_DEC_USE_COUNT;
		return -ENODEV;
	}

#if _WAIT_ON_READ_TIMEOUT	
        init_waitqueue_head(&dev->rd_wait_q);
#endif
        
	/* lock this device */
	down (&dev->sem);

	/* unlock the minor table */
	up (&minor_table_mutex);

	/* increment our usage count for the driver */
	++dev->open_count;

	/* save our object in the file's private structure */
	file->private_data = dev;

	/* unlock this device */
	up (&dev->sem);

	return retval;
}


/**
 *	uscan_release
 */
static int uscan_release (struct inode *inode, struct file *file)
{
	struct usb_uscan *dev;
	int retval = 0;

	dev = (struct usb_uscan *)file->private_data;
	if (dev == NULL) {
		printk("uscan_release: object is NULL\n");
		return -ENODEV;
	}

        if (debug)
	  printk("uscan_release: minor %d\n", dev->minor);

	/* lock our minor table */
	down (&minor_table_mutex);

	/* lock our device */
	down (&dev->sem);

	if (dev->open_count <= 0) {
		printk("uscan_release: device not opened\n");
		retval = -ENODEV;
		goto exit_not_opened;
	}

	if (dev->udev == NULL) {
		/* the device was unplugged before the file was released */
		up (&dev->sem);
		uscan_delete (dev);
		up (&minor_table_mutex);
		MOD_DEC_USE_COUNT;
		return 0;
	}

	/* decrement our usage count for the device */
	--dev->open_count;
	if (dev->open_count <= 0) {
		/* shutdown any bulk writes that might be going on */
		usb_unlink_urb (dev->write_urb);
		dev->open_count = 0;
	}

#if 0	
	/* awaken all other childrens */
	if (waitqueue_active(&dev->rd_wait_q)) {
	  printk( "uscan_release: wake-up other world.\n" );
	  wake_up_interruptible(&dev->rd_wait_q);
	}
#endif

	/* decrement our usage count for the module */
	MOD_DEC_USE_COUNT;

exit_not_opened:
	up (&dev->sem);
	up (&minor_table_mutex);

	return retval;
}


/**
 *	uscan_read
 */
static ssize_t uscan_read (struct file *file, char *buffer, size_t count, loff_t *ppos)
{
	struct usb_uscan  *dev;
	ssize_t            retval = 0;
	ssize_t            partial;
	int                result;
	ssize_t            bytes_read;	/* Overall count of bytes_read */
	int                this_read;	/* Max number of bytes to read */
	int                rd_expire = RD_EXPIRE;
	int                ibuf_size;
	char              *ibuf;

	dev = (struct usb_uscan *)file->private_data;
	
	if (debug)
	  printk("uscan_read: minor %d, count = %d\n", dev->minor, count);

	/* lock this object */
	down (&dev->sem);

	/* verify that the device wasn't unplugged */
	if (dev->udev == NULL) {
		up (&dev->sem);
		return -ENODEV;
	}

	ibuf = dev->bulk_in_buffer;
	ibuf_size = dev->bulk_in_size;
	bytes_read = 0;

        /* Update the atime of the device node */
	file->f_dentry->d_inode->i_atime = CURRENT_TIME; 
                                                            
	while (count > 0) {
		if (signal_pending(current)) {
			retval = -ERESTARTSYS;
			break;
		}

		this_read = (count >= ibuf_size) ? ibuf_size : count;
		partial = 0;

	        result = usb_bulk_msg (dev->udev, 
	                    usb_rcvbulkpipe (dev->udev, dev->bulk_in_endpointAddr),
			       ibuf, this_read, &partial, dev->rd_nak_timeout);
		if (debug)	       
                  printk("read: result:%d this_read:%d partial:%d count:%d\n", result, this_read, partial, count);

/*
 * Scanners are sometimes inheriently slow since they are mechanical
 * in nature.  USB bulk reads tend to timeout while the scanner is
 * positioning, resetting, warming up the lamp, etc if the timeout is
 * set too low.  A very long timeout parameter for bulk reads was used
 * to overcome this limitation, but this sometimes resulted in folks
 * having to wait for the timeout to expire after pressing Ctrl-C from
 * an application. The user was sometimes left with the impression
 * that something had hung or crashed when in fact the USB read was
 * just waiting on data.  So, the below code retains the same long
 * timeout period, but splits it up into smaller parts so that
 * Ctrl-C's are acted upon in a reasonable amount of time.
 */
		if (result == -ETIMEDOUT) { /* NAK */
			if (!partial) { /* No data */
				if (--rd_expire <= 0) {	/* Give it up */
					printk("uscan_read: excessive NAK's received!\n");
					retval = result;
					break;
				} else { /* Keep trying to read data */
				        if (debug)
				          printk( "uscan_read: sleep with timeout.\n" );
#if _WAIT_ON_READ_TIMEOUT					  
					interruptible_sleep_on_timeout(&dev->rd_wait_q, dev->rd_nak_timeout);
#endif					
					continue;
				}
			} else { /* Timeout w/ some data */
				goto data_recvd;
			}
		}

		if (result == -EPIPE) { /* No hope */
			if(usb_clear_halt(dev->udev, dev->bulk_in_endpointAddr)) {
			    printk("read: Failure to clear endpoint halt condition (%Zd).\n", retval);
			}
			retval = result;
			break;
		} else if ((result < 0) && (result != USB_ST_DATAUNDERRUN)) {
			printk("read: funky result:%d.\n", (int)result);
			retval = -EIO;
			break;
		}

	data_recvd:

		if (partial) { /* Data returned */
			if (copy_to_user(buffer, ibuf, partial)) {
				retval = -EFAULT;
				break;
			}
			count -= this_read; /* Compensate for short reads */
			bytes_read += partial; /* Keep tally of what actually was read */
			buffer += partial;
		} else {
			retval = 0;
			break;
		}
	}

	/* unlock the device */
	up (&dev->sem);
	return retval ? retval : bytes_read;
}


/**
 *	uscan_write
 */
static ssize_t uscan_write (struct file *file, const char *buffer, size_t count, loff_t *ppos)
{
	struct usb_uscan *dev;
	ssize_t bytes_written = 0;
	int retval = 0;
	int this_write;		/* Number of bytes to write */
	int partial;		/* Number of bytes successfully written */
	int result = 0;
	int  obuf_size;	
	char *obuf;

	dev = (struct usb_uscan *)file->private_data;

        if (debug)
	  printk("uscan_write: minor %d, count = %d\n", dev->minor, count);

	/* lock this object */
	down (&dev->sem);

	/* verify that the device wasn't unplugged */
	if (dev->udev == NULL) {
		retval = -ENODEV;
               if (debug)
	         printk("uscan_write: no such device attached!\n");
		goto exit;
	}

	/* verify that we actually have some data to write */
	if (count == 0){
		printk("uscan_write: write request of 0 bytes\n");
		goto exit;
	}

	obuf = dev->bulk_out_buffer;
	obuf_size = dev->bulk_out_size;

        /* Access time of device */
	file->f_dentry->d_inode->i_atime = CURRENT_TIME;

	while (count > 0) {

		if (signal_pending(current)) {
			retval = -ERESTARTSYS;
			break;
		}


		this_write = (count >= obuf_size) ? obuf_size : count;
          
		if (copy_from_user(obuf, buffer, this_write)) {
			retval = -EFAULT;
			break;
		}

		result = usb_bulk_msg(dev->udev,usb_sndbulkpipe(dev->udev, dev->bulk_out_endpointAddr), obuf, this_write, &partial, 60*HZ);
		if (debug)
		  printk("uscan_write: result:%d this_write:%d partial:%d\n", result, this_write, partial);

		if (result == -ETIMEDOUT) {	/* NAK -- shouldn't happen */
			printk("uscan_write: NAK received.\n");
			retval = result;
			break;
		} else if (result < 0) { /* We should not get any I/O errors */
			printk("uscan_write: funky result: %d.\n", result);
			retval = -EIO;
			break;
		}

		if (partial != this_write) { /* Unable to write all contents of obuf */
			retval = -EIO;
			break;
		}

		if (partial) { /* Data written */
			buffer += partial;
			count -= partial;
			bytes_written += partial;
		} else { /* No data written */
			retval = 0;
			break;
		}
	}

exit:
	/* unlock the device */
	up (&dev->sem);
	
	return retval ? retval : bytes_written; ;
}


/**
 *	uscan_ioctl
 */
static int uscan_ioctl (struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg)
{
	struct usb_uscan *dev;
	int  retval = -ENOTTY;
	
	dev = (struct usb_uscan *)file->private_data;

	/* lock this object */
	down (&dev->sem);

	/* verify that the device wasn't unplugged */
	if (dev->udev == NULL) {
		up (&dev->sem);
		return -ENODEV;
	}

        if (debug)
	  printk("uscan_ioctl: minor %d, cmd 0x%.4x, arg %lu\n", dev->minor, cmd, arg);

	/* fill in your device specific stuff here */
        switch(cmd) {
          default:
              break;
        }

	/* unlock the device */
	up (&dev->sem);
	
	/* return that we understand or reject this ioctl call */
	return retval ;
}


/**
 *	uscan_write_bulk_callback
 */
static void uscan_write_bulk_callback (struct urb *urb)
{
	struct usb_uscan *dev = (struct usb_uscan *)urb->context;

        if (debug)
	printk("uscan_write_bulk_callback: minor %d\n", dev->minor);

	if ((urb->status != -ENOENT) && 
	    (urb->status != -ECONNRESET)) {
		printk("ERROR: nonzero write bulk status received: %d\n",
		    urb->status);
		return;
	}

	return;
}


/**
 *	uscan_probe
 *
 *	Called by the usb core when a new device is connected that it thinks
 *	this driver might be interested in.
 */
static void * uscan_probe(struct usb_device *udev, unsigned int ifnum, const struct usb_device_id *id)
{
	struct usb_uscan *dev = NULL;
	struct usb_interface *interface;
	struct usb_interface_descriptor *iface_desc;
	struct usb_endpoint_descriptor *endpoint;
	int minor;
	int buffer_size;
	int i;
	int valid_device = 0;
	char name[10];
	
	
	/* See if the device offered us matches what we can accept */
	if (((udev->descriptor.idVendor == USB_USCAN_VENDOR_ID) &&
	    (udev->descriptor.idProduct = USB_USCAN_PRODUCT_ID)) ||
	    ((udev->descriptor.idVendor == USB_FUTRONIC_VENDOR_ID) &&
	    (udev->descriptor.idProduct = USB_FUTRONIC_PRODUCT_ID))) {
		valid_device = 1;
	}
	
	if (!valid_device)
	  return(NULL);

	/* select a "subminor" number (part of a minor number) */
	down (&minor_table_mutex);
	for (minor = 0; minor < MAX_DEVICES; ++minor) {
		if (minor_table[minor] == NULL)
			break;
	}
	if (minor >= MAX_DEVICES) {
		printk ("ERROR: too many devices plugged in, can not handle this device.\n");
		goto exit;
	}

	/* allocate memory for our device state and intialize it */
	dev = kmalloc (sizeof(struct usb_uscan), GFP_KERNEL);
	if (dev == NULL) {
		printk ("ERROR: out of memory!\n");
		goto exit;
	}
	memset (dev, 0x00, sizeof (*dev));
	minor_table[minor] = dev;

#if 0
        if (debug)
	  usb_show_device( udev );
#endif
	  
	interface = &udev->actconfig->interface[ifnum];

	init_MUTEX (&dev->sem);
	dev->udev = udev;
	dev->interface = interface;
	dev->minor = minor;

	/* set up the endpoint information */
	/* check out the endpoints */
	iface_desc = &interface->altsetting[0];
	for (i = 0; i < iface_desc->bNumEndpoints; ++i) {
		endpoint = &iface_desc->endpoint[i];

		if ((endpoint->bEndpointAddress & 0x80) &&
		    ((endpoint->bmAttributes & 3) == 0x02)) {
			/* we found a bulk in endpoint */
			buffer_size = endpoint->wMaxPacketSize;
			if (read_bufsize) buffer_size = read_bufsize;
			if (debug) printk( "uscan_probe: read_buf_size = %d bytes\n", buffer_size );
			dev->bulk_in_size = buffer_size;
			dev->bulk_in_endpointAddr = endpoint->bEndpointAddress;
			dev->bulk_in_buffer = kmalloc (buffer_size, GFP_KERNEL);
			if (!dev->bulk_in_buffer) {
				printk("ERROR: couldn't allocate bulk_in_buffer!\n");
				goto error;
			}
		}
		
		if (((endpoint->bEndpointAddress & 0x80) == 0x00) &&
		    ((endpoint->bmAttributes & 3) == 0x02)) {
			/* we found a bulk out endpoint */
			dev->write_urb = usb_alloc_urb(0);
			if (!dev->write_urb) {
				printk("ERROR: no free urbs available!\n");
				goto error;
			}
			buffer_size = endpoint->wMaxPacketSize;
			if (write_bufsize) buffer_size = write_bufsize;
			if (debug) printk( "uscan_probe: write_buf_size = %d bytes\n", buffer_size );
			dev->bulk_out_size = buffer_size;
			dev->bulk_out_endpointAddr = endpoint->bEndpointAddress;
			dev->bulk_out_buffer = kmalloc (buffer_size, GFP_KERNEL);
			if (!dev->bulk_out_buffer) {
				printk("ERROR: couldn't allocate bulk_out_buffer!\n");
				goto error;
			}
			FILL_BULK_URB(dev->write_urb, udev, 
				      usb_sndbulkpipe(udev, 
						      endpoint->bEndpointAddress),
				      dev->bulk_out_buffer, buffer_size,
				      uscan_write_bulk_callback, dev);
		}
	}

        if (read_timeout != 0)
	  dev->rd_nak_timeout = read_timeout * HZ;
	else
          dev->rd_nak_timeout = RD_NAK_TIMEOUT;
        
	/* initialize the devfs node for this device and register it */
	if (debug)
	  printk( "minor: %d\n", USB_USCAN_MINOR_BASE + dev->minor );
	sprintf(name, "%s%d", DEVICE_NAME,dev->minor);
	if (debug)
	  printk( "device: %s\n", name );

#if 1	
	dev->devfs = devfs_register (usb_devfs_handle, name,
				     DEVFS_FL_DEFAULT, USB_MAJOR,
				     USB_USCAN_MINOR_BASE + dev->minor,
				     S_IFCHR | S_IRUSR | S_IWUSR | 
				     S_IRGRP | S_IWGRP | S_IROTH, 
				     &uscan_fops, NULL);
         if (dev->devfs == NULL) 
	   printk( "WARNING: cannot register node!\n" );				     
#endif

	/* let the user know what node this device is now attached to */
	printk("USB FingerPrint device now attached to %s%d\n", DEVICE_NAME,dev->minor);

	goto exit;
	
error:
	uscan_delete (dev);
	dev = NULL;

exit:
	up (&minor_table_mutex);
	return dev;
}


/**
 *	uscan_disconnect
 *
 *	Called by the usb core when the device is removed from the system.
 */
static void uscan_disconnect(struct usb_device *udev, void *ptr)
{
	struct usb_uscan *dev;
	int minor;

	dev = (struct usb_uscan *)ptr;
	
	down (&minor_table_mutex);
	down (&dev->sem);
		
	minor = dev->minor;

	/* remove our devfs node */
	devfs_unregister(dev->devfs);

	/* if the device is not opened, then we clean up right now */
	if (!dev->open_count) {
		up (&dev->sem);
		uscan_delete (dev);
	} else {
		dev->udev = NULL;
		up (&dev->sem);
	}

	printk("USB FingerPrint Device #%d now disconnected\n", minor);
	up (&minor_table_mutex);
}



/**
 *	usb_uscan_init
 */
static int __init usb_uscan_init(void)
{
	int result;

        /* Suppress compile warnings */
        result = rcsid[0];
	
	/* register this driver with the USB subsystem */
	result = usb_register(&uscan_driver);
	if (result < 0) {
		printk("usb_register failed for the %s driver. Error number %d\n",
		    DRIVER_DESC, result);
		return -1;
	}

        if (debug)
	  printk("usb_uscan_init: %s %s\n", DRIVER_DESC,DRIVER_VERSION);
	return 0;
}


/**
 *	usb_uscan_exit
 */
static void __exit usb_uscan_exit(void)
{
	/* deregister this driver with the USB subsystem */
	if (debug)
	  printk( "usb_uscan_eixt()\n" );
	usb_deregister(&uscan_driver);
}


module_init (usb_uscan_init);
module_exit (usb_uscan_exit);

MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE("GPL");

