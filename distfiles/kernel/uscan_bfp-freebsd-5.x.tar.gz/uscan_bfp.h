/* Define these values to match your device */
#define USB_USCAN_VENDOR_ID	0x0834
#define USB_USCAN_PRODUCT_ID	0x0020

#define USB_FUTRONIC_VENDOR_ID	0x1491
#define USB_FUTRONIC_PRODUCT_ID	0x0020
