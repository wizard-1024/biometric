/** gtk-demo.c **/
/* Copyright (C) 2003-2004 Dmitry Stefankov */

#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>

#include <bfpsdk.h>

#define  FINGER_OFF_IMAGE   "fp-off.png"
#define  FINGER_ON_IMAGE    "fp-on.png"

/* Constants */
#define SCREEN_WIDTH  320
#define SCREEN_HEIGHT 480

#define BUTTON_FIXED_X_POS  80
#define BUTTON_FIXED_Y_POS  100
#define Y_STEP              50

#define  MAX_USERS_NUM   1024

#define  MAX_USER_NAME_SIZE  64

static const char rcs_id[] = "$Id: gtk-demo.c,v 1.3 2004-11-13 23:35:45+03 dstef Exp root $";

/* BFP measurement level */
int measure = 0;

/* 1=debug on, 0=debug off */
int gtk_debug = 0;

#define CYCLE_LEN 60
#define FRAME_DELAY 50

/* N seconds to detect finger presence */
int  timeout = 30;          

struct fp_user_template {
  int            template_size;
  unsigned char  * fp_template;
  char           user_name[MAX_USER_NAME_SIZE+1];
};

/* Current users number */
int  db_users_num = 0;

struct fp_user_template  temp_user_record;
struct fp_user_template  user_templates_db[MAX_USERS_NUM];

unsigned char   * fp_model = NULL;
unsigned char   * fp_template = NULL;
unsigned char   * raw_image_buf = NULL;
unsigned char   * enroll_images_buf = NULL;  

int             fp_model_size = 0;
int             fp_template_size = 0;
int             fp_images_num = 0;
unsigned int    fp_image_size = 0;
struct bfp_software_info  bfp_param; 

static void shutdown();

/* Callbacks */
gint eventDelete(GtkWidget *widget,GdkEvent *event,gpointer data);
gint eventDestroy(GtkWidget *widget,GdkEvent *event,gpointer data);

void CaptureCallback( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void VerifyCallback( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void IdentifyCallback( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void EnrollCallback( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void ExitCallback( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void EnterMessageCaptureCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void ReleaseMessageCaptureCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void EnterMessageVerifyCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void ReleaseMessageVerifyCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void EnterMessageIdentifyCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void ReleaseMessageIdentifyCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void EnterMessageEnrollCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void ReleaseMessageEnrollCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);


/* Miscellaneous */
int  run_this_program( char * program, char * parameters );
int  detect_scanner_presence_in_system(void);
void unlink_image_files(void);


/* Background image */
static int back_width, back_height;

/* Images */
static GdkPixbuf *frame;
static GdkPixbuf *image;

/* Widgets */
static GtkWidget *da;

static int frame_num;
static guint timeout_id;

/* Help */
static GtkWidget  *help_window = NULL;      
static GtkWidget *help_da;
static GdkPixbuf *help_frame;
static GdkPixbuf *help_image;
static int help_back_width, help_back_height;
static int help_frame_num;
static guint help_timeout_id;


/* Text message buffer */
static GtkWidget *TextMessageLabel;
char * MessageBuffer = NULL;
char release_message[]  = "MSG_BUF: Select your action using button press.";
char capture_message[]  = "MSG_BUF: Follow instructions in help window.   ";
char init_message[]     = "MSG_BUF: Select your action using button press.";
    

/* Main application */
int main(int argc,char *argv[])
{
    GtkWidget *topLevelWindow;
    GtkWidget *image;      
    GtkWidget *fixed;    
    GtkWidget *Button1;
    GtkWidget *Button2;    
    GtkWidget *Button3;
    GtkWidget *Button4;        
    GtkWidget *Button5;            
    int res;
    int i;
    GtkTooltips *button_tips;    

    if (argc > 1)
      gtk_debug=1;
    if (argc > 2)
      measure=atoi(argv[2]);  
      
    /* Init application */
	gtk_init(&argc,&argv);
	topLevelWindow = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(topLevelWindow),
            SCREEN_WIDTH,SCREEN_HEIGHT);
      gtk_window_set_title (GTK_WINDOW (topLevelWindow), "GTK BFPSDK Sample Application");	
      
    gtk_signal_connect(GTK_OBJECT(topLevelWindow),
            "delete_event",
            GTK_SIGNAL_FUNC(eventDelete),
            NULL);
    gtk_signal_connect(GTK_OBJECT(topLevelWindow),
            "destroy",
            GTK_SIGNAL_FUNC(eventDestroy),
            NULL);

    /* Add tooltips */
    button_tips = gtk_tooltips_new();
    
       fixed = gtk_fixed_new();
       gtk_widget_show(fixed);
       
    /* Add buttons into fixed container */
    Button1 = gtk_button_new_with_label("Capture ");
    gtk_signal_connect(GTK_OBJECT(Button1),
            "pressed",
            GTK_SIGNAL_FUNC(CaptureCallback),
            NULL);
    gtk_signal_connect(GTK_OBJECT(Button1),
            "enter",
            GTK_SIGNAL_FUNC(EnterMessageCaptureCallBack),
            NULL);            
    gtk_signal_connect(GTK_OBJECT(Button1),
            "released",
            GTK_SIGNAL_FUNC(ReleaseMessageCaptureCallBack),
            NULL);                        
    gtk_widget_show(Button1);
    gtk_fixed_put(GTK_FIXED(fixed),Button1, BUTTON_FIXED_X_POS, 
                            (BUTTON_FIXED_Y_POS+0*Y_STEP) );
    gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),Button1,
                         "Capture a single frame from scanner.",
                          "Please put your finger on scanner after pressing on button.\
                           Automatical timeout is 15 seconds to detect finger on scanner.\
                           This operation only captures a single frame. Use it to test\
                           image getting from a scanner."
                          );

    Button2 = gtk_button_new_with_label("Verify  ");
    gtk_signal_connect(GTK_OBJECT(Button2),
            "clicked",
            GTK_SIGNAL_FUNC(VerifyCallback),
            NULL);
    gtk_signal_connect(GTK_OBJECT(Button2),
            "enter",
            GTK_SIGNAL_FUNC(EnterMessageVerifyCallBack),
            NULL);            
    gtk_signal_connect(GTK_OBJECT(Button2),
            "released",
            GTK_SIGNAL_FUNC(ReleaseMessageVerifyCallBack),
            NULL);                        
    gtk_widget_show(Button2);
    gtk_fixed_put(GTK_FIXED(fixed),Button2, BUTTON_FIXED_X_POS, 
                    (BUTTON_FIXED_Y_POS+1*Y_STEP) );
    gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),Button2,
                         "Verify user against selected template from database.",
                         "Please put your finger on scanner after pressing on button." 
                         );
                         
    Button3 = gtk_button_new_with_label("Identify");
    gtk_signal_connect(GTK_OBJECT(Button3),
            "clicked",
            GTK_SIGNAL_FUNC(IdentifyCallback),
            NULL);
    gtk_signal_connect(GTK_OBJECT(Button3),
            "enter",
            GTK_SIGNAL_FUNC(EnterMessageIdentifyCallBack),
            NULL);            
    gtk_signal_connect(GTK_OBJECT(Button3),
            "released",
            GTK_SIGNAL_FUNC(ReleaseMessageIdentifyCallBack),
            NULL);                        
    gtk_widget_show(Button3);
    gtk_fixed_put(GTK_FIXED(fixed),Button3, BUTTON_FIXED_X_POS,
                    (BUTTON_FIXED_Y_POS+2*Y_STEP) );    
    gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),Button3,
                         "Identify user against templates database.", 
                         "Please put your finger on scanner after pressing on button." 
                          );

    Button4 = gtk_button_new_with_label("Enroll  ");
    gtk_signal_connect(GTK_OBJECT(Button4),
            "clicked",
            GTK_SIGNAL_FUNC(EnrollCallback),
            NULL);
    gtk_signal_connect(GTK_OBJECT(Button4),
            "enter",
            GTK_SIGNAL_FUNC(EnterMessageEnrollCallBack),
            NULL);            
    gtk_signal_connect(GTK_OBJECT(Button4),
            "released",
            GTK_SIGNAL_FUNC(ReleaseMessageEnrollCallBack),
            NULL);                        
    gtk_widget_show(Button4);
    gtk_fixed_put(GTK_FIXED(fixed),Button4, BUTTON_FIXED_X_POS,
                    (BUTTON_FIXED_Y_POS+3*Y_STEP) );    
    gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),Button4,
                         "Enroll user and put results into templates database.", 
                         "Please put your finger on scanner after pressing on button." 
                         );

    Button5 = gtk_button_new_with_label("Exit    ");
    gtk_signal_connect(GTK_OBJECT(Button5),
            "clicked",
            GTK_SIGNAL_FUNC(ExitCallback),
            NULL);
    gtk_widget_show(Button5);
    gtk_fixed_put(GTK_FIXED(fixed),Button5, BUTTON_FIXED_X_POS,
                    (BUTTON_FIXED_Y_POS+5*Y_STEP) );    
    gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),Button5,
                         "Exit this program.", 
                         "Please come back into this world." 
                         );

    MessageBuffer = init_message;
    TextMessageLabel = gtk_label_new(MessageBuffer);
    gtk_widget_show(TextMessageLabel);    
    gtk_fixed_put(GTK_FIXED(fixed),TextMessageLabel, BUTTON_FIXED_X_POS, 420 );
                             
    /* Add nice penguin */
    image = gtk_image_new_from_file ("logo.png");    
    gtk_widget_show(image);
    gtk_fixed_put(GTK_FIXED(fixed),image, BUTTON_FIXED_X_POS+100, 50 );    

    gtk_container_add(GTK_CONTAINER(topLevelWindow),
            fixed);

    gtk_widget_show(topLevelWindow);

    /* Init BFP dynamic library */
    res = bfp_init();  
    if (res != 0) {
      if (gtk_debug) g_print("FATAL ERROR: cannot init BFP library!\n");
      exit(1);
    }

    memset( &bfp_param, 0, sizeof(bfp_param) );
    res = bfp_get_software_info( &bfp_param );
    if (res != 0) {
     if (gtk_debug) 
       g_print("FATAL_ERROR: bfp_get_software_param() failed, code=%d\n", res);
       exit(1);
    } 

    if (measure == 0) measure = bfp_param.measure;
    if (gtk_debug) g_print( "measure = %d\n", measure );
    fp_model_size = bfp_param.model_size;
    fp_template_size = bfp_param.total_size;
    fp_image_size = bfp_param.image_size;
    if (gtk_debug) g_print( "image_size = %d\n", fp_image_size );    
    fp_images_num = bfp_param.samples_num;
    if (gtk_debug) g_print( "samples = %d\n", fp_images_num );
    
    fp_model = g_malloc(fp_model_size);
    if (fp_model == NULL) {
      if (gtk_debug) g_print( "Cannot allocate memory for model!\n" );
      exit(1);
    }
    
    fp_template = g_malloc(fp_template_size);
    if (fp_template == NULL) {
      if (gtk_debug)  g_print( "Cannot allocate memory for template!\n" );
      exit(1);
    }

    raw_image_buf = g_malloc(fp_image_size);
    if (raw_image_buf == NULL) {
      if (gtk_debug)  g_print( "Cannot allocate memory for one image buffer!\n" );
      exit(1);
    }

    enroll_images_buf = g_malloc(fp_image_size*fp_images_num);
    if (enroll_images_buf == NULL) {
      if (gtk_debug)  g_print( "Cannot allocate memory for images buffer!\n" );
      exit(1);
    }

    temp_user_record.fp_template = g_malloc(fp_template_size);
    if (temp_user_record.fp_template == NULL) {
      if (gtk_debug) g_print( "Cannot allocate memory for template buffer!\n" );
      exit(1);
    }
    
    memset( user_templates_db, 0, sizeof(user_templates_db) );
    for( i=0; i<MAX_USERS_NUM; i++) {
       user_templates_db[i].fp_template = g_malloc(fp_template_size);
       if (user_templates_db[i].fp_template == NULL) {
         if (gtk_debug) g_print( "Cannot allocate memory for templates buffer!\n" );
         exit(1);
       }
    }
    if (gtk_debug) g_print("Enter main application loop.\n");	

    /* Main application loop */
    gtk_main();
    if (gtk_debug) g_print("Done!\n");	
    exit(0);
}


gint eventDelete(GtkWidget *widget,GdkEvent *event,gpointer data) {
    if (gtk_debug) g_print("Delete window.\n.");
    return(FALSE);
}


gint eventDestroy(GtkWidget *widget,GdkEvent *event,gpointer data) {
    shutdown();
    return(0);
}


/* Destroy before exit */
void shutdown() {
    int res;
    int i;
    
    if (gtk_debug) g_print("Shutting down\n");        
    res = bfp_deinit();    
    unlink_image_files();
    if (fp_model != NULL) g_free(fp_model);
    if (fp_template != NULL) g_free(fp_template);
    if (raw_image_buf != NULL) g_free(raw_image_buf);    
    if (enroll_images_buf != NULL) g_free(enroll_images_buf);
    if (temp_user_record.fp_template != NULL) g_free(temp_user_record.fp_template);
    for( i=0; i<MAX_USERS_NUM; i++) {
       g_free(user_templates_db[i].fp_template);
    }
    gtk_main_quit();
}


void ExitCallback( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  shutdown();
  return;
}        


/* Wipe temporary files */
void unlink_image_files(void)
{
  unlink("image.png" );  
  unlink("image.bin" );  
}

/* Expose callback for the drawing area */
static gint
expose_cb (GtkWidget *widget, GdkEventExpose *event, gpointer data)
{
	guchar *pixels;
	int rowstride;
#if 0
        if (gtk_debug) g_print( "Redraw fp_image window.\n" );
#endif        
	gdk_pixbuf_copy_area (image, 0, 0, back_width, back_height, frame, 0, 0);
        
	rowstride = gdk_pixbuf_get_rowstride (frame);

	pixels = gdk_pixbuf_get_pixels (frame) + rowstride * event->area.y + event->area.x;
		  
	gdk_draw_rgb_image_dithalign (widget->window,
				      widget->style->black_gc,
				      event->area.x, event->area.y,
				      event->area.width, event->area.height,
				      GDK_RGB_DITHER_NORMAL,
				      pixels, rowstride,
				      event->area.x, event->area.y);

	return TRUE;
}


/* Destroy handler for the window */
static void
destroy_cb (GtkObject *object, gpointer data)
{
        if (gtk_debug) g_print( "Destroy fp_image window.\n" );
	g_source_remove (timeout_id);
	timeout_id = 0;
}


/* Timeout handler to regenerate the frame */
static gint
frame_timeout (gpointer data)
{
#if 0
        if (gtk_debug) g_print( "frame_timeout().\n" );
#endif        
	gdk_pixbuf_copy_area (image, 0, 0, back_width, back_height,
			      frame, 0, 0);

	gtk_widget_queue_draw (da);

	frame_num++;
	return TRUE;
}

/* Write fingerprint images in separate window */
void display_fp_image_in_window(void)
{
  static GtkWidget  *image_window = NULL;      
  FILE * fp;
  int res;

  fp = fopen( "image.bin", "w" );
  if (fp != NULL) {
    fwrite( raw_image_buf,fp_image_size,1,fp );
    fclose(fp);
     /* Image conversion */
#if __linux__     
     res = run_this_program( "/usr/bin/convert", 
#else
#if __FreeBSD__
     res = run_this_program( "/usr/local/bin/convert", 
#else
#error Unsupported OS found
#endif     
#endif     
                  "-depth 8 -size 320x480 gray:image.bin image.png");
     if (res == 0) {              
        if (gtk_debug) g_print( "Load new image.\n" );
	image = gdk_pixbuf_new_from_file ("image.png", NULL);
	if (!image) {
		if (gtk_debug) g_print( "ERROR: cannot load image into buffer.\n" );
		return;
	}

        if (!image_window) {
	  back_width = gdk_pixbuf_get_width (image);
	  back_height = gdk_pixbuf_get_height (image);
	  frame = gdk_pixbuf_new (GDK_COLORSPACE_RGB, FALSE, 8, back_width, back_height);
	}
	gdk_pixbuf_copy_area (image, 0, 0, back_width, back_height, frame, 0, 0);

        if (!image_window) {
          if (gtk_debug) g_print("Make new window.\n" );
	  image_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  	  gtk_widget_set_size_request (image_window, back_width, back_height);
          gtk_window_set_resizable (GTK_WINDOW (image_window), FALSE);
          gtk_window_set_title (GTK_WINDOW (image_window), "BFP Image Window");	       
          gtk_window_move( GTK_WINDOW (image_window), 450, 1 );
  	  g_signal_connect (image_window, "destroy",
			    G_CALLBACK (destroy_cb), NULL);
 	  da = gtk_drawing_area_new ();
	  g_signal_connect (da, "expose_event",
			    G_CALLBACK (expose_cb), NULL);
	  gtk_container_add (GTK_CONTAINER (image_window), da);
   	  timeout_id = g_timeout_add (FRAME_DELAY, frame_timeout, NULL);	  
	}
	gtk_widget_show_all (image_window);	
        while( g_main_context_iteration(NULL,FALSE));       	
     }
  }  
}


/* Expose callback for the drawing area */
static gint
help_expose_cb (GtkWidget *widget, GdkEventExpose *event, gpointer data)
{
	guchar *pixels;
	int rowstride;
#if 0
        if (gtk_debug) g_print( "Redraw help_image window.\n" );
#endif        
	gdk_pixbuf_copy_area (help_image, 0, 0, help_back_width, help_back_height, help_frame, 0, 0);
        
	rowstride = gdk_pixbuf_get_rowstride (help_frame);

	pixels = gdk_pixbuf_get_pixels (help_frame) + rowstride * event->area.y + event->area.x;
		  
	gdk_draw_rgb_image_dithalign (widget->window,
				      widget->style->black_gc,
				      event->area.x, event->area.y,
				      event->area.width, event->area.height,
				      GDK_RGB_DITHER_NORMAL,
				      pixels, rowstride,
				      event->area.x, event->area.y);

	return TRUE;
}


/* Destroy handler for the window */
static void
help_destroy_cb (GtkObject *object, gpointer data)
{
        if (gtk_debug) g_print( "Destroy help_image window.\n" );
	g_source_remove (help_timeout_id);
	help_timeout_id = 0;
}


/* Timeout handler to regenerate the frame */
static gint
help_frame_timeout (gpointer data)
{
#if 0
        if (gtk_debug) g_print( "frame_timeout().\n" );
#endif        
	gdk_pixbuf_copy_area (help_image, 0, 0, help_back_width, help_back_height,
			      help_frame, 0, 0);

	gtk_widget_queue_draw (help_da);

	help_frame_num++;
	return TRUE;
}

/* Write help in separate window */
void display_help_in_window(char * filename)
{
  help_image = gdk_pixbuf_new_from_file (filename, NULL);
  if (!help_image) {
    if (gtk_debug) g_print( "ERROR: cannot load fp_off image into buffer.\n" );
    return;
  }

  if (!help_window) {
    help_back_width = gdk_pixbuf_get_width (help_image);
    help_back_height = gdk_pixbuf_get_height (help_image);
    help_frame = gdk_pixbuf_new (GDK_COLORSPACE_RGB, FALSE, 8, help_back_width, help_back_height);
  }
  gdk_pixbuf_copy_area (help_image, 0, 0, help_back_width, help_back_height, help_frame, 0, 0);

  if (!help_window) {
     if (gtk_debug) g_print("Make new window.\n" );
     help_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
     gtk_widget_set_size_request (help_window, help_back_width, help_back_height);
     gtk_window_set_resizable (GTK_WINDOW (help_window), FALSE);
     gtk_window_set_title (GTK_WINDOW (help_window), "Help Window");	       
     gtk_window_move( GTK_WINDOW (help_window), 785, 1 );
     g_signal_connect (help_window, "destroy",
		       G_CALLBACK (help_destroy_cb), NULL);
     help_da = gtk_drawing_area_new ();
     g_signal_connect (help_da, "expose_event",
		       G_CALLBACK (help_expose_cb), NULL);
     gtk_container_add (GTK_CONTAINER (help_window), help_da);
     help_timeout_id = g_timeout_add (FRAME_DELAY, help_frame_timeout, NULL);	  
  }
  gtk_widget_show_all (help_window);	
  while( g_main_context_iteration(NULL,FALSE));       	
}


/* Capture single frame */

void EnterMessageCaptureCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "enter message callback (capture).\n" );
  MessageBuffer = capture_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}

void ReleaseMessageCaptureCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "release message callback (capture).\n" );
  MessageBuffer = release_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}

void CaptureCallback(GtkWidget *widget,
        GdkEvent *event,gpointer data) 
{
  int res;
  GtkWidget *dialog;
  GtkWidget  *window;    
    
  if (gtk_debug) g_print( "Capture.\n" );

  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);  
  
  res = detect_scanner_presence_in_system();
  if (res != 0) {
    if (gtk_debug) g_print( "ERROR: scanner not found.\n" );
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "Biometric fingerprint scanner not found!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }

  unlink_image_files();
  
  display_help_in_window(FINGER_ON_IMAGE);
  if (gtk_debug) g_print( "Start operation. Timeout %d seconds.\n", timeout );
  memset( raw_image_buf, 0, fp_image_size );
  res = bfp_get_image_timeo( raw_image_buf, fp_image_size, timeout, 0 );
  display_help_in_window(FINGER_OFF_IMAGE);  
  
  if (res < 0) {
    if (gtk_debug) g_print( "ERROR: no finger detected on scanner.\nTerminate.\n" );      
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "No finger detected on scanner!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }

  display_fp_image_in_window();

  if (gtk_debug) g_print( "Done.\n" );
  return;
}


/* Verification */

void EnterMessageVerifyCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "enter message callback (verify).\n" );
  MessageBuffer = capture_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}

void ReleaseMessageVerifyCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "release message callback (verify).\n" );
  MessageBuffer = release_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}


void VerifyCallback(GtkWidget *widget,
        GdkEvent *event,gpointer data) 
{
  GtkWidget  *dialog;
  gint response;  
  GtkWidget  *window;
  GtkWidget *hbox;
  GtkWidget *stock;
  GtkWidget *table;
  GtkWidget *local_entry1;
  GtkWidget *label;
#if 0
  GtkWidget *combo;
  GList *items = NULL;
#endif  
  int  username_found;
  char message[100];
  int  i;
  int  res;    
  int  found;
  char verify_user_name[MAX_USER_NAME_SIZE+1];  
  
  if (gtk_debug) g_print( "Verify.\n" );
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
#if 1  
  gtk_window_move( GTK_WINDOW(window), 320, 100 );
#endif
  
  if (db_users_num == 0) {
    if (gtk_debug) g_print( "ERROR: empty users database found.\n" );
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "Empty users database found!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }
  
#if 0
  for( i=0; i<db_users_num; i++ ) {
      items = g_list_append( items,user_templates_db[i].user_name); 
      if (gtk_debug) 
         g_print( "Add name %s to list.\n", user_templates_db[i].user_name );
  }
  combo = gtk_combo_new();
  gtk_widget_show(combo);  
  gtk_entry_set_text( GTK_ENTRY (GTK_COMBO(combo)->entry), "My String");
  gtk_entry_set_editable( GTK_ENTRY (GTK_COMBO(combo)->entry), FALSE );
  gtk_combo_set_popdown_strings( GTK_COMBO(combo),items );
  gtk_container_add(GTK_CONTAINER(window),combo);
  gtk_widget_show_all(window);  
#endif   

  dialog = gtk_dialog_new_with_buttons ("Interactive Dialog",
					GTK_WINDOW(window),
					GTK_DIALOG_MODAL| GTK_DIALOG_DESTROY_WITH_PARENT,
					GTK_STOCK_OK,
					GTK_RESPONSE_OK,
                                        GTK_STOCK_CANCEL,
                                        GTK_RESPONSE_CANCEL,
					NULL);

  hbox = gtk_hbox_new (FALSE, 8);
  gtk_container_set_border_width (GTK_CONTAINER (hbox), 8);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->vbox), hbox, FALSE, FALSE, 0);

  stock = gtk_image_new_from_stock (GTK_STOCK_DIALOG_QUESTION, GTK_ICON_SIZE_DIALOG);
  gtk_box_pack_start (GTK_BOX (hbox), stock, FALSE, FALSE, 0);

  table = gtk_table_new (2, 2, FALSE);
  gtk_table_set_row_spacings (GTK_TABLE (table), 4);
  gtk_table_set_col_spacings (GTK_TABLE (table), 4);
  gtk_box_pack_start (GTK_BOX (hbox), table, TRUE, TRUE, 0);
  label = gtk_label_new_with_mnemonic ("Username");
  gtk_table_attach_defaults (GTK_TABLE (table),
			     label,
			     0, 1, 0, 1);
  local_entry1 = gtk_entry_new ();
  gtk_table_attach_defaults (GTK_TABLE (table), local_entry1, 1, 2, 0, 1);
  gtk_label_set_mnemonic_widget (GTK_LABEL (label), local_entry1);

  gtk_widget_show_all (hbox);
  response = gtk_dialog_run (GTK_DIALOG (dialog));

  memset( verify_user_name, 0, sizeof(verify_user_name) );
  username_found = 1;
  if (response == GTK_RESPONSE_CANCEL) {
    username_found = 0;    
  }
  if (response == GTK_RESPONSE_OK)
  {
       strncpy( verify_user_name,  gtk_entry_get_text(GTK_ENTRY(local_entry1)), 
                  sizeof(verify_user_name)-1 );
       if (gtk_debug) g_print( "username: %s\n", verify_user_name );
       if (strlen(verify_user_name) == 0) username_found = 0;
  }
  
  gtk_widget_destroy (dialog);  

  if (username_found == 0) {
    if (gtk_debug) g_print( "ERROR: no user input.\nCancelled.\n" );
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "No username found!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }

  if (gtk_debug) g_print( "Search names space for requested name.\n" );
  found = 0;
  for( i=0; i<db_users_num; i++ ) {
      if (strcmp(verify_user_name,user_templates_db[i].user_name) == 0) {
        if (gtk_debug) g_print( "Matching name found. Record is %d.\n", i );
        found = 1;
        break;
      }
  }
  if (found == 0) {
    if (gtk_debug) g_print( "ERROR: this person is missing into database.\n" );
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "This person not found in database!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }

  res = detect_scanner_presence_in_system();
  if (res != 0) {
    if (gtk_debug) g_print( "ERROR: scanner not found.\n" );
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "Biometric fingerprint scanner not found!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }  

  unlink_image_files();  
  
  display_help_in_window(FINGER_ON_IMAGE);  
  if (gtk_debug) g_print( "Start operation. Timeout %d seconds.\n", timeout );
  memset( raw_image_buf, 0, fp_image_size );
  res = bfp_get_image_timeo( raw_image_buf, fp_image_size, timeout, 0 );
  display_help_in_window(FINGER_OFF_IMAGE);  
  
  if (res < 0) {
    if (gtk_debug) g_print( "ERROR: no finger detected on scanner.\nTerminate.\n" );      
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "No finger detected on scanner!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }
  
  display_fp_image_in_window();  
  
  if (gtk_debug) g_print( "OK. Image successfully captured.\n" );
  if (gtk_debug) g_print("Building model.\n");
  res = bfp_extract(raw_image_buf, 1, fp_model);
  if (res > 0) {
    if (gtk_debug) g_print( "Model OK. Size = %d\n", res );
  }
  else {
    if (gtk_debug) g_print( "Model BAD. Code = %d\nTerminate.\n", res );
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "Cannot build biometric model from captured image!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }
  if (gtk_debug) g_print( "Compare model and template for this person.\n" );
  res = bfp_match(fp_model, fp_model_size, user_templates_db[i].fp_template, 
                  user_templates_db[i].template_size );
  if (gtk_debug) g_print( "%d: user = %s, code = %d\n", i, user_templates_db[i].user_name, res );  
  found = 0;  
  memset( message, 0, sizeof(message) );
  if (res > 0) { 
      if (gtk_debug) g_print( "Candidate. Check measure.\n" );
      if (res < measure) {
        if (gtk_debug) g_print( "ERROR: has not enough power.\nWeak person.\n" );
        dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
	 			     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "Verification done. Mismatched person!" );
        gtk_dialog_run (GTK_DIALOG (dialog));
        gtk_widget_destroy (dialog);
        return;        
      }
      found++;
      strncat( message, "Verification successful. Person is ", sizeof(message)-1 );
      strncat( message, user_templates_db[i].user_name, sizeof(message)-1 );
      strncat( message, ".", sizeof(message)-1 );
      dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
	 			     GTK_MESSAGE_INFO,
				     GTK_BUTTONS_OK,
				     message );
      gtk_dialog_run (GTK_DIALOG (dialog));
      gtk_widget_destroy (dialog);
  }
  else {
    if (gtk_debug) g_print( "ERROR: bad person.\n" );
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
	 			     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "Verification done. Mismatched person!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }

  if (gtk_debug) g_print( "Done.\n" );  
  return;  
}


/* Identification */

void EnterMessageIdentifyCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "enter message callback (identify).\n" );
  MessageBuffer = capture_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}

void ReleaseMessageIdentifyCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "release message callback (identify).\n" );
  MessageBuffer = release_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}

void IdentifyCallback(GtkWidget *widget,
        GdkEvent *event,gpointer data) 
{
  int res;
  int i;
  int found;
  GtkWidget *dialog;
  GtkWidget  *window;  
  char message[100];

  if (gtk_debug) g_print( "Identify.\n" );
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  
  if (db_users_num == 0) {
    if (gtk_debug) g_print( "ERROR: empty users database found.\n" );
    dialog = gtk_message_dialog_new (GTK_WINDOW(window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "Empty users database found!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }
  
  res = detect_scanner_presence_in_system();
  if (res != 0) {
    if (gtk_debug) g_print( "ERROR: scanner not found.\n" );
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "Biometric fingerprint scanner not found!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }  
  
  unlink_image_files();  
  
  display_help_in_window(FINGER_ON_IMAGE);  
  if (gtk_debug) g_print( "Start operation. Timeout %d seconds.\n", timeout );
  memset( raw_image_buf, 0, fp_image_size );
  res = bfp_get_image_timeo( raw_image_buf, fp_image_size, timeout, 0 );
  display_help_in_window(FINGER_OFF_IMAGE);  
  
  if (res < 0) {
    if (gtk_debug) g_print( "ERROR: no finger detected on scanner.\nTerminate.\n" );      
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "No finger detected on scanner!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }

  display_fp_image_in_window();  
  
  if (gtk_debug) g_print( "OK. Image successfully captured.\n" );
  if (gtk_debug) g_print("Building model.\n");
  memset( fp_model, 0, sizeof(fp_model) );
  res = bfp_extract(raw_image_buf, 1, fp_model);
  if (res > 0) {
    if (gtk_debug) g_print( "Model OK. Size = %d\n", res );
  }
  else {
    if (gtk_debug) g_print( "Model BAD. Code = %d\nTerminate.\n", res );
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "Cannot build biometric model from captured image!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }
  if (gtk_debug) g_print( "Search database for identification.\n" );
  memset( message, 0, sizeof(message) );
  strncat( message, "Person(s):", sizeof(message)-1 );
  found = 0;
  for( i=0; i<db_users_num; i++ ) {
    res = bfp_match(fp_model, fp_model_size, user_templates_db[i].fp_template, 
                   user_templates_db[i].template_size );
    if (gtk_debug) g_print( "%d: user = %s, code = %d\n", i, user_templates_db[i].user_name, res );
    if (res > 0) { 
      if (gtk_debug) g_print( "Candidate. Check measure.\n" );
      if (res < measure) {
        if (gtk_debug) g_print( "Has not enough power. Skip this person.\n" );
        continue;
      }
      found++;
      if (gtk_debug) g_print( "Match Ok. Added to list.\n" );
      strncat( message, " ", sizeof(message)-1);
      strncat( message, user_templates_db[i].user_name, sizeof(message)-1);
    }
    else {
      if (gtk_debug) g_print( "Mismatch. Skip this person.\n" );
    }
  }
  if (found == 0) {
    if (gtk_debug) g_print( "ERROR: matching records not found.\n" );
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "No such person found!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }
  if (gtk_debug) g_print( "%s\n", message );
  dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  		   	           GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				   GTK_MESSAGE_INFO,
				   GTK_BUTTONS_OK,
				   message );
  gtk_dialog_run (GTK_DIALOG (dialog));
  gtk_widget_destroy (dialog);  
  return;
}


void EnterMessageEnrollCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "enter message callback (enroll).\n" );
  MessageBuffer = capture_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}


/* Enrollment */

void ReleaseMessageEnrollCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "release message callback (enroll).\n" );
  MessageBuffer = release_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}

void EnrollCallback(GtkWidget *widget,
        GdkEvent *event,gpointer data) 
{
  GtkWidget  *dialog;
  gint response;  
  GtkWidget  *window;
  GtkWidget *hbox;
  GtkWidget *stock;
  GtkWidget *table;
  GtkWidget *local_entry1;
  GtkWidget *label;
  int  username_found;
  int res;
  int i;
  unsigned char * p;
  char enroll_user_name[MAX_USER_NAME_SIZE+1];
  char message[100];

  if (gtk_debug) g_print( "Enroll.\n" );
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);  
  
  if (db_users_num >= MAX_USERS_NUM) {
    if (gtk_debug) g_print( "ERROR: user database is full.\n" );
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "User database full!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }
  
  res = detect_scanner_presence_in_system();  
  if (res != 0) {
    if (gtk_debug) g_print( "ERROR: scanner not found.\n" );
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "Biometric fingerprint scanner not found!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }  
  
  memset( enroll_images_buf, 0, fp_image_size*fp_images_num );
  p = enroll_images_buf;  

  display_help_in_window(FINGER_ON_IMAGE);    
  
  for( i=0; i<fp_images_num; i++ ) {
    unlink_image_files();  
    
    if (i > 0) {
      display_help_in_window(FINGER_OFF_IMAGE);    
      while( 1 ) {  
        res = bfp_get_image_timeo( raw_image_buf, fp_image_size, 2, 0 );
        if (gtk_debug) g_print( "get_image_result=%d\n", res );
        if (res != 0) break;
        else {
          if (gtk_debug) 
            g_print( "Please remove your fingers off our device!\n");
        }
      }
    }
    
    display_help_in_window(FINGER_ON_IMAGE);    
    if (gtk_debug) g_print( "Start operation %d. Timeout %d seconds.\n", i+1, timeout );
    res = bfp_get_image_timeo( p, fp_image_size, timeout, 0 );
    display_help_in_window(FINGER_OFF_IMAGE);    
    
    if (res < 0) {
      if (gtk_debug) g_print( "ERROR: no finger detected on scanner.\nTerminate.\n" );      
      dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "No finger detected on scanner!" );
      gtk_dialog_run (GTK_DIALOG (dialog));
      gtk_widget_destroy (dialog);
      return;
    }
    memcpy( raw_image_buf, p, fp_image_size );
    display_fp_image_in_window();          
    if (gtk_debug) g_print( "OK. Image successfully captured.\n" );  
    p += fp_image_size;
  }
  
  if (gtk_debug) g_print("Building template.\n");
  memset( fp_template, 0, fp_template_size );
  res = bfp_extract(enroll_images_buf, fp_images_num, fp_template);
  if (res > 0) {
    if (gtk_debug) g_print( "Template OK. Size = %d\n", res );
  }
  else {
    if (gtk_debug) g_print( "Template BAD. Code = %d\nTerminate.\n", res );
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "Cannot build biometric model from captured image!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }
  if (gtk_debug) g_print( "Ask username." );
  temp_user_record.user_name[0] = '\0';
  memcpy( temp_user_record.fp_template, fp_template, fp_template_size );
  temp_user_record.template_size = res;

  dialog = gtk_dialog_new_with_buttons ("Interactive Dialog",
					GTK_WINDOW(window),
					GTK_DIALOG_MODAL| GTK_DIALOG_DESTROY_WITH_PARENT,
					GTK_STOCK_OK,
					GTK_RESPONSE_OK,
                                        GTK_STOCK_CANCEL,
                                        GTK_RESPONSE_CANCEL,
					NULL);

  hbox = gtk_hbox_new (FALSE, 8);
  gtk_container_set_border_width (GTK_CONTAINER (hbox), 8);
  gtk_box_pack_start (GTK_BOX (GTK_DIALOG (dialog)->vbox), hbox, FALSE, FALSE, 0);

  stock = gtk_image_new_from_stock (GTK_STOCK_DIALOG_QUESTION, GTK_ICON_SIZE_DIALOG);
  gtk_box_pack_start (GTK_BOX (hbox), stock, FALSE, FALSE, 0);

  table = gtk_table_new (2, 2, FALSE);
  gtk_table_set_row_spacings (GTK_TABLE (table), 4);
  gtk_table_set_col_spacings (GTK_TABLE (table), 4);
  gtk_box_pack_start (GTK_BOX (hbox), table, TRUE, TRUE, 0);
  label = gtk_label_new_with_mnemonic ("Username");
  gtk_table_attach_defaults (GTK_TABLE (table),
			     label,
			     0, 1, 0, 1);
  local_entry1 = gtk_entry_new ();
  //gtk_entry_set_text (GTK_ENTRY (local_entry1), gtk_entry_get_text (GTK_ENTRY (entry1)));
  gtk_table_attach_defaults (GTK_TABLE (table), local_entry1, 1, 2, 0, 1);
  gtk_label_set_mnemonic_widget (GTK_LABEL (label), local_entry1);

  gtk_widget_show_all (hbox);
  response = gtk_dialog_run (GTK_DIALOG (dialog));

  memset( enroll_user_name, 0, sizeof(enroll_user_name) );
  username_found = 1;
  if (response == GTK_RESPONSE_CANCEL) {
    username_found = 0;    
  }
  if (response == GTK_RESPONSE_OK)
  {
       strncpy( enroll_user_name,  gtk_entry_get_text(GTK_ENTRY(local_entry1)), 
                  sizeof(enroll_user_name)-1 );
       if (gtk_debug) g_print( "username: %s\n", enroll_user_name );
       if (strlen(enroll_user_name) == 0) username_found = 0;
  }
  
  gtk_widget_destroy (dialog);  

  if (username_found == 0) {
    if (gtk_debug) g_print( "ERROR: no user input.\nCancelled.\n" );
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "No username found!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }

    if (gtk_debug) g_print( "Search names space for duplicates.\n" );
    for( i=0; i<MAX_USERS_NUM; i++ ) {
      if (strcmp(enroll_user_name,user_templates_db[i].user_name) == 0) {
        if (gtk_debug) g_print( "ERROR: duplicate name found.\n" );
        dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "Duplicate username found!" );
        gtk_dialog_run (GTK_DIALOG (dialog));
        gtk_widget_destroy (dialog);
        return;
      }
    }
    if (gtk_debug) g_print( "Duplicate names not found.\n" );
    i = db_users_num;
    if (gtk_debug) g_print( "Added record %d to database. User = %s\n", i+1, enroll_user_name );
    strncpy( user_templates_db[i].user_name, enroll_user_name, MAX_USER_NAME_SIZE );
    memcpy( user_templates_db[i].fp_template, temp_user_record.fp_template, 
            fp_template_size );
    user_templates_db[i].template_size = temp_user_record.template_size;
    db_users_num++;
    if (gtk_debug) g_print( "Users per database = %d\n", db_users_num );
    sprintf(message,"User %s added to database.\n", 
            user_templates_db[i].user_name);    

  dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  		   	           GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				   GTK_MESSAGE_INFO,
				   GTK_BUTTONS_OK,
				   message );
  gtk_dialog_run (GTK_DIALOG (dialog));
  gtk_widget_destroy (dialog);  

  if (gtk_debug) g_print( "Done.\n" );  
  return;  
}


/* Miscellaneous */

int detect_scanner_presence_in_system(void)
{
  int  res;
  struct bfp_hardware_info  bfp_hw_param;

  res = bfp_get_hardware_info( &bfp_hw_param, 0 );
  if (res != 0) {
    g_print( "ERROR: bfp_get_hardware_param() failed, code=%d\n", res );
    return(-1);
  }

  if (gtk_debug) g_print( "BFP scanner found.\n" );

  return res;
}


/* Run another program */
int  run_this_program( char * program, char * parameters )
{
  int      res = 1;
  pid_t    pid;
  int      status = -1;
  char     cmdstr[256];

  if ((program == NULL) || (parameters == NULL))
    return(res);

  memset( cmdstr, 0, sizeof(cmdstr) );
  strncpy( cmdstr, program, sizeof(cmdstr) );
  strncat( cmdstr, " ", sizeof(cmdstr)-(strlen(cmdstr)+1) );  
  strncat( cmdstr, parameters, sizeof(cmdstr)-(strlen(cmdstr)+1) );
  
  switch( pid = fork()) {
    case -1: 
           if (gtk_debug) g_print( "ERROR: fork failed!\n" );
           res = 2;
           break;
    case 0:
          /* child */
          execl( "/bin/sh", "sh","-c", cmdstr, NULL,NULL );
          if (gtk_debug) g_print( "ERROR: exec faled!" );
          res = 3;
          break;
    default:
          wait(&status);
          if (gtk_debug) g_print( "exec running.\n" );
          res = WEXITSTATUS(status);          
          if (gtk_debug) g_print( "exec done. code = %d\n", res );
          break;
  }

  return(res);
}
