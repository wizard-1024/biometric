/** ncurses-demo.c **/
/* Copyright (C) 2003-2004 Dmitry Stefankov */

#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <menu.h>
#include <curses.h>

#include <bfpsdk.h>

/* Constants */
#define  MAX_USERS_NUM   1024
#define  MAX_USER_NAME_SIZE  64

static const char rcs_id[] = "$Id: ncurses-demo.c,v 1.3 2004-12-02 16:19:44+03 dstef Exp root $";

/* BFP measurement level */
int measure = 0;

/* N seconds to detect finger presence */
int  fp_timeout = 30;          

struct fp_user_template {
  int            template_size;
  unsigned char  * fp_template;
  char           user_name[MAX_USER_NAME_SIZE+1];
};

/* Current users number */
int  db_users_num = 0;

struct fp_user_template  temp_user_record;
struct fp_user_template  user_templates_db[MAX_USERS_NUM];

unsigned char   * fp_model = NULL;
unsigned char   * fp_template = NULL;
unsigned char   * raw_image_buf = NULL;
unsigned char   * enroll_images_buf;  

int             fp_model_size = 0;
int             fp_template_size = 0;
int             fp_images_num = 0;
unsigned int    fp_image_size = 0;
struct bfp_software_info  bfp_param; 


/* Functions */
void enroll_user(void );
void list_users(void );
void verify_user(void );
void identify_user(void );
void shutdown();
int  detect_scanner_presence_in_system(void);    

#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))
#define CTRLD 	4

char *choices[] = {
                        "Enroll",
                        "Identify",
                        "Verify",
                        "List",
                        "Exit",
                        (char *)NULL,
                  };
		  
char *choices_help[] = {
                        "User enrollment",
                        "User identification",
                        "User verification",
                        "List all current users",
                        "Exit",
                        (char *)NULL,
                  };
		  
void print_in_middle(WINDOW *win, int starty, int startx, int width, char *string, chtype color);

void print_status_message( char * msg)
{
  mvprintw( LINES -2, 0, 
            "                                                                      " );
  refresh();
  mvprintw(LINES - 2, 0, msg );
  refresh();
}

void func(char *name);
void force_exit(void);

int main()
{	ITEM **my_items;
	int c;				
	MENU *my_menu;
        WINDOW *my_menu_win;
        int n_choices;
        int res;
        int i;

    /* Init BFP dynamic library */
    res = bfp_init();  
    if (res != 0) {
      printf("FATAL ERROR: cannot init BFP library!\n");
      exit(1);
    }

    memset( &bfp_param, 0, sizeof(bfp_param) );
    res = bfp_get_software_info( &bfp_param );
    if (res != 0) {
       printf("FATAL_ERROR: bfp_get_software_param() failed, code=%d\n", res);
       exit(1);
    } 

    measure = bfp_param.measure;
    fp_model_size = bfp_param.model_size;
    fp_template_size = bfp_param.total_size;
    fp_images_num = bfp_param.samples_num;
    fp_image_size = bfp_param.image_size;
    
    fp_model = malloc(fp_model_size);
    if (fp_model == NULL) {
      printf( "Cannot allocate memory for model!\n" );
      exit(1);
    }
    
    fp_template = malloc(fp_template_size);
    if (fp_template == NULL) {
      printf( "Cannot allocate memory for template!\n" );
      exit(1);
    }

    raw_image_buf = malloc(fp_image_size*1);
    if (raw_image_buf == NULL) {
      printf( "Cannot allocate memory for image buffer!\n" );
      exit(1);
    }

    enroll_images_buf = malloc(fp_image_size*fp_images_num);
    if (enroll_images_buf == NULL) {
      printf( "Cannot allocate memory for images buffer!\n" );
      exit(1);
    }

    temp_user_record.fp_template = malloc(fp_template_size);
    if (temp_user_record.fp_template == NULL) {
      printf( "Cannot allocate memory for template buffer!\n" );
      exit(1);
    }
    
    memset( user_templates_db, 0, sizeof(user_templates_db) );
    for( i=0; i<MAX_USERS_NUM; i++) {
       user_templates_db[i].fp_template = malloc(fp_template_size);
       if (user_templates_db[i].fp_template == NULL) {
         printf( "Cannot allocate memory for templates buffer!\n" );
         exit(1);
       }
    }
	
	/* Initialize curses */
	initscr();
	start_color();
        cbreak();
        noecho();
	keypad(stdscr, TRUE);
	init_pair(1, COLOR_RED, COLOR_BLACK);

	/* Create items */
        n_choices = ARRAY_SIZE(choices);
        my_items = (ITEM **)calloc(n_choices, sizeof(ITEM *));
        for(i = 0; i < n_choices; ++i)  {
                my_items[i] = new_item(choices[i], choices_help[i]);
		/* Set the user pointer */
		if (i == 0) set_item_userptr(my_items[i], enroll_user);
		if (i == 1) set_item_userptr(my_items[i], identify_user);		
		if (i == 2) set_item_userptr(my_items[i], verify_user);
		if (i == 3) set_item_userptr(my_items[i], list_users);
		if (i == 4) set_item_userptr(my_items[i], force_exit);				
        }
	my_items[n_choices] = (ITEM *)NULL;        
	/* Create menu */
	my_menu = new_menu((ITEM **)my_items);

	/* Create the window to be associated with the menu */
        my_menu_win = newwin(10, 40, 4, 4);
        keypad(my_menu_win, TRUE);
     
	/* Set main window and sub window */
        set_menu_win(my_menu, my_menu_win);
        set_menu_sub(my_menu, derwin(my_menu_win, 6, 38, 3, 1));

	/* Set menu mark to the string " * " */
        set_menu_mark(my_menu, " * ");

	/* Print a border around the main window and print a title */
        box(my_menu_win, 0, 0);
	print_in_middle(my_menu_win, 1, 0, 40, "BFP Application NCurses-Demo Menu", COLOR_PAIR(1));
	mvwaddch(my_menu_win, 2, 0, ACS_LTEE);
	mvwhline(my_menu_win, 2, 1, ACS_HLINE, 38);
	mvwaddch(my_menu_win, 2, 39, ACS_RTEE);
	print_status_message("F10 to exit");
	refresh();
        
	/* Post the menu */
	post_menu(my_menu);
	wrefresh(my_menu_win);

	while((c = wgetch(my_menu_win)) != KEY_F(10))
	{       
	        print_status_message("F10 to exit");
	        switch(c)
	        {	case KEY_DOWN:
				menu_driver(my_menu, REQ_DOWN_ITEM);
				break;
			case KEY_UP:
				menu_driver(my_menu, REQ_UP_ITEM);
				break;
			case 10: /* Enter */ 
			        {  ITEM *cur;
				   void (*p)(char *);
				   cur = current_item(my_menu);
				   p = item_userptr(cur);
				   p((char *)item_name(cur));
				   pos_menu_cursor(my_menu);
				   break;
			        }
			        break;				
		}
                wrefresh(my_menu_win);
	}	

	/* Unpost and free all the memory taken up */
        unpost_menu(my_menu);
        free_menu(my_menu);
        for(i = 0; i < n_choices; ++i)
                free_item(my_items[i]);
	endwin();

        shutdown();	
	return(0);
}

void print_in_middle(WINDOW *win, int starty, int startx, int width, char *string, chtype color)
{	int length, x, y;
	float temp;

	if(win == NULL)
		win = stdscr;
	getyx(win, y, x);
	if(startx != 0)
		x = startx;
	if(starty != 0)
		y = starty;
	if(width == 0)
		width = 80;

	length = strlen(string);
	temp = (width - length)/ 2;
	x = startx + (int)temp;
	wattron(win, color);
	mvwprintw(win, y, x, "%s", string);
	wattroff(win, color);
	refresh();
}

void func(char *name)
{	
    char buf[80];
    
    snprintf(buf, sizeof(buf)-1, "Item selected is : %s", name );
    print_status_message(buf);
}	

void force_exit(void)
{
  ungetch( KEY_F(10) );
}

/* Destroy before exit */
void shutdown() {
    int res;
    int i;
    
    res = bfp_deinit();    
    if (fp_model != NULL) free(fp_model);
    if (fp_template != NULL) free(fp_template);
    if (raw_image_buf != NULL) free(raw_image_buf);    
    if (enroll_images_buf != NULL) free(enroll_images_buf);
    if (temp_user_record.fp_template != NULL) free(temp_user_record.fp_template);
    for( i=0; i<MAX_USERS_NUM; i++) {
       free(user_templates_db[i].fp_template);
    }
}

/* Miscellaneous */
int detect_scanner_presence_in_system(void)
{
  int  res;
  struct bfp_hardware_info  bfp_hw_param;
  char buf[80];

  res = bfp_get_hardware_info( &bfp_hw_param, 0 );
  if (res != 0) {
    snprintf( buf, sizeof(buf)-1, 
             "ERROR: bfp_get_hardware_param() failed, code=%d.", res );
    print_status_message(buf);             
    return(-1);
  }

  return res;
}


/* Display current users per database */
void list_users(void )
{
  char buf[80];

  snprintf( buf, sizeof(buf)-1, "Sorry, not implemented." );
  print_status_message(buf);             
}


/* Enrollment */
void enroll_user(void )
{
  int  username_found;
  int res;
  int i;
  unsigned char * p;
  char enroll_user_name[MAX_USER_NAME_SIZE+1];
  char buf[80];

  if (db_users_num >= MAX_USERS_NUM) {
    snprintf( buf, sizeof(buf)-1, "ERROR: user database is full!" );
    print_status_message(buf);
    return;
  }
  
  res = detect_scanner_presence_in_system();  
  if (res != 0) {
    snprintf( buf, sizeof(buf)-1, "ERROR: scanner not found!" );
    print_status_message(buf);
    return;
  }  
  
  memset( enroll_images_buf, 0, fp_image_size*fp_images_num );
  p = enroll_images_buf;  

  for( i=0; i<fp_images_num; i++ ) {
    
    if (i > 0) {
      while( 1 ) {  
        res = bfp_get_image_timeo( raw_image_buf, fp_image_size, 2, 0 );
        if (res != 0) break;
        snprintf( buf, sizeof(buf)-1, 
                  "Please remove your fingers off our device!");
        print_status_message(buf);          
      }
    }

    snprintf( buf, sizeof(buf)-1, 
              "Put your finger ON scanner. Start capture image %d. Timeout %d seconds.", 
              i+1, fp_timeout );
    print_status_message(buf);              
    res = bfp_get_image_timeo( p, fp_image_size, fp_timeout, 0 );
    
    if (res < 0) {
      snprintf( buf, sizeof(buf)-1, "ERROR: no finger detected on scanner.Terminate." );      
      print_status_message(buf);
      return;
    }
    memcpy( raw_image_buf, p, fp_image_size );
    p += fp_image_size;
    snprintf( buf, sizeof(buf)-1, "Put your finger OFF scanner." );
    print_status_message(buf);
    sleep(1);
  }
  
  snprintf( buf, sizeof(buf)-1,"Build template.");
  print_status_message(buf);
  memset( fp_template, 0, fp_template_size );
  res = bfp_extract(enroll_images_buf, fp_images_num, fp_template);
  if (res > 0) {
    snprintf( buf, sizeof(buf)-1, "Template OK." );
    print_status_message(buf);
  }
  else {
    snprintf( buf, sizeof(buf)-1, "Template BAD. Code = %d. Terminate.", res );
    print_status_message(buf);
    return;
  }
  
  temp_user_record.user_name[0] = '\0';
  memcpy( temp_user_record.fp_template, fp_template, fp_template_size );
  temp_user_record.template_size = res;

  memset( enroll_user_name, 0, sizeof(enroll_user_name) );
  snprintf( buf, sizeof(buf)-1, "Enter username: " );
  print_status_message(buf);
  echo();
#if __NetBSD__
  getstr( enroll_user_name );
#else  
  getnstr( enroll_user_name, sizeof(enroll_user_name)-1 );
#endif  
  noecho();
  
  username_found = 1;
  if (strlen(enroll_user_name) < 1) {
    username_found = 0;    
  }
  
  if (username_found == 0) {
    snprintf( buf, sizeof(buf)-1, "ERROR: no user input. Cancelled." );
    print_status_message(buf);
    return;
  }

  for( i=0; i<MAX_USERS_NUM; i++ ) {
      if (strcmp(enroll_user_name,user_templates_db[i].user_name) == 0) {
        snprintf( buf, sizeof(buf)-1, "ERROR: duplicate name found!" );
        print_status_message(buf);
        return;
      }
  }

  i = db_users_num;
  snprintf( buf, sizeof(buf)-1, "Added record %d to database. User = %s.", 
            i+1, enroll_user_name );
  print_status_message(buf);          
  strncpy( user_templates_db[i].user_name, enroll_user_name, MAX_USER_NAME_SIZE );
  memcpy( user_templates_db[i].fp_template, temp_user_record.fp_template, 
            fp_template_size );
  user_templates_db[i].template_size = temp_user_record.template_size;
  db_users_num++;

  return;  
}


/* Identification */

void identify_user(void)
{
  int res;
  int i;
  int found;
  char message[100];
  char buf[80];
  
  if (db_users_num == 0) {
    snprintf( buf, sizeof(buf)-1, "ERROR: empty users database found!" );
    print_status_message(buf);          
    return;
  }
  
  res = detect_scanner_presence_in_system();
  if (res != 0) {
    snprintf( buf, sizeof(buf)-1, "ERROR: scanner not found!" );
    print_status_message(buf);          
    return;
  }  

  snprintf( buf, sizeof(buf)-1, 
            "Put your finger ON scanner. Start capture image. Timeout %d seconds.", 
            fp_timeout );
  print_status_message(buf);          
  memset( raw_image_buf, 0, fp_image_size );
  res = bfp_get_image_timeo( raw_image_buf, fp_image_size, fp_timeout, 0 );
  snprintf( buf, sizeof(buf)-1, "Put your finger OFF scanner." );  
  print_status_message(buf);

  if (res < 0) {
    snprintf( buf, sizeof(buf)-1, 
              "ERROR: no finger detected on scanner.Terminate." );      
    print_status_message(buf);          
    return;
  }

  snprintf( buf, sizeof(buf)-1,"Build model.");
  print_status_message(buf);
  memset( fp_model, 0, sizeof(fp_model) );
  res = bfp_extract(raw_image_buf, 1, fp_model);
  if (res > 0) {
    snprintf( buf, sizeof(buf)-1, "Model OK." );
    print_status_message(buf);
  }
  else {
    snprintf( buf, sizeof(buf)-1, "Model BAD. Code = %d. Terminate.", res );
    print_status_message(buf);
    return;
  }
  
  memset( message, 0, sizeof(message) );
  strncat( message, "Person(s):", sizeof(message)-1 );
  found = 0;
  for( i=0; i<db_users_num; i++ ) {
    res = bfp_match(fp_model, fp_model_size, user_templates_db[i].fp_template, 
                   user_templates_db[i].template_size );
    if (res > 0) { 
      if (res < measure) {
        continue;
      }
      found++;
      strncat( message, " ", sizeof(message)-1);
      strncat( message, user_templates_db[i].user_name, sizeof(message)-1);
    }
    else {
    }
  }
  if (found == 0) {
    snprintf( buf, sizeof(buf)-1, "ERROR: No such person(s) found!" );
    print_status_message(buf);
    return;
  }
  snprintf( buf, sizeof(buf)-1, "%s", message );
  print_status_message(buf);
  
  return;
}


/* Verification */

void verify_user(void)
{
  int  username_found;
  char message[100];
  int  i;
  int  res;    
  int  found;
  char verify_user_name[MAX_USER_NAME_SIZE+1];  
  char buf[80];
  
  if (db_users_num == 0) {
    snprintf( buf, sizeof(buf)-1, "ERROR: empty users database found!" );
    print_status_message(buf);
    return;
  }
  
  memset( verify_user_name, 0, sizeof(verify_user_name) );
  snprintf( buf, sizeof(buf)-1, "Enter username: " );
  print_status_message(buf);
  echo();
#if __NetBSD__  
  getstr( verify_user_name );
#else  
  getnstr( verify_user_name, sizeof(verify_user_name)-1 );  
#endif  
  noecho();
  
  username_found = 1;
  if (strlen(verify_user_name) < 1) {
    username_found = 0;    
  }
  
  if (username_found == 0) {
    snprintf( buf, sizeof(buf)-1, "ERROR: no user input. Cancelled." );
    print_status_message(buf);
    return;
  }

  found = 0;
  for( i=0; i<db_users_num; i++ ) {
      if (strcmp(verify_user_name,user_templates_db[i].user_name) == 0) {
        snprintf( buf, sizeof(buf)-1, "Matching name found. Record is %d.", i );
        print_status_message(buf);
        found = 1;
        break;
      }
  }
  
  if (found == 0) {
    snprintf( buf, sizeof(buf)-1, "ERROR: this person is missing into database!" );
    print_status_message(buf);
    return;
  }

  res = detect_scanner_presence_in_system();
  if (res != 0) {
    snprintf( buf, sizeof(buf)-1, "ERROR: scanner not found." );
    print_status_message(buf);
    return;
  }  

  snprintf( buf, sizeof(buf)-1, 
            "Put your finger ON scanner. Start capture image. Timeout %d seconds.", 
            fp_timeout );
  print_status_message(buf);          
  memset( raw_image_buf, 0, fp_image_size );
  res = bfp_get_image_timeo( raw_image_buf, fp_image_size, fp_timeout, 0 );
  snprintf( buf, sizeof(buf)-1, "Put your finger OFF scanner." );  
  print_status_message(buf);
  
  if (res < 0) {
    snprintf( buf, sizeof(buf)-1, "ERROR: no finger detected on scanner. Terminate." );      
    print_status_message(buf);
    return;
  }
  
  snprintf( buf, sizeof(buf)-1,"Build model.");
  print_status_message(buf);
  res = bfp_extract(raw_image_buf, 1, fp_model);
  if (res > 0) {
    snprintf( buf, sizeof(buf)-1, "Model OK." );
    print_status_message(buf);
  }
  else {
    snprintf( buf, sizeof(buf)-1, "Model BAD. Code = %d. Terminate.", res );
    print_status_message(buf);
    return;
  }
  
  res = bfp_match(fp_model, fp_model_size, user_templates_db[i].fp_template, 
                  user_templates_db[i].template_size );
                  
  found = 0;  
  memset( message, 0, sizeof(message) );
  if (res > 0) { 
      if (res < measure) {
        snprintf( buf, sizeof(buf)-1, "ERROR: Bad person!" );
        print_status_message(buf);
        return;        
      }
      found++;
      strncat( message, "Verification successful. Person is ", sizeof(message)-1 );
      strncat( message, user_templates_db[i].user_name, sizeof(message)-1 );
      strncat( message, ".", sizeof(message)-1 );
      snprintf( buf, sizeof(buf)-1, message );
      print_status_message(buf);
  }
  else {
    snprintf( buf, sizeof(buf)-1, "ERROR: Mismatched person!" );
    print_status_message(buf);
    return;
  }

  return;
}
