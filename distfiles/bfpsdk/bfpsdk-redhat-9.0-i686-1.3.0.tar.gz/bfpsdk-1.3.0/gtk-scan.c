/** gtk-scan.c **/
/* Copyright (C) 2004 Dmitry Stefankov */

#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>

#include <bfpsdk.h>


/* Constants */
#define SCREEN_WIDTH  320
#define SCREEN_HEIGHT 480

#define BUTTON_FIXED_X_POS  80
#define BUTTON_FIXED_Y_POS  100
#define Y_STEP              50

static const char rcs_id[] = "$Id: gtk-scan.c,v 1.2 2004-11-13 23:35:59+03 dstef Exp root $";

/* 1=debug on, 0=debug off */
int gtk_debug = 0;

#define CYCLE_LEN 60
#define FRAME_DELAY 50

/* N seconds to detect finger presence */
int  timeout = 0;          

/* Running flag */
int save_image = 0;
int scan_run = 0;

unsigned char   * raw_image_buf = NULL;

unsigned int    fp_image_size = 0;
struct bfp_software_info  bfp_param; 

static void shutdown();

/* Callbacks */
gint eventDelete(GtkWidget *widget,GdkEvent *event,gpointer data);
gint eventDestroy(GtkWidget *widget,GdkEvent *event,gpointer data);

void CaptureCallback( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void StopCallback( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void SaveCallback( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void EnrollCallback( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void ExitCallback( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void EnterMessageCaptureCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void ReleaseMessageCaptureCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void EnterMessageStopCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void ReleaseMessageStopCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void EnterMessageSaveCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void ReleaseMessageSaveCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void EnterMessageEnrollCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);
void ReleaseMessageEnrollCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data);


/* Miscellaneous */
int  run_this_program( char * program, char * parameters );
int  detect_scanner_presence_in_system(void);
void unlink_image_files(void);


/* Background image */
static int back_width, back_height;

/* Images */
static GdkPixbuf *frame;
static GdkPixbuf *image;

/* Widgets */
static GtkWidget *da;

static int frame_num;
static guint timeout_id;

/* Text message buffer */
static GtkWidget *TextMessageLabel;
char * MessageBuffer = NULL;
char release_message[]  = "MSG_BUF: Select your action using button press.";
char capture_message[]  = "MSG_BUF: Follow instructions in help window.   ";
char init_message[]     = "MSG_BUF: Select your action using button press.";
    

/* Main application */
int main(int argc,char *argv[])
{
    GtkWidget *topLevelWindow;
    GtkWidget *image;      
    GtkWidget *fixed;    
    GtkWidget *Button1;
    GtkWidget *Button2;    
    GtkWidget *Button3;
    GtkWidget *Button4;        
    GtkWidget *Button5;            
    int res;
    GtkTooltips *button_tips;    

    /* Init application */
	gtk_init(&argc,&argv);
	topLevelWindow = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(topLevelWindow),
            SCREEN_WIDTH,SCREEN_HEIGHT);
      gtk_window_set_title (GTK_WINDOW (topLevelWindow), "GTK BFPSDK ScanDemo Sample Application");	
      
    gtk_signal_connect(GTK_OBJECT(topLevelWindow),
            "delete_event",
            GTK_SIGNAL_FUNC(eventDelete),
            NULL);
    gtk_signal_connect(GTK_OBJECT(topLevelWindow),
            "destroy",
            GTK_SIGNAL_FUNC(eventDestroy),
            NULL);

    /* Add tooltips */
    button_tips = gtk_tooltips_new();
    
       fixed = gtk_fixed_new();
       gtk_widget_show(fixed);
       
    /* Add buttons into fixed container */
    Button1 = gtk_button_new_with_label("Scanning");
    gtk_signal_connect(GTK_OBJECT(Button1),
            "pressed",
            GTK_SIGNAL_FUNC(CaptureCallback),
            NULL);
    gtk_signal_connect(GTK_OBJECT(Button1),
            "enter",
            GTK_SIGNAL_FUNC(EnterMessageCaptureCallBack),
            NULL);            
    gtk_signal_connect(GTK_OBJECT(Button1),
            "released",
            GTK_SIGNAL_FUNC(ReleaseMessageCaptureCallBack),
            NULL);                        
    gtk_widget_show(Button1);
    gtk_fixed_put(GTK_FIXED(fixed),Button1, BUTTON_FIXED_X_POS, 
                            (BUTTON_FIXED_Y_POS+0*Y_STEP) );
    gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),Button1,
                         "Capture a fingerprint from scanner continuously.",
                          "Please put your finger on scanner after pressing on button.\
                           Automatical timeout is 0 seconds to detect finger on scanner.\
                           This operation captures a full fingerprint."
                          );

    Button2 = gtk_button_new_with_label("Stopping");
    gtk_signal_connect(GTK_OBJECT(Button2),
            "clicked",
            GTK_SIGNAL_FUNC(StopCallback),
            NULL);
    gtk_signal_connect(GTK_OBJECT(Button2),
            "enter",
            GTK_SIGNAL_FUNC(EnterMessageStopCallBack),
            NULL);            
    gtk_signal_connect(GTK_OBJECT(Button2),
            "released",
            GTK_SIGNAL_FUNC(ReleaseMessageStopCallBack),
            NULL);                        
    gtk_widget_show(Button2);
    gtk_fixed_put(GTK_FIXED(fixed),Button2, BUTTON_FIXED_X_POS, 
                    (BUTTON_FIXED_Y_POS+1*Y_STEP) );
    gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),Button2,
                         "Stop fingerprint capture from scanner.",
                         "No special action." 
                         );
                         
    Button3 = gtk_button_new_with_label("Saving  ");
    gtk_signal_connect(GTK_OBJECT(Button3),
            "clicked",
            GTK_SIGNAL_FUNC(SaveCallback),
            NULL);
    gtk_signal_connect(GTK_OBJECT(Button3),
            "enter",
            GTK_SIGNAL_FUNC(EnterMessageSaveCallBack),
            NULL);            
    gtk_signal_connect(GTK_OBJECT(Button3),
            "released",
            GTK_SIGNAL_FUNC(ReleaseMessageSaveCallBack),
            NULL);                        
    gtk_widget_show(Button3);
    gtk_fixed_put(GTK_FIXED(fixed),Button3, BUTTON_FIXED_X_POS,
                    (BUTTON_FIXED_Y_POS+2*Y_STEP) );    
    gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),Button3,
                         "Saving last image.", 
                         "Not implemented yet."
                          );

    Button4 = gtk_button_new_with_label("Nothing ");
    gtk_signal_connect(GTK_OBJECT(Button4),
            "clicked",
            GTK_SIGNAL_FUNC(EnrollCallback),
            NULL);
    gtk_signal_connect(GTK_OBJECT(Button4),
            "enter",
            GTK_SIGNAL_FUNC(EnterMessageEnrollCallBack),
            NULL);            
    gtk_signal_connect(GTK_OBJECT(Button4),
            "released",
            GTK_SIGNAL_FUNC(ReleaseMessageEnrollCallBack),
            NULL);                        
    gtk_widget_show(Button4);
    gtk_fixed_put(GTK_FIXED(fixed),Button4, BUTTON_FIXED_X_POS,
                    (BUTTON_FIXED_Y_POS+3*Y_STEP) );    
    gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),Button4,
                         "Nothing.", 
                         "Not implemented yet." 
                         );

    Button5 = gtk_button_new_with_label("Exit    ");
    gtk_signal_connect(GTK_OBJECT(Button5),
            "clicked",
            GTK_SIGNAL_FUNC(ExitCallback),
            NULL);
    gtk_widget_show(Button5);
    gtk_fixed_put(GTK_FIXED(fixed),Button5, BUTTON_FIXED_X_POS,
                    (BUTTON_FIXED_Y_POS+5*Y_STEP) );    
    gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),Button5,
                         "Exit this program.", 
                         "Please come back into this world." 
                         );

    MessageBuffer = init_message;
    TextMessageLabel = gtk_label_new(MessageBuffer);
    gtk_widget_show(TextMessageLabel);    
    gtk_fixed_put(GTK_FIXED(fixed),TextMessageLabel, BUTTON_FIXED_X_POS, 420 );
                             
    /* Add nice penguin */
    image = gtk_image_new_from_file ("logo.png");    
    gtk_widget_show(image);
    gtk_fixed_put(GTK_FIXED(fixed),image, BUTTON_FIXED_X_POS+100, 50 );    

    gtk_container_add(GTK_CONTAINER(topLevelWindow),
            fixed);

    gtk_widget_show(topLevelWindow);

    /* Init BFP dynamic library */
    res = bfp_init();  
    if (res != 0) {
      if (gtk_debug) g_print("FATAL ERROR: cannot init BFP library!\n");
      exit(1);
    }

    memset( &bfp_param, 0, sizeof(bfp_param) );
    res = bfp_get_software_info( &bfp_param );
    if (res != 0) {
     if (gtk_debug) 
       g_print("FATAL_ERROR: bfp_get_software_param() failed, code=%d\n", res);
       exit(1);
    } 

    fp_image_size = bfp_param.image_size;
    if (gtk_debug) g_print( "image_size = %d\n", fp_image_size );    
    
    raw_image_buf = g_malloc(fp_image_size);
    if (raw_image_buf == NULL) {
      if (gtk_debug)  g_print( "Cannot allocate memory for one image buffer!\n" );
      exit(1);
    }

    if (gtk_debug) g_print("Enter main application loop.\n");	

    /* Main application loop */
    gtk_main();
    if (gtk_debug) g_print("Done!\n");	
    exit(0);
}


gint eventDelete(GtkWidget *widget,GdkEvent *event,gpointer data) {
    if (gtk_debug) g_print("Delete window.\n.");
    return(FALSE);
}


gint eventDestroy(GtkWidget *widget,GdkEvent *event,gpointer data) {
    shutdown();
    return(0);
}


/* Destroy before exit */
void shutdown() {
    int res;
    
    if (gtk_debug) g_print("Shutting down\n");        
    if (scan_run == 1) {
      if (gtk_debug) g_print("Stop a running scan.\n");            
      scan_run = 0;
      sleep(2);
    }
    res = bfp_deinit();    
    if (save_image == 0) unlink_image_files();
    if (raw_image_buf != NULL) g_free(raw_image_buf);    
    gtk_main_quit();
}


void ExitCallback( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  shutdown();
  return;
}        


/* Wipe temporary files */
void unlink_image_files(void)
{
  unlink("image.png" );  
  unlink("image.bin" );  
}

/* Expose callback for the drawing area */
static gint
expose_cb (GtkWidget *widget, GdkEventExpose *event, gpointer data)
{
	guchar *pixels;
	int rowstride;
#if 0
        if (gtk_debug) g_print( "Redraw fp_image window.\n" );
#endif        
	gdk_pixbuf_copy_area (image, 0, 0, back_width, back_height, frame, 0, 0);
        
	rowstride = gdk_pixbuf_get_rowstride (frame);

	pixels = gdk_pixbuf_get_pixels (frame) + rowstride * event->area.y + event->area.x;
		  
	gdk_draw_rgb_image_dithalign (widget->window,
				      widget->style->black_gc,
				      event->area.x, event->area.y,
				      event->area.width, event->area.height,
				      GDK_RGB_DITHER_NORMAL,
				      pixels, rowstride,
				      event->area.x, event->area.y);

	return TRUE;
}


/* Destroy handler for the window */
static void
destroy_cb (GtkObject *object, gpointer data)
{
        if (gtk_debug) g_print( "Destroy fp_image window.\n" );
	g_source_remove (timeout_id);
	timeout_id = 0;
}


/* Timeout handler to regenerate the frame */
static gint
frame_timeout (gpointer data)
{
#if 0
        if (gtk_debug) g_print( "frame_timeout().\n" );
#endif        
	gdk_pixbuf_copy_area (image, 0, 0, back_width, back_height,
			      frame, 0, 0);

	gtk_widget_queue_draw (da);

	frame_num++;
	return TRUE;
}

void PutMessageText( char * message )
{
  if (gtk_debug) g_print( "new message text.\n" );
  MessageBuffer = message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}

/* Write fingerprint images in separate window */
void display_fp_image_in_window(void)
{
  static GtkWidget  *image_window = NULL;      
  FILE * fp;
  int res;

  fp = fopen( "image.bin", "w" );
  if (fp != NULL) {
    fwrite( raw_image_buf,fp_image_size,1,fp );
    fclose(fp);
     /* Image conversion */
#if __linux__     
     res = run_this_program( "/usr/bin/convert", 
#else
#if __FreeBSD__
     res = run_this_program( "/usr/local/bin/convert", 
#else
#error Unsupported OS found
#endif
#endif     
                  "-depth 8 -size 320x480 gray:image.bin image.png");
     if (res == 0) {              
        if (gtk_debug) g_print( "Load new image.\n" );
	image = gdk_pixbuf_new_from_file ("image.png", NULL);
	if (!image) {
		if (gtk_debug) g_print( "ERROR: cannot load image into buffer.\n" );
		return;
	}

        if (!image_window) {
	  back_width = gdk_pixbuf_get_width (image);
	  back_height = gdk_pixbuf_get_height (image);
	  frame = gdk_pixbuf_new (GDK_COLORSPACE_RGB, FALSE, 8, back_width, back_height);
	}
	gdk_pixbuf_copy_area (image, 0, 0, back_width, back_height, frame, 0, 0);

        if (!image_window) {
          if (gtk_debug) g_print("Make new window.\n" );
	  image_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  	  gtk_widget_set_size_request (image_window, back_width, back_height);
          gtk_window_set_resizable (GTK_WINDOW (image_window), FALSE);
          gtk_window_set_title (GTK_WINDOW (image_window), "BFP Image Window");	       
          gtk_window_move( GTK_WINDOW (image_window), 450, 1 );
  	  g_signal_connect (image_window, "destroy",
			    G_CALLBACK (destroy_cb), NULL);
 	  da = gtk_drawing_area_new ();
	  g_signal_connect (da, "expose_event",
			    G_CALLBACK (expose_cb), NULL);
	  gtk_container_add (GTK_CONTAINER (image_window), da);
   	  timeout_id = g_timeout_add (FRAME_DELAY, frame_timeout, NULL);	  
	}
	gtk_widget_show_all (image_window);	
        while( g_main_context_iteration(NULL,FALSE));       	
     }
  }  
}



/* Capture single frame */

void EnterMessageCaptureCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "enter message callback (capture).\n" );
  MessageBuffer = capture_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}

void ReleaseMessageCaptureCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "release message callback (capture).\n" );
  MessageBuffer = release_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}

void CaptureCallback(GtkWidget *widget,
        GdkEvent *event,gpointer data) 
{
  int res;
  GtkWidget *dialog;
  GtkWidget  *window;    
  struct timeval  old_time;
  struct timeval  new_time;
  unsigned long int runtimes_us;
  char msg_text_buf[100];
  char value_str[16];
    
  if (gtk_debug) g_print( "Capture.\n" );
  scan_run = 1;

  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);  

  res = detect_scanner_presence_in_system();
  if (res != 0) {
    if (gtk_debug) g_print( "ERROR: scanner not found.\n" );
    dialog = gtk_message_dialog_new (GTK_WINDOW (window),
  				     GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
				     GTK_MESSAGE_ERROR,
				     GTK_BUTTONS_OK,
				     "Biometric fingerprint scanner not found!" );
    gtk_dialog_run (GTK_DIALOG (dialog));
    gtk_widget_destroy (dialog);
    return;
  }

while( 1 ) {  

  unlink_image_files();
  
  if (gtk_debug) g_print( "Start operation. Timeout %d seconds.\n", timeout );
  memset( raw_image_buf, 0, fp_image_size );
  gettimeofday( &old_time, NULL );
  res = bfp_get_image_timeo( raw_image_buf, fp_image_size, timeout, 0 );
  gettimeofday( &new_time, NULL );
  
  memset( msg_text_buf, 0, sizeof(msg_text_buf) );
  runtimes_us = (new_time.tv_sec - old_time.tv_sec)*1000000 +
                (new_time.tv_usec - old_time.tv_usec);
  snprintf( value_str, sizeof(value_str), " (%lu.%lu sec)", runtimes_us/1000000,
            runtimes_us/1000 );
  
  if (res < 0) {
    strncpy( msg_text_buf, "MSG_BUF: Fingerprint not present.", sizeof(msg_text_buf) );
    strncat( msg_text_buf, value_str, sizeof(msg_text_buf) );
  }
  else {
    strncpy( msg_text_buf, "MSG_BUF: Fingerprint found.", sizeof(msg_text_buf) );  
    strncat( msg_text_buf, value_str, sizeof(msg_text_buf) );    
  }
  PutMessageText( msg_text_buf );
  
  display_fp_image_in_window();

  if (scan_run == 0) {
    if (gtk_debug) g_print( "Stop scanning.\n" );
    break;  
  }
}

  if (gtk_debug) g_print( "Done.\n" );
  return;
}


/* Stop scanning */

void EnterMessageStopCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "enter message callback (stop).\n" );
  MessageBuffer = capture_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}

void ReleaseMessageStopCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "release message callback (stop).\n" );
  MessageBuffer = release_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}


void StopCallback(GtkWidget *widget,
        GdkEvent *event,gpointer data) 
{
  if (gtk_debug) g_print( "Stop scanning signal.\n" );
  scan_run = 0;
  if (gtk_debug) g_print( "Done.\n" );  
  return;  
}


/* Images saving */

void EnterMessageSaveCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "enter message callback (save).\n" );
  MessageBuffer = capture_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}

void ReleaseMessageSaveCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "release message callback (save).\n" );
  MessageBuffer = release_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}

void SaveCallback(GtkWidget *widget,
        GdkEvent *event,gpointer data) 
{
  if (gtk_debug) g_print( "Save a fingerprint image.\n" );
  save_image = 1;
  if (gtk_debug) g_print( "No erase images after exit!\n" );  
  return;
}


void EnterMessageEnrollCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "enter message callback (enroll).\n" );
  MessageBuffer = capture_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}


/* Enrollment */

void ReleaseMessageEnrollCallBack( GtkWidget *widget,
        GdkEvent *event,gpointer data)
{
  if (gtk_debug) g_print( "release message callback (enroll).\n" );
  MessageBuffer = release_message;
  gtk_label_set_text(GTK_LABEL(TextMessageLabel),MessageBuffer);
  return;
}

void EnrollCallback(GtkWidget *widget,
        GdkEvent *event,gpointer data) 
{
  if (gtk_debug) g_print( "Enroll.\n" );
  return;  
}


/* Miscellaneous */

int detect_scanner_presence_in_system(void)
{
  int  res;
  struct bfp_hardware_info  bfp_hw_param;

  res = bfp_get_hardware_info( &bfp_hw_param, 0 );
  if (res != 0) {
    g_print( "ERROR: bfp_get_hardware_param() failed, code=%d\n", res );
    return(-1);
  }

  if (gtk_debug) g_print( "BFP scanner found.\n" );

  return res;
}


/* Run another program */
int  run_this_program( char * program, char * parameters )
{
  int      res = 1;
  pid_t    pid;
  int      status = -1;
  char     cmdstr[256];

  if ((program == NULL) || (parameters == NULL))
    return(res);

  memset( cmdstr, 0, sizeof(cmdstr) );
  strncpy( cmdstr, program, sizeof(cmdstr) );
  strncat( cmdstr, " ", sizeof(cmdstr)-(strlen(cmdstr)+1) );  
  strncat( cmdstr, parameters, sizeof(cmdstr)-(strlen(cmdstr)+1) );
  
  switch( pid = fork()) {
    case -1: 
           if (gtk_debug) g_print( "ERROR: fork failed!\n" );
           res = 2;
           break;
    case 0:
          /* child */
          execl( "/bin/sh", "sh","-c", cmdstr, NULL,NULL );
          if (gtk_debug) g_print( "ERROR: exec faled!" );
          res = 3;
          break;
    default:
          wait(&status);
          if (gtk_debug) g_print( "exec running.\n" );
          res = WEXITSTATUS(status);          
          if (gtk_debug) g_print( "exec done. code = %d\n", res );
          break;
  }

  return(res);
}
