/* Copyright (c) 2003-2004 Dmitry Stefankov */

/* $Id: bfpsdk.h,v 1.7 2004-08-05 16:51:59+04 dstef Exp root $ */

#ifndef __bfpsdk_h__
#define __bfpsdk_h__


#ifndef BFP_API

#if defined(_WINDOWS)
 #if defined(__BORLANDC__)
  #define DllImport	__declspec( dllimport ) WINAPI
  #define DllExport	__declspec( dllexport ) WINAPI
 #else
  #define DllImport	__declspec( dllimport )
  #define DllExport	__declspec( dllexport )
 #endif
#else
#define DllExport
#define DllImport
#endif

#ifdef _WINDLL
#define BFP_API DllExport 
#else
#define BFP_API DllImport  
#endif

#endif


#ifdef __cplusplus
extern "C" { /* assume C declarations for C++ */
#endif


#if defined(_WIN32)
#pragma pack(push,1)
#endif

/* Hardware information */
struct bfp_hardware_info;

struct bfp_hardware_info {
  struct bfp_hardware_info  * next_link;
  unsigned char         country;
  unsigned char         manufacturer;
  unsigned char         parameters;
  unsigned char         serial_num_low;
  unsigned char         serial_num_mid;
  unsigned char         serial_num_high;
  unsigned char		major_hardware_version;
  unsigned char		minor_hardware_version;
  unsigned char		major_firmware_version;
  unsigned char		minor_firmware_version;
  unsigned char		x_size_high;
  unsigned char		x_size_low;
  unsigned char		y_size_high;
  unsigned char		y_size_low;
  unsigned char		rotate_image;
  unsigned char		mirror_image;
  unsigned char		x_pixel_size;
  unsigned char		another_light;
  unsigned char         serial_num_option;
  unsigned char         y_pixel_size;
  unsigned char         calibration_option;
#if defined(_WIN32)  
};
#else
} __attribute__ ((aligned(1),packed));
#endif

/* Software information */
struct bfp_software_info {
  unsigned int   model_size;
  unsigned int   total_size; 
  unsigned short quality;
  unsigned short measure;   
  char           internal_version[128];   
  unsigned int   image_height;   
  unsigned int   image_width;
  unsigned int   image_size;     
  unsigned short samples_num;
  unsigned short models_num;
  unsigned short max_models;
  unsigned char	 major_software_version;
  unsigned char	 minor_software_version;
#if defined(_WIN32)  
};
#else
} __attribute__ ((aligned(1),packed));
#endif

#if defined(_WIN32)
#pragma pack(pop)
#endif

BFP_API int bfp_init(void);
BFP_API int bfp_deinit(void);
BFP_API int bfp_get_software_info( struct bfp_software_info * p_soft_param );
BFP_API int bfp_get_hardware_info( struct bfp_hardware_info * p_hard_param, int scanner );
BFP_API int bfp_get_image_timeo( unsigned char * buf, unsigned long int bufsize, 
                                int timeout, unsigned long int sernum );
BFP_API int bfp_extract(void *images, int n, void *buf);
BFP_API int bfp_match(void *buf1, int n1, void *buf2, int n2);


#ifdef __cplusplus
};
#endif                        

#endif
