/* Copyright (c) 2003-2004 Dmitry Stefankov */

#if defined(_WIN32)
#include <windows.h>
#endif
#if defined(_UNIX)
#include <unistd.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <math.h>

#include "bfpsdk.h"

static const char rcs_id[] = "$Id: sample.c,v 1.4 2004-07-11 22:52:42+04 dstef Exp root $";

//---------------------------------------------------------------------------
int main(int argc, char **argv)
{
 int               i;
 unsigned char   * lpMapA = NULL;
 unsigned char   * lpMapB = NULL; 
 long              l;
 long              n;
 int               res;
 long              tmpl_size;
 struct bfp_hardware_info  bfp_hw_param; 
 struct bfp_software_info  bfp_soft_param;
 int               IMG_SCAN_SIZE;
 int               timeout = 15;
 int               max_images_num = 0;
 unsigned char   * pImagesTmpl = NULL;
 unsigned char   * pImagesMdl  = NULL;

 // Init library
 res = bfp_init();
 if (res != 0) {
   fprintf( stderr, "bfp_init() failed, code=%d\n", res );
   return(1);
 }

 // Detect hardware presence
 memset( &bfp_hw_param, 0, sizeof(bfp_hw_param) );
 res = bfp_get_hardware_info( &bfp_hw_param, 0 );
 if (res != 0) {
   fprintf( stderr, "bfp_get_hardware_param() failed, code=%d\n", res );
   return(1);
 }

 // Get library constants
 memset( &bfp_soft_param, 0, sizeof(bfp_soft_param) );
 res = bfp_get_software_info( &bfp_soft_param );
 if (res != 0) {
   fprintf( stderr, "bfp_get_software_info() failed, code=%d\n", res );
   return(1);
 }

 max_images_num = bfp_soft_param.samples_num;
 IMG_SCAN_SIZE = bfp_soft_param.image_size;

 // Allocate memory
 l = bfp_soft_param.max_models;
 if((lpMapA = (unsigned char *)malloc(l * bfp_soft_param.model_size)) == NULL)
    {printf("Not enough memory!"); goto final;}
 memset(lpMapA, 0, l * bfp_soft_param.model_size);

 n = 1;
 if((lpMapB = (unsigned char *)malloc(n * bfp_soft_param.model_size)) == NULL)
    {printf("Not enough memory!"); goto final;}
 memset(lpMapB, 0, n * bfp_soft_param.model_size);
 
 pImagesTmpl = malloc(max_images_num*IMG_SCAN_SIZE);
 if (pImagesTmpl == NULL) {
   printf( "Not enough memory for images buffer (template)!\n" );
   goto final;
 }

 pImagesMdl = malloc(n*IMG_SCAN_SIZE);
 if (pImagesMdl == NULL) {
   printf( "Not enough memory for images buffer (model)!\n" );
   goto final;
 }

 // Read N images from scanner
 printf( "Get images for template.\n" );
 for( i=0; i<max_images_num; i++ ) {
   printf( "Put your finger on scanner.\n" );
   res = bfp_get_image_timeo( pImagesTmpl+(i*IMG_SCAN_SIZE), IMG_SCAN_SIZE, timeout, 0 );
   if (res != 0) {
         printf( "ERROR: cannot get fingerprint image from scanner!\n" );
         return(1);
   }
   printf( "Take your finger off scanner. Image %d.\n", i );
#if defined(_UNIX)
   sleep(1);
#endif
#if defined(_WIN32)
   Sleep(1000);
#endif
 }

 // Read one image from scanner
 printf( "Get image for model.\n" );
 printf( "Put your finger on scanner.\n" );
 res = bfp_get_image_timeo( pImagesMdl, IMG_SCAN_SIZE, timeout, 0 );
 if (res != 0) {
         printf( "ERROR: cannot get fingerprint image from scanner!\n" );
         return(1);
  }
  printf( "Take your finger off scanner.\n" );
 
 // Build template from images
 printf("Build template.\n");
 tmpl_size = bfp_extract(pImagesTmpl,max_images_num , lpMapA);
 printf("template_size = %lu\n", tmpl_size );

 // Build model from image
 printf("Build model.\n");
 res = bfp_extract(pImagesMdl, n, lpMapB);
 printf("model_size = %d\n", res );

 // Compare template and model
 printf( "Compare.\n" );
 res = bfp_match( lpMapB, res, lpMapA, tmpl_size );
 printf( "result = %d\n", res );

final:
 // Cleanup 
 if(lpMapA != NULL) free(lpMapA);
 if(pImagesTmpl != NULL) free(pImagesTmpl);
 if(lpMapB != NULL) free(lpMapB);  
 if(pImagesMdl != NULL) free(pImagesMdl);
 
 // Exit library
 res = bfp_deinit();
  
 return 0;
}
