/** text-demo.c **/
/* Copyright (C) 2003-2004 Dmitry Stefankov */

#if defined(_UNIX)
#include <unistd.h>
#endif
#if defined(_WIN32)
#include <windows.h>
#endif
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#if defined(_UNIX)
#include <bfpsdk.h>
#endif
#if defined(_WIN32)
#include "bfpsdk.h"
#endif

#if defined(_WIN32)
#define  sleep(x)   Sleep(x*1000)
#endif

/* Constants */
#define  MAX_USERS_NUM   1024
#define  MAX_USER_NAME_SIZE  64

static const char rcs_id[] = "$Id: text-demo.c,v 1.4 2004-07-11 22:53:02+04 dstef Exp root $";

/* BFP measurement level */
int measure = 0;

/* N seconds to detect finger presence */
int  timeout = 30;          

struct fp_user_template {
  int            template_size;
  unsigned char  * fp_template;
  char           user_name[MAX_USER_NAME_SIZE+1];
};

/* Current users number */
int  db_users_num = 0;

struct fp_user_template  temp_user_record;
struct fp_user_template  user_templates_db[MAX_USERS_NUM];

unsigned char   * fp_model = NULL;
unsigned char   * fp_template = NULL;
unsigned char   * raw_image_buf = NULL;
unsigned char   * enroll_images_buf;  

int             fp_model_size = 0;
int             fp_template_size = 0;
int             fp_images_num = 0;
unsigned int    fp_image_size = 0;
struct bfp_software_info  bfp_param; 


/* Functions */
void enroll_user(void );
void list_users(void );
void verify_user(void );
void identify_user(void );
void program_shutdown();
int  detect_scanner_presence_in_system(void);    


void display_main_menu( void )
{
    printf( "\n" );
    printf( "BFP demo application for text mode, v1.0\n" );
    printf( "[1] User enrollment\n" );
    printf( "[2] User identification\n" );
    printf( "[3] User verification\n" );
    printf( "[4] List users\n" );
    printf( "[5] Quit\n" );
    printf( "Your selection [12345]: " );
}

/* Main application */
int main(int argc,char *argv[])
{
    int res;
    int i;
    int c;
    int done = 0;
    
    /* Init BFP dynamic library */
    res = bfp_init();  
    if (res != 0) {
      printf("FATAL ERROR: cannot init BFP library!\n");
      exit(1);
    }

    memset( &bfp_param, 0, sizeof(bfp_param) );
    res = bfp_get_software_info( &bfp_param );
    if (res != 0) {
       printf("FATAL_ERROR: bfp_get_software_param() failed, code=%d\n", res);
       exit(1);
    } 

    measure = bfp_param.measure;
    fp_model_size = bfp_param.model_size;
    fp_template_size = bfp_param.total_size;
    fp_images_num = bfp_param.samples_num;
    fp_image_size = bfp_param.image_size;
    
    fp_model = malloc(fp_model_size);
    if (fp_model == NULL) {
      printf( "Cannot allocate memory for model!\n" );
      exit(1);
    }
    
    fp_template = malloc(fp_template_size);
    if (fp_template == NULL) {
      printf( "Cannot allocate memory for template!\n" );
      exit(1);
    }

    raw_image_buf = malloc(fp_image_size*1);
    if (raw_image_buf == NULL) {
      printf( "Cannot allocate memory for image buffer!\n" );
      exit(1);
    }

    enroll_images_buf = malloc(fp_image_size*fp_images_num);
    if (enroll_images_buf == NULL) {
      printf( "Cannot allocate memory for images buffer!\n" );
      exit(1);
    }

    temp_user_record.fp_template = malloc(fp_template_size);
    if (temp_user_record.fp_template == NULL) {
      printf( "Cannot allocate memory for template buffer!\n" );
      exit(1);
    }
    
    memset( user_templates_db, 0, sizeof(user_templates_db) );
    for( i=0; i<MAX_USERS_NUM; i++) {
       user_templates_db[i].fp_template = malloc(fp_template_size);
       if (user_templates_db[i].fp_template == NULL) {
         printf( "Cannot allocate memory for templates buffer!\n" );
         exit(1);
       }
    }

    while( done == 0 ) {
      printf( "\n" );    
      display_main_menu();
      c = getchar();
      switch( c ) {
        case '5':  done = 1;
                   break;
        case '1':  enroll_user();
                   break;
        case '2':  identify_user();
                   break;
        case '3':  verify_user();
                   break;
        case '4':  list_users();
                   break;
        default:
               break;
      }
      c = getchar();
      printf( "\n" );      
    }

    printf( "\n" );
    program_shutdown();
    return(0);
}


/* Destroy before exit */
void program_shutdown() {
    int res;
    int i;
    
    res = bfp_deinit();    
    if (fp_model != NULL) free(fp_model);
    if (fp_template != NULL) free(fp_template);
    if (raw_image_buf != NULL) free(raw_image_buf);    
    if (enroll_images_buf != NULL) free(enroll_images_buf);
    if (temp_user_record.fp_template != NULL) free(temp_user_record.fp_template);
    for( i=0; i<MAX_USERS_NUM; i++) {
       free(user_templates_db[i].fp_template);
    }
}

/* Miscellaneous */
int detect_scanner_presence_in_system(void)
{
  int  res;
  struct bfp_hardware_info  bfp_hw_param;

  res = bfp_get_hardware_info( &bfp_hw_param, 0 );
  if (res != 0) {
    printf( "ERROR: bfp_get_hardware_param() failed, code=%d\n", res );
    return(-1);
  }

  return res;
}

/* Display current users per database */
void list_users(void )
{
  int i;

  printf( "Users per database.\n" );  
  for( i=0; i<MAX_USERS_NUM; i++ ) {
      if (strlen(user_templates_db[i].user_name) > 0) {
        printf( "%d. %s\n", i+1, user_templates_db[i].user_name );
      }
  }

}

/* Enrollment */
void enroll_user(void )
{
  int  username_found;
  int res;
  int i;
  unsigned char * p;
  char enroll_user_name[MAX_USER_NAME_SIZE+1];

  if (db_users_num >= MAX_USERS_NUM) {
    printf( "ERROR: user database is full.\n" );
    return;
  }
  
  res = detect_scanner_presence_in_system();  
  if (res != 0) {
    printf( "ERROR: scanner not found.\n" );
    return;
  }  
  
  memset( enroll_images_buf, 0, fp_image_size*fp_images_num );
  p = enroll_images_buf;  

  for( i=0; i<fp_images_num; i++ ) {
    
    if (i > 0) {
      while( 1 ) {  
        res = bfp_get_image_timeo( raw_image_buf, fp_image_size, 2, 0 );
        if (res != 0) break;
        printf( "Please remove your fingers off our device!\n");
      }
    }

    printf( "Put your finger ON scanner.\n" );    
    printf( "Start capture image %d. Timeout %d seconds.\n", i+1, timeout );
    res = bfp_get_image_timeo( p, fp_image_size, timeout, 0 );
    
    if (res < 0) {
      printf( "ERROR: no finger detected on scanner.\nTerminate.\n" );      
      return;
    }
    memcpy( raw_image_buf, p, fp_image_size );
    p += fp_image_size;
    printf( "Put your finger OFF scanner.\n" );
    sleep(1);
  }
  
  printf("Building template.\n");
  memset( fp_template, 0, fp_template_size );
  res = bfp_extract(enroll_images_buf, fp_images_num, fp_template);
  if (res > 0) {
    printf( "Template OK.\n" );
  }
  else {
    printf( "Template BAD. Code = %d\nTerminate.\n", res );
    return;
  }
  
  temp_user_record.user_name[0] = '\0';
  memcpy( temp_user_record.fp_template, fp_template, fp_template_size );
  temp_user_record.template_size = res;

  memset( enroll_user_name, 0, sizeof(enroll_user_name) );
  printf( "Enter username: " );
  scanf( "%s", enroll_user_name );
  
  username_found = 1;
  if (strlen(enroll_user_name) < 1) {
    username_found = 0;    
  }
  
  if (username_found == 0) {
    printf( "ERROR: no user input.\nCancelled.\n" );
    return;
  }

  for( i=0; i<MAX_USERS_NUM; i++ ) {
      if (strcmp(enroll_user_name,user_templates_db[i].user_name) == 0) {
        printf( "ERROR: duplicate name found.\n" );
        return;
      }
  }

  i = db_users_num;
  printf( "Added record %d to database. User = %s\n", i+1, enroll_user_name );
  strncpy( user_templates_db[i].user_name, enroll_user_name, MAX_USER_NAME_SIZE );
  memcpy( user_templates_db[i].fp_template, temp_user_record.fp_template, 
            fp_template_size );
  user_templates_db[i].template_size = temp_user_record.template_size;
  db_users_num++;

  return;  
}


/* Identification */

void identify_user(void)
{
  int res;
  int i;
  int found;
  char message[100];

  if (db_users_num == 0) {
    printf( "ERROR: empty users database found.\n" );
    return;
  }
  
  res = detect_scanner_presence_in_system();
  if (res != 0) {
    printf( "ERROR: scanner not found.\n" );
    return;
  }  

  printf( "Put your finger ON scanner.\n" );    
  printf( "Start capture image. Timeout %d seconds.\n", timeout );
  memset( raw_image_buf, 0, fp_image_size );
  res = bfp_get_image_timeo( raw_image_buf, fp_image_size, timeout, 0 );
  printf( "Put your finger OFF scanner.\n" );  

  if (res < 0) {
    printf( "ERROR: no finger detected on scanner.\nTerminate.\n" );      
    return;
  }

  printf("Building model.\n");
  memset( fp_model, 0, sizeof(fp_model) );
  res = bfp_extract(raw_image_buf, 1, fp_model);
  if (res > 0) {
    printf( "Model OK.\n" );
  }
  else {
    printf( "Model BAD. Code = %d\nTerminate.\n", res );
    return;
  }
  
  memset( message, 0, sizeof(message) );
  strncat( message, "Person(s):", sizeof(message)-1 );
  found = 0;
  for( i=0; i<db_users_num; i++ ) {
    res = bfp_match(fp_model, fp_model_size, user_templates_db[i].fp_template, 
                   user_templates_db[i].template_size );
    //printf( "%d, %d\n", i, res );               
    if (res > 0) { 
      if (res < measure) {
        continue;
      }
      found++;
      strncat( message, " ", sizeof(message)-1);
      strncat( message, user_templates_db[i].user_name, sizeof(message)-1);
    }
    else {
    }
  }
  if (found == 0) {
    printf( "ERROR: No such person(s) found.\n" );
    return;
  }
  printf( "%s\n", message );
  
  return;
}


/* Verification */

void verify_user(void)
{
  int  username_found;
  char message[100];
  int  i;
  int  res;    
  int  found;
  char verify_user_name[MAX_USER_NAME_SIZE+1];  
  
  if (db_users_num == 0) {
    printf( "ERROR: empty users database found.\n" );
    return;
  }
  
  memset( verify_user_name, 0, sizeof(verify_user_name) );
  printf( "Enter username: " );
  scanf( "%s", verify_user_name );

  
  username_found = 1;
  if (strlen(verify_user_name) < 1) {
    username_found = 0;    
  }
  
  if (username_found == 0) {
    printf( "ERROR: no user input.\nCancelled.\n" );
    return;
  }

  found = 0;
  for( i=0; i<db_users_num; i++ ) {
      if (strcmp(verify_user_name,user_templates_db[i].user_name) == 0) {
        printf( "Matching name found. Record is %d.\n", i );
        found = 1;
        break;
      }
  }
  
  if (found == 0) {
    printf( "ERROR: this person is missing into database.\n" );
    return;
  }

  res = detect_scanner_presence_in_system();
  if (res != 0) {
    printf( "ERROR: scanner not found.\n" );
    return;
  }  

  printf( "Put your finger ON scanner.\n" );    
  printf( "Start capture image. Timeout %d seconds.\n", timeout );
  memset( raw_image_buf, 0, fp_image_size );
  res = bfp_get_image_timeo( raw_image_buf, fp_image_size, timeout, 0 );
  printf( "Put your finger OFF scanner.\n" );  
  
  if (res < 0) {
    printf( "ERROR: no finger detected on scanner.\nTerminate.\n" );      
    return;
  }
  
  printf("Building model.\n");
  res = bfp_extract(raw_image_buf, 1, fp_model);
  if (res > 0) {
    printf( "Model OK.\n" );
  }
  else {
    printf( "Model BAD. Code = %d\nTerminate.\n", res );
    return;
  }
  
  res = bfp_match(fp_model, fp_model_size, user_templates_db[i].fp_template, 
                  user_templates_db[i].template_size );
  //printf( "%d: user = %s, code = %d\n", i, user_templates_db[i].user_name, res );  
  
  found = 0;  
  memset( message, 0, sizeof(message) );
  if (res > 0) { 
      if (res < measure) {
        printf( "ERROR: Bad person.\n" );
        return;        
      }
      found++;
      strncat( message, "Verification successful. Person is ", sizeof(message)-1 );
      strncat( message, user_templates_db[i].user_name, sizeof(message)-1 );
      strncat( message, ".", sizeof(message)-1 );
      printf( message );
  }
  else {
    printf( "ERROR: Mismatched person.\n" );
    return;
  }

  return;
}
